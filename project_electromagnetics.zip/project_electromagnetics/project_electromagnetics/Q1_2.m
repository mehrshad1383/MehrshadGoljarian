clc
clear all
z_v = -50:1:200;
iterator = 2 * sqrt(4 * z_v.^2 + 1) .* sqrt(4 * z_v.^2 - 792 * z_v + 39205) ...
    - 8 * z_v.^2 + 1584 * z_v - 78410;
extrator = sqrt(4 * z_v.^2 + 1) .* (4 * z_v.^2 - 792 * z_v + 39205);
equal = iterator ./ extrator;
Ez=equal*(100/99)*(1/(4*pi*(8.85e-12)));
figure;
plot(z_v, Ez,color='g');
grid on;
