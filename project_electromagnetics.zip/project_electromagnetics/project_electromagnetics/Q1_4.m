n_values = -100:100;
P_values = ((0.999).^(n_values-3)) .* ((0.999).^3 + n_values.*(1/1000).*(0.999).^2 + (n_values.*(n_values-1)/2).*0.999.*(1/1000).^2 + (n_values.*(n_values-1).*(n_values-2)/6).*(1/1000)^3);
P2_values = exp(-n_values/1000) .* (1 + n_values/1000 + ((n_values/1000).^2)/2 + ((n_values/1000).^3)/6);
disp('P values:');
disp(P_values);
disp('P2 values:');
disp(P2_values);
figure;
plot(n_values, P2_values);
title('Plot of P2 vs. n');
xlabel('n');
ylabel('P2');











