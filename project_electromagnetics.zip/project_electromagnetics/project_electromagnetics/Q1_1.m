clc
clear all
num = 100;  
a = 1;           
r = 0.5 * a;    
k = 8.9905e9;   
z_v = linspace(-130*a, 130*a, 1000); 
x_v = linspace(-130*a, 130*a, 1000); 
E_z = zeros(size(z_v));
E_x = zeros(size(x_v));

for i = 1:num 
    z_q = (i - 1) * a;
    x_q = a/2;
    r_z = sqrt((z_v - z_q).^2 + r^2);
    r_x = sqrt((x_v - x_q).^2 + r^2);
    dE_z = k * (a ./ r_z.^3) .* (z_v - z_q);
    dE_x = k * ((a/2) ./ r_z.^3) ;
    E_z = E_z + dE_z;
    E_x = E_x + dE_x;
end
figure;
plot(z_v, E_z);

plot(z_v, E_x);

window_size = 5 * a;
E_z_avg = movmean(E_z, window_size);
E_x_avg = movmean(E_x, window_size);
figure;
subplot(2,1,1);
plot(z_v, E_z_avg,color='g');

subplot(2,1,2);
plot(z_v, E_x_avg,color='r');
