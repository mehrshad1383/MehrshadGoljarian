clc
clear all
Ps = 0.01;
alfa = 1;
t = 2e-9;
d = 96e-9;
Ec = 8e6; 
epsilon = 8.85e-12;
V1 = 0;
g = @(P) Ps * tanh(alfa * ((-epsilon * V1 - 2 * t * P) / (Ec * epsilon * (2 * t + d)) + 1)) - P;
P_g = 0;
result = fsolve(g, P_g);
result
