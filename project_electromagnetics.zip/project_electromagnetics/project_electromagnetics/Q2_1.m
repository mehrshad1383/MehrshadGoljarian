clc
clear all
Ps = 0.01;
a = 1;
t = 5e-9;
d = 96e-9;
Ec = 8e6;  
epsilon = 8.85e-12;
num = linspace(-15, 15, 1000);
F_s = zeros(size(num));
F1_s = zeros(size(num));
F = @(P, num) Ps * tanh(a * ((-epsilon * num - 2 * t * P) / (Ec * epsilon * (2 * t + d)) + 1)) - P;

for j = 1:length(num)
    F_g = 0;
    F_s(j) = fsolve(@(P) F(P, num(j)), F_g);
end
f1 = @(P1, v) Ps * tanh(a * ((-epsilon * v - 2 * t * P1) / (Ec * epsilon * (2 * t + d)) - 1)) - P1;
for j = 1:length(num)
    F1_g = 0;
    F1_s(j) = fsolve(@(P1) f1(P1, num(j)), F1_g);
end
plot(num, F_s, 'r', num, F1_s, 'g');
ylabel("P")
xlabel("voltage")
grid on;
