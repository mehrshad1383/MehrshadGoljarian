package view;

import controller.CustomerMenuController;
import controller.OrderHistoryMenuController;
import javafx.application.Application;
import javafx.css.Match;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.ImagePattern;
import javafx.scene.paint.Paint;
import javafx.stage.Stage;
import model.Customer;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class OrderHistoryMenu extends Application {
    private OrderHistoryMenuController orderHistoryMenuController;
    private Customer customer;
    public static Stage stage;
    private Pane pane = new Pane();
    private MediaPlayer mediaPlayer;

    public OrderHistoryMenu(Customer loggedcustomer) {
        this.orderHistoryMenuController = new OrderHistoryMenuController(this);
        this.customer = loggedcustomer;
    }

//    public OrderHistoryMenu() {
//        this.customer = new Customer("pp" , "pp" , 4 , "pp");
//    }
    @Override
    public void start(Stage stage) throws Exception {
        int index = Customer.returnIndexFromObject(customer);
        OrderHistoryMenu.stage=stage;
        stage.setMaximized(true);
        //pane = FXMLLoader.load(new URL(LoginMenu.class.getResource("/FXML/CustomerMenu.fxml").toExternalForm()));
        Paint paint = new ImagePattern(new Image(LoginMenu.class.getResource("/Image/LoginMenu.JPG").toExternalForm()));
        BackgroundFill backgroundFill = new BackgroundFill(paint , CornerRadii.EMPTY, Insets.EMPTY);
        pane.setBackground(new Background(backgroundFill));
        if (stage.getScene() == null) {
            Scene scene = new Scene(pane);
            stage.setScene(scene);
        } else stage.getScene().setRoot(pane);
        ScrollPane scrollPane = new ScrollPane();
        VBox vBox = new VBox();
        Label label = new Label();
        label.setLayoutX(300);
        label.setLayoutY(300);
        vBox = orderHistoryMenuController.ShowAllOrder(index,vBox);
        if(vBox.getChildren().size()==0){
            pane.getChildren().add(label);
        }
        Button exitbutton = new Button("Exit");
        exitbutton.setLayoutX(10);
        exitbutton.setLayoutY(10);
        exitbutton.setStyle("-fx-background-color:rgba(32,253,143,0.65);");
        pane.getChildren().add(exitbutton);
        exitbutton.setOnAction(event -> {
            try {
                exit();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });
        vBox.setAlignment(Pos.CENTER);
        vBox.setSpacing(5);
        scrollPane.setContent(vBox);
        scrollPane.setMaxSize(800,800);
        pane.getChildren().add(scrollPane);
        scrollPane.setLayoutX(400);
        scrollPane.setLayoutY(20);
        stage.show();
    }
    public void exit() throws Exception {
        CostumerMenu costumerMenu = new CostumerMenu(customer,mediaPlayer);
        costumerMenu.start(LoginMenu.stage);
    }
}
/*
    public void run(Customer customer) {
        int index = Customer.returnIndexFromObject(customer);
        orderHistoryMenuController.showAllOrder(index);
        if(customer.getOrders().size()==0)
            return;
        String r1 = "SELECT ORDER (?<ID>(\\d)+)";
        Pattern p1 = Pattern.compile(r1);
        String r2 = "back";
        Pattern p2 = Pattern.compile(r2);
        String r3 = "Help";
        Pattern p3 = Pattern.compile(r3);
        String command, result;
        while (true) {
            command = Menu.getScanner().nextLine();
            command = command.trim();
            Matcher m1 = p1.matcher(command);
            Matcher m2 = p2.matcher(command);
            Matcher m3 = p3.matcher(command);
            if(m1.matches()){
                int id = Integer.parseInt(m1.group("ID"));
                id=id-3000000;
                orderHistoryMenuController.Showspecialorder(index,id);
            }
            else if(m2.matches()){
                return;
            }
            else if (command.trim().equals("WHERE AM I")) {
                System.out.println("OrderHistoryMenu");
            }
            else if(m3.matches()){
                System.out.println("Available options: ");
                System.out.println("SELECT ORDER <ID>");
                System.out.println(r2);
            }
            else{
                System.out.println("Invalid Command");
            }
        }
    }
}
*/
