package view;

import controller.DeliveryManagementMenuController;
import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import model.*;

import java.awt.*;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DeliveryManagementMenu extends Application {
    public Stage stage;

    public static Pane pane;
    public Label DeliverYLabel;
    public ImageView icon = new ImageView();
    public ImageView icon2 = new ImageView();
    public ImageView icon3 = new ImageView();
    public Button back = new Button("back");
    public ArrayList<Order> AvailibleOrders = new ArrayList<>();
    public Button ShowPathbutton;
    private ChoiceBox<String> ChoiceBox = new ChoiceBox<>();
    private String[] Choices = {"ShowOrderPath" , "ConfirmOrder" , "ShowDetail"};

    public Pane getPane() {
        return pane;
    }

    private DeliveryManagementMenuController deliveryManagementMenuController;
    private static Delivery delivery;
    public DeliveryManagementMenu()
    {
        this.deliveryManagementMenuController = new DeliveryManagementMenuController(this);
    }
    public DeliveryManagementMenu(Delivery loggedDelivery) {
        this.deliveryManagementMenuController = new DeliveryManagementMenuController(this);
        this.delivery = loggedDelivery;
    }

    public void start(Stage stage) throws IOException
    {
        this.stage = stage;
        stage.setMaximized(true);
        pane = FXMLLoader.load(new URL(LoginMenu.class.getResource("/FXML/mapTest.fxml").toExternalForm()));
        Paint paint = new ImagePattern(new Image(LoginMenu.class.getResource("/Image/map.JPG").toExternalForm()));
        Image pp = new Image(LoginMenu.class.getResource("/Image/delivery.PNG").toExternalForm());
        Image pp2 = new Image(LoginMenu.class.getResource("/Image/resturant.PNG").toExternalForm());
        Image pp3 = new Image(LoginMenu.class.getResource("/Image/customer.PNG").toExternalForm());
        icon.setImage(pp);
        icon.setFitHeight(30);
        icon.setFitWidth(30);
        icon2.setImage(pp2);
        icon2.setFitHeight(30);
        icon2.setFitWidth(30);
        icon2.setX(30);
        icon2.setY(30);
        icon3.setImage(pp3);
        icon3.setFitHeight(30);
        icon3.setFitWidth(30);
        icon3.setX(30);
        icon3.setY(30);
        back.setLayoutX(10);
        back.setLayoutY(10);
        back.setOnAction(event -> {
                    try {
                        mmd();
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
        );
        ChoiceBox.setLayoutX(1350);
        ChoiceBox.setLayoutY(20);
        ChoiceBox.setPrefWidth(150);
        ChoiceBox.getItems().addAll(Choices);
//        javafx.scene.control.Label label = new javafx.scene.control.Label();
//        label.setGraphic(icon);
//        javafx.scene.control.Label label2 = new javafx.scene.control.Label();
//        label2.setGraphic(icon2);
//        javafx.scene.control.Label label3 = new Label();
//        label3.setGraphic(icon3);
//        label2.setLayoutX(Map.getMapMatrixX()[22]-15);
//        label2.setLayoutY(Map.getMapMatrixY()[22]-15);
//        label3.setLayoutX(Map.getMapMatrixX()[60]-15);
//        label3.setLayoutY(Map.getMapMatrixY()[60]-15);
//        label.setLayoutX(orderControllertest.x-15);
//        label.setLayoutY(orderControllertest.y-15);
        BackgroundFill backgroundFill = new BackgroundFill(paint , CornerRadii.EMPTY, Insets.EMPTY);
        pane.setBackground(new Background(backgroundFill));
        ShowOrders(delivery);
        pane.getChildren().add(back);
        pane.getChildren().add(ChoiceBox);
//        Button button = new Button();
//        button.setLayoutX(600);
//        button.setLayoutY(600);
//        pane.getChildren().add(button);pane.getChildren().add(icon);
        if (stage.getScene() == null) {
            Scene scene = new Scene(pane);
            stage.setScene(scene);
        } else stage.getScene().setRoot(pane);
        stage.show();
    }

    private void mmd() throws IOException {
        LoginMenu loginMenu = new LoginMenu();
        loginMenu.start(LoginMenu.stage);
    }

    @FXML
    public void initialize() throws Exception{
        ChoiceBox.getItems().addAll(Choices);
    }

    public void ShowOrders(Delivery delivery) {
        System.out.println("pp");
        AvailibleOrders = new ArrayList<>();
//        String returner = "";
        for (int i = 0; i < FileManager.getFileManagerInstance().customers.size(); i++) {
            for (int j = 0; j < FileManager.getFileManagerInstance().customers.get(i).getCompletedorders().size(); j++) {
                if (FileManager.getFileManagerInstance().customers.get(i).getCompletedorders().get(j).getStatus().equals("Confirmed_IsCooking")) {
//                    returner += FileManager.getFileManagerInstance().customers.get(i).getCompletedorders().get(j).getId()+" "+
//                            FileManager.getFileManagerInstance().customers.get(i).getCompletedorders().get(j).getOwner().getNode()+" "+
//                            FileManager.getFileManagerInstance().customers.get(i).getCompletedorders().get(j).getResturant().getLocation().getNode()+" "+
//                            FileManager.getFileManagerInstance().customers.get(i).getCompletedorders().get(j).getDeliveryCost()+"\n";
                    AvailibleOrders.add(FileManager.getFileManagerInstance().customers.get(i).getCompletedorders().get(j));
                }
            }
        }
        for (int i = 0; i < AvailibleOrders.size(); i++) {
            ButtonV2 buttonV2 = new ButtonV2(icon, AvailibleOrders.get(i));
            buttonV2.getButton().setLayoutX(Map.getMapMatrixX()[AvailibleOrders.get(i).getOwner().getNode()-1]);
            buttonV2.getButton().setLayoutY(Map.getMapMatrixY()[AvailibleOrders.get(i).getOwner().getNode()-1]);
            buttonV2.getButton().setMinHeight(3);
            buttonV2.getButton().setMinHeight(3);
            buttonV2.getButton().setOnAction(MouseEvent ->
            {
                String S = ChoiceBox.getValue();
                //"ShowOrderPath" , "ConfirmOrder" , "ShowDetail"
                if(S == null)
                {

                }
                else if(S.equals("ShowOrderPath"))
                {
                    try {
                        pane = FXMLLoader.load(new URL(LoginMenu.class.getResource("/FXML/mapTest.fxml").toExternalForm()));
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                    Paint paint = new ImagePattern(new Image(LoginMenu.class.getResource("/Image/map.JPG").toExternalForm()));
                    BackgroundFill backgroundFill = new BackgroundFill(paint , CornerRadii.EMPTY, Insets.EMPTY);
                    pane.setBackground(new Background(backgroundFill));
                    ShowOrders(delivery);
                    pane.getChildren().add(back);
                    pane.getChildren().add(ChoiceBox);

                    if (stage.getScene() == null) {
                        Scene scene = new Scene(pane);
                        stage.setScene(scene);
                    } else stage.getScene().setRoot(pane);
                    stage.show();
                    deliveryManagementMenuController.ShowRoad2(buttonV2.getOrder());
                }
                else if(S.equals("ConfirmOrder"))
                {
                    try {
                        pane = FXMLLoader.load(new URL(LoginMenu.class.getResource("/FXML/mapTest.fxml").toExternalForm()));
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                    Paint paint = new ImagePattern(new Image(LoginMenu.class.getResource("/Image/map.JPG").toExternalForm()));
                    BackgroundFill backgroundFill = new BackgroundFill(paint , CornerRadii.EMPTY, Insets.EMPTY);
                    pane.setBackground(new Background(backgroundFill));
                    ShowOrders(delivery);
                    pane.getChildren().add(back);
                    pane.getChildren().add(ChoiceBox);

                    if (stage.getScene() == null) {
                        Scene scene = new Scene(pane);
                        stage.setScene(scene);
                    } else stage.getScene().setRoot(pane);
                    deliveryManagementMenuController.ConfirmOrder(buttonV2.getOrder()  , delivery );
                    ShowOrders(delivery);
                    stage.show();
                }
                else if(S.equals("ShowDetail"))
                {
                 DeliveryManageMentOrderreview deliveryManageMentOrderreview = new DeliveryManageMentOrderreview(buttonV2.getOrder() , delivery);
                    try {
                        deliveryManageMentOrderreview.start(stage);
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                }
            });
            pane.getChildren().add(buttonV2.getButton());
        }
    }

    public void ShowPath(MouseEvent mouseEvent) {

        deliveryManagementMenuController.ShowRoad(delivery);

        DeliverYLabel = new Label();
        DeliverYLabel.setGraphic(icon);
        DeliverYLabel.setLayoutX(delivery.x-15);
        DeliverYLabel.setLayoutY(delivery.y-15);
        Label label = new Label();
        label.setGraphic(icon2);
        label.setLayoutX(Map.getMapMatrixX()[delivery.getOrder().getResturant().getLocation().getNode()-1]);
        label.setLayoutY(Map.getMapMatrixY()[delivery.getOrder().getResturant().getLocation().getNode()-1]);
        Label label1 = new Label();
        label1.setGraphic(icon3);
        label1.setLayoutX(Map.getMapMatrixX()[delivery.getOrder().getOwner().getNode()-1]);
        label1.setLayoutY(Map.getMapMatrixY()[delivery.getOrder().getOwner().getNode()-1]);
        pane.getChildren().addAll(label1);
        pane.getChildren().addAll(label);
        pane.getChildren().addAll(DeliverYLabel);
        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                DeliverYLabel.setLayoutX(delivery.x-15);
                DeliverYLabel.setLayoutY(delivery.y-15);
//                TimeLabel.setText(order.getFinaltime() - System.currentTimeMillis() + " milliseconds");
            }
        }, 5, 15);
    }

//    public void run() {
//            String r1 = "Show Availible Orders";
//            Pattern p1 = Pattern.compile(r1);
//            String r3 = "back";
//            Pattern p3 = Pattern.compile(r3);
//            String r2 = "Show Road To Resturant";
//            Pattern p2 = Pattern.compile(r2);
//            String r4 = "SHOW BEST PATH (?<id>\\d+)";
//            Pattern p4 = Pattern.compile(r4);
//            String r5 = "CONFIRM ORDER (?<id>\\d+)";
//            Pattern p5 = Pattern.compile(r5);
//            String r6 = "Help";
//            Pattern p6 = Pattern.compile(r6);
//            String command, result;
//            while (true) {
//                command = Menu.getScanner().nextLine();
//                command = command.trim();
//                Matcher m1 = p1.matcher(command);
//                Matcher m2 = p2.matcher(command);
//                Matcher m3 = p3.matcher(command);
//                Matcher m4 = p4.matcher(command);
//                Matcher m5 = p5.matcher(command);
//                Matcher m6 = p6.matcher(command);
//
//                if (m6.matches()) {
//                    System.out.println(r1 + "\n" + r2 + "\n" + r3 + "\n" + r4 + "\n" + r5 + "\n" + r6);
//                }
//                else if ((m1.matches())) {
//                    System.out.println(deliveryManagementMenuController.ShowOrders());
//                }
//                else if (m2.matches()) {
//                    System.out.println(deliveryManagementMenuController.ShowRoad(this.delivery));
//                }
//                else if (m3.matches()) {
//                    return;
//                }
//                else if (m4.matches()) {
//                    System.out.println(deliveryManagementMenuController.ShowRoad2(m4));
//                }
//                else if (m5.matches()) {
//                    System.out.println(deliveryManagementMenuController.ConfirmOrder(m5, this.delivery));
//                } else {
//                    System.out.println("Invalid Command");
//                }
//            }
//        }
}

