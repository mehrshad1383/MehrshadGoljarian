package view;

import controller.CustomerMenuController;
import controller.LoginMenuController;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.ImagePattern;
import javafx.scene.paint.Paint;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import model.Customer;
import model.FileManager;
import javafx.scene.shape.Rectangle;
import model.Resturant;

import java.awt.*;
import java.io.IOException;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CostumerMenu extends Application {

    public static Stage stage;
    private Pane pane = new Pane();
    private Button Search = new Button("Search Restaurant");
    private  TextField textField = new TextField();
    private Button button =new Button("submit");
    private String checker="";

    private Button access = new Button("ACCESS ORDER HISTORY");

    private Button cartstatus = new Button("DISPLAY CART STATUS");

    private Button confirm = new Button("CONFIRM ORDER");
    private Button charge = new Button("CHARGE ACCOUNT");

    private Button displaycharge = new Button("DISPLAY CHARGE ACCOUNT");

    private Button delete = new Button("DELETE FOOD FROM CART");

    private Button showdelivery = new Button("SHOW DELIVERY TIME");

    private Button back =new Button("Back");
    private Label label = new Label();
    private Label showRestauranr=new Label();
    public CustomerMenuController customerMenuController;
    private Customer customer;
    private String result="";
    private int index;
    private MediaPlayer mediaPlayer;
    public CostumerMenu(){
        this.customerMenuController=new CustomerMenuController(this);
    }

    public CostumerMenu(Customer loggedcustomer,MediaPlayer mediaPlayer) {
        this.customerMenuController = new CustomerMenuController(this);
        this.customer = loggedcustomer;
        this.mediaPlayer=mediaPlayer;
    }
    @Override
    public void start(Stage stage) throws Exception {
        customer.setLoggedInCustomer(customer);
        CostumerMenu.stage=stage;
        index = Customer.returnIndexFromObject(customer);
        stage.setMaximized(true);
        //pane = FXMLLoader.load(new URL(LoginMenu.class.getResource("/FXML/CustomerMenu.fxml").toExternalForm()));
        Paint paint = new ImagePattern(new Image(LoginMenu.class.getResource("/Image/LoginMenu.JPG").toExternalForm()));
        BackgroundFill backgroundFill = new BackgroundFill(paint , CornerRadii.EMPTY, Insets.EMPTY);
        pane.setBackground(new Background(backgroundFill));
        if (stage.getScene() == null) {
            Scene scene = new Scene(pane);
            stage.setScene(scene);
        } else stage.getScene().setRoot(pane);
        buttonrunner(pane);
        ScrollPane scrollPane = new ScrollPane();
        VBox vBox = new VBox();
        vBox = customerMenuController.showallResturant(customer,vBox,mediaPlayer);
        vBox.setAlignment(Pos.TOP_RIGHT);
        vBox.setSpacing(5);
        scrollPane.setContent(vBox);
        scrollPane.setMaxSize(800,800);
        pane.getChildren().add(scrollPane);
        scrollPane.setLayoutX(780);
        scrollPane.setLayoutY(20);

        /*
        Rectangle rectangle = new Rectangle(900,70,500,500);
        rectangle.setFill(Color.YELLOW);
        result=result+customerMenuController.showallResturant(customer);
        showRestauranr.setText(result);
        showRestauranr.setStyle("-fx-text-fill: red ; -fx-font-size: 20; -fx-font-family: Arial");
        showRestauranr.setLayoutX(915);
        showRestauranr.setLayoutY(100);
        pane.getChildren().add(rectangle);
        pane.getChildren().add(showRestauranr);
         */
        back.setOnAction(event -> {
            try {
                returnnn();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
        Search.setOnAction(event ->searchRestaurant(pane));
        button.setOnAction(event -> {
            try {
                compile(pane);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });
        charge.setOnAction(event ->charge(pane));
        displaycharge.setOnAction(event ->displaycharge(pane));
        cartstatus.setOnAction(event ->displaycart(pane));
        showdelivery.setOnAction(event -> {
            try {
                ShowDelivery(pane);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });
        delete.setOnAction(event ->deleteFoodFromCart(pane));
        confirm.setOnAction(event ->confirmorder(pane));
        access.setOnAction(event -> {
            try {
                accessOrderHistory(pane);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });
        stage.show();
    }
    public void returnnn() throws IOException {
        pane.getChildren().remove(textField);
        pane.getChildren().remove(button);
        LoginMenu loginMenu = new LoginMenu();
        loginMenu.start(stage);
    }
    public void displaycharge(Pane pane){
        pane.getChildren().remove(textField);
        pane.getChildren().remove(button);
        result=customerMenuController.DisplayChargeAccount(index);
        label.setText(result);
        pane.requestFocus();
    }
    public void displaycart(Pane pane){
        pane.getChildren().remove(textField);
        pane.getChildren().remove(button);
        result=customerMenuController.DisplayCartStatus(index);
        label.setText(result);
        pane.requestFocus();
    }
    public void searchRestaurant(Pane pane){
        pane.getChildren().remove(textField);
        pane.getChildren().remove(button);
        textField.setText("");
        textField.setPromptText("Enter name of restaurant");
        pane.getChildren().add(textField);
        pane.getChildren().add(button);
        checker="Search";
        pane.requestFocus();
    }
    public void ShowDelivery(Pane pane) throws Exception {
        for(int i = 0 ; i<customer.getCompletedorders().size() ; i++)
        {
            if(customer.getCompletedorders().get(i).getStatus().equals("Delivery"))
            {
                ShowDeliveryMenu showDeliveryMenu = new ShowDeliveryMenu(customer.getCompletedorders().get(i) , mediaPlayer);
                showDeliveryMenu.start(LoginMenu.stage);
            }
        }
    }
    public void deleteFoodFromCart(Pane pane){
        pane.getChildren().remove(textField);
        pane.getChildren().remove(button);
        textField.setText("");
        textField.setPromptText("Enter id of food");
        pane.getChildren().add(textField);
        pane.getChildren().add(button);
        checker="delete";
        pane.requestFocus();
    }
    public void accessOrderHistory(Pane pane) throws Exception {
        pane.getChildren().remove(textField);
        pane.getChildren().remove(button);
        OrderHistoryMenu orderHistoryMenu = new OrderHistoryMenu(customer);
        orderHistoryMenu.start(CostumerMenu.stage);
    }
    public void compile(Pane pane) throws Exception {
        if(checker.equals("Search")){
           String name= textField.getText();
           result = customerMenuController.SearchResturant(name);
           label.setText(result);
           pane.getChildren().remove(textField);
           pane.getChildren().remove(button);
        }
        else if(checker.equals("charge")){
            double money= Double.parseDouble(textField.getText());
            customerMenuController.chargeaccount(index,money);
            label.setText("Charged successfully");
            pane.getChildren().remove(textField);
            pane.getChildren().remove(button);
        }
        else if(checker.equals("delete")){
            int id= Integer.parseInt(textField.getText());
            result=customerMenuController.DeleteCart(index,id);
            label.setText(result);
            pane.getChildren().remove(textField);
            pane.getChildren().remove(button);
        }
        else if(checker.equals("select")){
            int id= Integer.parseInt(textField.getText());
            pane.getChildren().remove(textField);
            pane.getChildren().remove(button);
            if((id-1000000)>=FileManager.getFileManagerInstance().resturants.size()||(id-1000000)<0){
                label.setText("There is no Restaurant with this id");
            }
            else {
                Resturant resturant;
                resturant = Resturant.returnResturantByIndex(index);
                ResturantMenu resturantMenu = new ResturantMenu(resturant,customer,mediaPlayer);
                resturantMenu.start(CostumerMenu.stage);
            }
        }
        else if(checker.equals("check1")){
            String command = textField.getText();
            if(command.equals("no")){
              result=customerMenuController.confirmOrder(index,customer,"",false);
              label.setText(result);
                pane.getChildren().remove(textField);
                pane.getChildren().remove(button);
            }
            else{
                getCode(pane);
            }
        }
        else if(checker.equals("confirm")){
            String code = textField.getText();
            result=customerMenuController.confirmOrder(index,customer,code,true);
            label.setText(result);
            if(result.equals("there is no discount code with this name you can try again or enter no"))
            {
                pane.getChildren().remove(textField);
                pane.getChildren().remove(button);
                confirmorder(pane);
            }

        }
    }
    public void buttonrunner(Pane pane){
        Rectangle rectangle = new Rectangle(120,240,560,350);
        rectangle.setFill(Color.web("95DA03FF"));
        pane.getChildren().add(rectangle);
        label.setLayoutY(260);
        label.setLayoutX(140);
        label.setStyle("-fx-text-fill: #ff0000;-fx-font-family: Arial;-fx-font-size: 20");
        pane.getChildren().add(label);
        Search.setLayoutY(100);
        Search.setLayoutX(80);
        Search.setStyle("-fx-background-color:rgba(32,253,143,0.65);");
        pane.getChildren().add(Search);
        charge.setLayoutX(238);
        charge.setLayoutY(180);
        charge.setStyle("-fx-background-color:rgba(32,253,143,0.65);");
        textField.setLayoutX(300);
        textField.setLayoutY(620);
        button.setLayoutX(347);
        button.setLayoutY(670);
        button.setStyle("-fx-background-color:rgba(32,253,143,0.65);");
        displaycharge.setLayoutX(580);
        displaycharge.setLayoutY(180);
        displaycharge.setStyle("-fx-background-color:rgba(32,253,143,0.65);");
        cartstatus.setLayoutX(415);
        cartstatus.setLayoutY(100);
        cartstatus.setStyle("-fx-background-color:rgba(32,253,143,0.65);");
        showdelivery.setLayoutX(410);
        showdelivery.setLayoutY(180);
        showdelivery.setStyle("-fx-background-color:rgba(32,253,143,0.65);");
        delete.setLayoutX(50);
        delete.setLayoutY(180);
        delete.setStyle("-fx-background-color:rgba(32,253,143,0.65);");
        back.setLayoutX(10);
        back.setLayoutY(10);
        back.setStyle("-fx-background-color:rgba(32,253,143,0.65);");
        access.setLayoutX(230);
        access.setLayoutY(100);
        access.setStyle("-fx-background-color:rgba(32,253,143,0.65);");
        confirm.setLayoutX(600);
        confirm.setLayoutY(100);
        confirm.setStyle("-fx-background-color:rgba(32,253,143,0.65);");
        pane.getChildren().add(confirm);
        pane.getChildren().add(access);
        pane.getChildren().add(delete);
        pane.getChildren().add(back);
        pane.getChildren().add(showdelivery);
        pane.getChildren().add(charge);
        pane.getChildren().add(displaycharge);
        pane.getChildren().add(cartstatus);
    }
    public void charge(Pane pane){
        pane.getChildren().remove(textField);
        pane.getChildren().remove(button);
        textField.setText("");
        textField.setPromptText("Enter amount of money");
        pane.getChildren().add(textField);
        pane.getChildren().add(button);
        checker="charge";
        pane.requestFocus();
    }
    public void confirmorder(Pane pane){
        pane.getChildren().remove(textField);
        pane.getChildren().remove(button);
        textField.setText("");
        if(FileManager.getFileManagerInstance().customers.get(index).getCarts().size()==0){
            label.setText("Your cart is empty");
        }
        else if(customer.getAccountmoney()<FileManager.getFileManagerInstance().customers.get(index).getCarts().get(0).getCost()){
            label.setText("Your account is low, please top up your account first Or delete sth from your cart");
        }
        else{
            textField.setPromptText("if you want enter discount code enter yes otherwise, enter no");
            pane.getChildren().add(textField);
            pane.getChildren().add(button);
            checker="check1";
        }
        pane.requestFocus();
    }
    public void getCode(Pane pane){
        pane.getChildren().remove(textField);
        pane.getChildren().remove(button);
        textField.setText("");
        textField.setPromptText("Enter your discount food");
        pane.getChildren().add(textField);
        pane.getChildren().add(button);
        checker = "confirm";
        pane.requestFocus();
    }
}
    /*
    public void run()
    {
        customerMenuController.showallResturant(customer);
        String r1 = "SEARCH RESTAURANT (?<resturantname>((\\w)|((\\s)|(\\W)))*)";
        Pattern p1 = Pattern.compile(r1);
        String r2 = "SELECT (?<resturantid>(\\d)*)";
        Pattern p2 = Pattern.compile(r2);
        String r3 = "back";
        Pattern p3 = Pattern.compile(r3);
        String r4 = "ACCESS ORDER HISTORY";
        Pattern p4 = Pattern.compile(r4);
        String r5 = "DISPLAY CART STATUS";
        Pattern p5 = Pattern.compile(r5);
        String r6 = "CONFIRM ORDER";
        Pattern p6 = Pattern.compile(r6);
        String r7 = "Help";
        Pattern p7 = Pattern.compile(r7);
        String r8 = "CHARGE ACCOUNT";
        Pattern p8 = Pattern.compile(r8);
        String r9 = "DISPLAY ACCOUNT CHARGE";
        Pattern p9 = Pattern.compile(r9);
        String r10 = "DELETE (?<IDFOOD>(\\d)*) FROM CART";
        Pattern p10 = Pattern.compile(r10);
        String r11 = "SHOW DELIVERY TIME";
        Pattern p11 = Pattern.compile(r11);
        String command ,result;
        while (true) {
           command = Menu.getScanner().nextLine();
           command = command.trim();
           Matcher m1 = p1.matcher(command);
           Matcher m2 = p2.matcher(command);
           Matcher m3 = p3.matcher(command);
           Matcher m4 = p4.matcher(command);
           Matcher m5 = p5.matcher(command);
           Matcher m6 = p6.matcher(command);
           Matcher m7 = p7.matcher(command);
           Matcher m8 = p8.matcher(command);
           Matcher m9 = p9.matcher(command);
           Matcher m10 = p10.matcher(command);
           Matcher m11 = p11.matcher(command);
           if(m1.matches()){
               String name = m1.group("resturantname");
               result = customerMenuController.SearchResturant(name);
               System.out.println(result);
           }
           else if(m2.matches()){
               int id = Integer.parseInt(m2.group("resturantid"));
               if(customerMenuController.returnindexbyid(id)<0){
                   System.out.println("There is no resturant with this id");
               }
               else {
                    customerMenuController.Select(customerMenuController.returnindexbyid(id),customer);
               }
           }
           else if(m3.matches()){
               break;
           }
           else if(m4.matches()){
               OrderHistoryMenu orderHistoryMenu = new OrderHistoryMenu(customer);
               orderHistoryMenu.run(customer);
           }
           else if(m5.matches()){
               int index = Customer.returnIndexFromObject(customer);
               customerMenuController.DisplayCartStatus(index);
           }
           else if(m6.matches()){
               int index = Customer.returnIndexFromObject(customer);
               customerMenuController.confirmOrder(index,customer);
           }
           else if (command.trim().equals("WHERE AM I")) {
               System.out.println("CustomerMenu");
           }
           else if(m7.matches()){
               System.out.println("if the amount of your order is more than 20000, you will be given a discount code of ten percent of your order, which you can use in your next purchases.");
               System.out.println("Available options :");
               System.out.println("SEARCH RESTAURANT <resturantname>");
               System.out.println("SELECT <resturantid>");
               System.out.println(r4);
               System.out.println(r5);
               System.out.println(r6);
               System.out.println(r3);
               System.out.println(r8);
               System.out.println(r9);
               System.out.println("DELETE <IDFOOD> FROM CART");
               System.out.println(r11);
           }
           else if(m8.matches()){
               int index = Customer.returnIndexFromObject(customer);
               customerMenuController.chargeaccount(index);
           }
           else if(m9.matches()){
               int index = Customer.returnIndexFromObject(customer);
               customerMenuController.DisplayChargeAccount(index);
           }
           else if(m10.matches()){
               int id = Integer.parseInt(m10.group("IDFOOD"));
               int index = Customer.returnIndexFromObject(customer);
                customerMenuController.DeleteCart(index,id);
           }
           else if(m11.matches())
           {
               System.out.println(CustomerMenuController.ShowDeliveryTime(customer));
           }
           else{
               System.out.println("Invalid command");
           }
        }
        }
    }
*/
