package view;

import controller.CustomerMenuController;
import controller.ResturantMenuController;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import model.Customer;
import model.FileManager;
import model.Resturant;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ResturantMenu extends Application {

    private ResturantMenuController resturantMenuController;

    private Resturant resturant;
    public static Stage stage;
    private Customer customer;
    private ScrollPane scrollpanee =new ScrollPane();
    private String checker="";
    private TextField textField = new TextField();
    private Button Search = new Button("Search FOOD");
    private Button button =new Button("submit");
    private Button newcomment = new Button("ADD NEW COMMENT");
    private Button editCommit = new Button("EDIT COMMIT");
    private Button subrate = new Button("SUBMIT RATING");
    private Button editrating = new Button("EDIT RATING");
    private Button displaycomment = new Button("DISPLAY COMMENT");
    private int index;
    private Label label = new Label();
    private Button back =new Button("Back");
    private Pane pane = new Pane();
    private MediaPlayer mediaPlayer;

    public ResturantMenu(Resturant resturant,Customer customer,MediaPlayer mediaPlayer) {
        this.resturantMenuController = new ResturantMenuController(this);
        this.customer=customer;
        this.resturant = resturant;
        this.mediaPlayer=mediaPlayer;
    }

    @Override
    public void start(Stage stage) throws Exception {
        ResturantMenu.stage=stage;
        index = Resturant.ReturnIndexFromRestaurant(resturant);
        stage.setMaximized(true);
        //pane = FXMLLoader.load(new URL(LoginMenu.class.getResource("/FXML/CustomerMenu.fxml").toExternalForm()));
        Paint paint = new ImagePattern(new Image(LoginMenu.class.getResource("/Image/LoginMenu.JPG").toExternalForm()));
        BackgroundFill backgroundFill = new BackgroundFill(paint , CornerRadii.EMPTY, Insets.EMPTY);
        pane.setBackground(new Background(backgroundFill));
        if (stage.getScene() == null) {
            Scene scene = new Scene(pane);
            stage.setScene(scene);
        } else stage.getScene().setRoot(pane);
        buttonrunner(pane);
        ScrollPane scrollPane = new ScrollPane();
        VBox vBox = new VBox();
        vBox = resturantMenuController.showListFood(index,vBox,resturant,mediaPlayer);
        vBox.setAlignment(Pos.TOP_RIGHT);
        vBox.setSpacing(5);
        scrollPane.setContent(vBox);
        scrollPane.setMaxSize(800,800);
        if(vBox.getChildren().size()!=0)
            pane.getChildren().add(scrollPane);
        else{
            ImageView imageView = new ImageView();
            imageView.setX(850);
            imageView.setY(200);
            Image imagepoker = new Image(LoginMenu.class.getResource("/Image/poker.png").toExternalForm());
            imageView.setImage(imagepoker);
            Rectangle rectangle = new Rectangle(930,100,360,50);
            rectangle.setFill(Color.web("#226537"));
            Label label1 = new Label("THERE IS NO FOOD");
            label1.setLayoutX(970);
            label1.setLayoutY(112);
            label1.setStyle("-fx-font-family: Arial;-fx-text-fill: red;-fx-font-size: 25");
            pane.getChildren().add(rectangle);
            pane.getChildren().add(label1);
            pane.getChildren().add(imageView);
        }
        scrollPane.setLayoutX(780);
        scrollPane.setLayoutY(20);
        Search.setOnAction(event ->searchRestaurant(pane));
        editCommit.setOnAction(event -> editcomment(pane));
        newcomment.setOnAction(event -> addNewComment(pane));
        displaycomment.setOnAction(event -> {
            try {
                DisplayComment(pane);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
        editrating.setOnAction(event -> editrate(pane));
        subrate.setOnAction(event -> subrating(pane));
        button.setOnAction(event -> {
            try {
                compile(pane);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });
        back.setOnAction(event -> {
            try {
                returnnn();
            } catch (IOException e) {
                throw new RuntimeException(e);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });
        stage.show();
    }
    public void returnnn() throws Exception {
        pane.getChildren().remove(label);
        pane.getChildren().remove(scrollpanee);
        pane.getChildren().remove(textField);
        pane.getChildren().remove(button);
        CostumerMenu costumerMenu = new CostumerMenu(customer,mediaPlayer);
        costumerMenu.start(LoginMenu.stage);
    }
    public void subrating(Pane pane){
        pane.getChildren().remove(scrollpanee);
        pane.getChildren().remove(label);
        pane.getChildren().add(label);
        int indexOfcomment = Resturant.CheckForHisRating(customer,index);
        if(indexOfcomment<0){
            label.setText("Please write your comment first Then give your score from 0 to 10");
            pane.requestFocus();
        }
        else if(Resturant.getrating(index,indexOfcomment)>0){
            label.setText("You already rated it, maybe you need to edit it");
            pane.requestFocus();
        }
        else{
            label.setText("");
            checker = "subrate";
            textField.setText("");
            textField.setPromptText("num 0 to 10");
            pane.getChildren().add(textField);
            pane.getChildren().add(button);
            pane.requestFocus();
        }
    }
    public void DisplayComment(Pane pane) throws IOException {
        pane.getChildren().remove(label);
        pane.getChildren().remove(scrollpanee);
        pane.getChildren().remove(textField);
        pane.getChildren().remove(button);
        if(((Resturant)FileManager.getFileManagerInstance().resturants.get(index)).getComments().size()>0) {
            VBox vBoxx = new VBox();
            vBoxx = resturantMenuController.ShowAllCommand(index, vBoxx);
                vBoxx.setAlignment(Pos.CENTER_LEFT);
                vBoxx.setSpacing(5);
                scrollpanee.setContent(vBoxx);
                scrollpanee.setMaxSize(800, 300);
                pane.getChildren().add(scrollpanee);
                scrollpanee.setLayoutX(10);
                scrollpanee.setLayoutY(300);
        }
        else{
            pane.getChildren().remove(label);
            pane.getChildren().add(label);
            label.setText("THERE IS NO COMMENT FOR THIS RESTAURANT");
        }
        pane.getChildren().remove(textField);
        pane.getChildren().remove(button);
        pane.requestFocus();
    }
    public void editrate(Pane pane){
        pane.getChildren().remove(scrollpanee);
        pane.getChildren().remove(label);
        pane.getChildren().add(label);
        int indexOfcomment = Resturant.CheckForHisRating(customer,index);
        if(indexOfcomment<0){
            label.setText("Please write your comment first Then give your score from 0 to 10");
            pane.requestFocus();
        }
        else if(Resturant.getAllresturants().get(index).getComments().get(indexOfcomment).getRating()==-1){
            label.setText("You have not rated yet");
            pane.requestFocus();
        }
        else{
            label.setText("");
            checker = "editrate";
            textField.setText("");
            textField.setPromptText("num 0 to 10");
            pane.getChildren().add(textField);
            pane.getChildren().add(button);
            pane.requestFocus();
        }
    }
    public void addNewComment(Pane pane) {
        pane.getChildren().remove(label);
        pane.getChildren().add(label);
        pane.getChildren().remove(scrollpanee);
        pane.getChildren().remove(textField);
        pane.getChildren().remove(button);
        if (resturantMenuController.checkCommentOrNot(customer, index)) {
            label.setText("");
            checker = "newcomment";
            textField.setText("");
            textField.setPromptText("write your opinion about the restaurant");
            pane.getChildren().add(textField);
            pane.getChildren().add(button);
            pane.requestFocus();
        }
        else {
            label.setText("You already comment it, maybe you need to edit it");
        }
    }
    public void editcomment(Pane pane){
        pane.getChildren().remove(label);
        pane.getChildren().remove(scrollpanee);
        pane.getChildren().remove(textField);
        pane.getChildren().remove(button);
        textField.setText("");
        textField.setPromptText("Enter id of comment");
        pane.getChildren().add(textField);
        pane.getChildren().add(button);
        checker="Editcomment";
        pane.requestFocus();
    }
    public void buttonrunner(Pane pane){
        back.setLayoutX(10);
        back.setLayoutY(10);
        Search.setLayoutY(100);
        Search.setLayoutX(80);
        label.setLayoutY(260);
        label.setLayoutX(140);
        textField.setLayoutX(300);
        textField.setLayoutY(620);
        button.setLayoutX(347);
        newcomment.setLayoutX(230);
        newcomment.setLayoutY(100);
        newcomment.setStyle("-fx-background-color:rgba(32,253,143,0.65);");
        pane.getChildren().add(newcomment);
        editCommit.setLayoutX(600);
        editCommit.setLayoutY(100);
        subrate.setLayoutX(415);
        subrate.setLayoutY(100);
        subrate.setStyle("-fx-background-color:rgba(32,253,143,0.65);");
        displaycomment.setLayoutX(420);
        displaycomment.setLayoutY(180);
        displaycomment.setStyle("-fx-background-color:rgba(32,253,143,0.65);");
        pane.getChildren().add(displaycomment);
        editrating.setLayoutX(270);
        editrating.setLayoutY(180);
        editrating.setStyle("-fx-background-color:rgba(32,253,143,0.65);");
        pane.getChildren().add(editrating);
        pane.getChildren().add(subrate);
        editCommit.setStyle("-fx-background-color:rgba(32,253,143,0.65);");
        pane.getChildren().add(editCommit);
        button.setLayoutY(670);
        button.setStyle("-fx-background-color:rgba(32,253,143,0.65);");
        label.setStyle("-fx-text-fill: #ff0000;-fx-font-family: Arial;-fx-font-size: 20");
        pane.getChildren().add(label);
        Search.setStyle("-fx-background-color:rgba(32,253,143,0.65);");
        pane.getChildren().add(Search);
        back.setStyle("-fx-background-color:rgba(32,253,143,0.65);");
        pane.getChildren().add(back);
    }
    public void searchRestaurant(Pane pane){
        pane.getChildren().remove(scrollpanee);
        label.setText("");
        pane.getChildren().remove(scrollpanee);
        pane.getChildren().remove(textField);
        pane.getChildren().remove(button);
        textField.setText("");
        textField.setPromptText("Enter name of restaurant");
        pane.getChildren().add(textField);
        pane.getChildren().add(button);
        checker="Search";
        pane.requestFocus();
    }
    public void compile(Pane pane) throws Exception {
        int id=0;
        int indexOfcomment = Resturant.CheckForHisRating(customer,index);
        pane.getChildren().remove(label);
        pane.getChildren().remove(textField);
        pane.getChildren().remove(button);
        pane.getChildren().remove(scrollpanee);
        if (checker.equals("Search")) {
            String name = textField.getText();
            VBox vBoxx = new VBox();
            vBoxx = resturantMenuController.SearchFood(index,name,vBoxx,resturant,mediaPlayer);
            if(vBoxx.getChildren().size()!=0) {
                vBoxx.setAlignment(Pos.CENTER_LEFT);
                vBoxx.setSpacing(5);
                scrollpanee.setContent(vBoxx);
                scrollpanee.setMaxSize(800, 800);
                pane.getChildren().add(scrollpanee);
                scrollpanee.setLayoutX(10);
                scrollpanee.setLayoutY(300);
            }
            else{
                pane.getChildren().add(label);
                label.setText("THERE IS NO FOOD WITH THIS NAME");
            }
            pane.getChildren().remove(textField);
            pane.getChildren().remove(button);
            pane.requestFocus();
        }
        else if(checker.equals("newcomment")){
            String content = textField.getText();
            resturantMenuController.ADDNewcomment(customer,index,content);
            pane.getChildren().remove(textField);
            pane.getChildren().remove(button);
            pane.getChildren().add(label);
            label.setText("Added successfully");
            pane.requestFocus();
        }
        else if(checker.equals("Editcomment")){
            pane.getChildren().add(label);
            id = Integer.parseInt(textField.getText());
            if(Resturant.ReturnNumberOfComment(index)<id){
                label.setText("There is now comment with this id");
            }
            else if(!Resturant.ReturnCustomerFromid(index,id).equals(customer)){
                label.setText("This comment is not for you");
            }
            else{
                textField.setText("");
                pane.getChildren().remove(label);
                textField.setPromptText("Enter your opinion");
                pane.getChildren().add(textField);
                pane.getChildren().add(button);
                checker="editcomment1";
            }
            pane.requestFocus();
        }
        else if(checker.equals("editcomment1")){
            String content = textField.getText();
            resturantMenuController.Editcomment(index,id,content);
            pane.getChildren().remove(textField);
            pane.getChildren().remove(button);
            pane.getChildren().add(label);
            label.setText("CHANGED SUCCESSFULLY");
            pane.requestFocus();
        }
        else if(checker.equals("subrate")){
            pane.getChildren().add(label);
            double rate = Double.parseDouble(textField.getText());
            resturantMenuController.SubmitRating(index,indexOfcomment,rate);
            label.setText("SUBMIT SUCCESSFULLY");
        }
        else if(checker.equals("editrate")){
            pane.getChildren().add(label);
            double rate = Double.parseDouble(textField.getText());
            resturantMenuController.EditRating(index,indexOfcomment,rate);
            label.setText("CHANGED SUCCESSFULLY");
        }
    }
}
    /*
    public void run(int index, Customer customer)
    {
        resturantMenuController.showListFood(index);
        String r1 = "SEARCH (?<foodname>((\\w)|((\\s)|(\\W)))*)";
        Pattern p1 = Pattern.compile(r1);
        String r2 = "SELECT (?<foodid>(\\d)*)";
        Pattern p2 = Pattern.compile(r2);
        String r3 = "DISPLAY COMMENTS";
        Pattern p3 = Pattern.compile(r3);
        String r4 = "back";
        Pattern p4 = Pattern.compile(r4);
        String r5 = "ADD NEW COMMENT";
        Pattern p5 = Pattern.compile(r5);
        String r6 = "EDIT COMMENT (?<commentid>(\\d)*)";
        Pattern p6 = Pattern.compile(r6);
        String r7 = "DISPLAY RATING";
        Pattern p7 = Pattern.compile(r7);
        String r8 = "SUBMIT RATING";
        Pattern p8 = Pattern.compile(r8);
        String r9 = "EDIT RATING";
        Pattern p9 = Pattern.compile(r9);
        String r10 = "Help";
        Pattern p10 = Pattern.compile(r10);
        String command;
        while (true) {
            command = Menu.getScanner().nextLine();
            command = command.trim();
            Matcher m1 = p1.matcher(command);
            Matcher m2 = p2.matcher(command);
            Matcher m3 = p3.matcher(command);
            Matcher m4 = p4.matcher(command);
            Matcher m5 = p5.matcher(command);
            Matcher m6 = p6.matcher(command);
            Matcher m7 = p7.matcher(command);
            Matcher m8 = p8.matcher(command);
            Matcher m9 = p9.matcher(command);
            Matcher m10 = p10.matcher(command);
            if(m1.matches()){
                String name = m1.group("foodname");
                resturantMenuController.SearchFood(index,name);
            }
            else if(m2.matches()){
                int id = Integer.parseInt(m2.group("foodid"));
                resturantMenuController.SelectFood(index,id,customer);
            }
            else if(m3.matches()){
                resturantMenuController.ShowAllCommand(index);
            }
            else if(m4.matches()){
                return;
            }
            else if(m5.matches()){
                if(resturantMenuController.checkCommentOrNot(customer,index))
                    resturantMenuController.ADDNewcomment(customer,index);
                else {
                    System.out.println("You already comment it, maybe you need to edit it");
                }
            }
            else if(m6.matches()){
                int id = Integer.parseInt(m6.group("commentid"));
                resturantMenuController.Editcomment(index,id,customer);
            }
            else if(m7.matches()){
                resturantMenuController.DisplayRating(index);
            }
            else if(m8.matches()){
                resturantMenuController.SubmitRating(customer,index);
            }
            else if(m9.matches()){
                resturantMenuController.EditRating(customer,index);
            }
            else if(m10.matches()){
                System.out.println("Available options: ");
                System.out.println("SEARCH <foodname>");
                System.out.println("SELECT <foodid>");
                System.out.println(r3);
                System.out.println(r4);
                System.out.println(r5);
                System.out.println("EDIT COMMENT <commentid>");
                System.out.println(r7);
                System.out.println(r8);
                System.out.println(r9);
            }
            else if (command.trim().equals("WHERE AM I")) {
                System.out.println("Restaurant Menu");
            }
            else{
                System.out.println("Invalid command");
            }
        }
    }
}
     */
