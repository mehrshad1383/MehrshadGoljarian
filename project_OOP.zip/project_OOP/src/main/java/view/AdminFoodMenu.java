package view;

import controller.AdminFoodMenuController;
import model.Comment;
import model.Food;
import model.Resturant;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AdminFoodMenu {
    private Food food;
    private Resturant resturant;
    private AdminFoodMenuController adminFoodMenuController;

    public AdminFoodMenu(Food a , Resturant b){
        this.food=a;
        this.resturant=b;
        this.adminFoodMenuController = new AdminFoodMenuController(this);
    }

    public void run(int indexRestaurant,int indexfood) {
        this.food=Resturant.returnFoodByIndex(indexfood+2000000,indexRestaurant+1000000);
        String command;
        System.out.println("Welcome to ("+food.getName()+") administrate manu at "+resturant.getName()+" , write next command or Help");
        Scanner scanner = Menu.getScanner();
        String r1 = "Help";
        Pattern p1 = Pattern.compile(r1);
        String r5 = "back";
        Pattern p5 = Pattern.compile(r5);
        String r2 = "DISPLAY RATING";
        Pattern p2 = Pattern.compile(r2);
        String r3 = "DISPLAY COMMENTS";
        Pattern p3 = Pattern.compile(r3);
        String r4 = "ADD NEW RESPONSE (?<id>\\d+) (?<message>((\\w)|((\\s)|(\\W)))*)";
        Pattern p4 = Pattern.compile(r4);
        String r6 = "EDIT RESPONSE (?<id>\\d+) (?<message>((\\w)|((\\s)|(\\W)))*)";
        Pattern p6 = Pattern.compile(r6);

        while (true){
            command = scanner.nextLine().trim();
            Matcher m1 = p1.matcher(command);
            Matcher m2 = p2.matcher(command);
            Matcher m3 = p3.matcher(command);
            Matcher m5 = p5.matcher(command);
            Matcher m4 = p4.matcher(command);
            Matcher m6 = p6.matcher(command);
            if(m5.matches()){
              return;
            } else if (m1.matches()) {
                System.out.println("Available options: ");
                System.out.println("DISPLAY RATING");
                System.out.println(r3);
                System.out.println("ADD NEW RESPONSE <id> <message>");
                System.out.println("EDIT RESPONSE <id> <message>");
            } else if (m2.matches()) {
                if(Resturant.RatingFood(indexRestaurant+1000000,indexfood+2000000)==-1){
                    System.out.println("no rated");
                }
                else{
                    System.out.println("RATING= "+Resturant.RatingFood(indexRestaurant+1000000,indexfood+2000000)+" from "+Resturant.numOfRatingFood(indexRestaurant+1000000,indexfood+2000000));
                }
            } else if (m3.matches()) {
                adminFoodMenuController.DisplayComments(food);
            } else if (m4.matches()) {
                adminFoodMenuController.ADDResponse(food,m4);
            } else if (m6.matches()) {
                adminFoodMenuController.EditResponse(food,m6);
            } else if (command.trim().equals("WHERE AM I")) {
                System.out.println("AdminFoodMenu");
            }else {
                System.out.println("Invalid Command");
            }
        }
    }
}
