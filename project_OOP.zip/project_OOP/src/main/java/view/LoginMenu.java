package view;
import controller.CustomerMenuController;
import controller.LoginMenuController;
import controller.RegisterMenuController;
import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.Pane;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.ImagePattern;
import javafx.scene.paint.Paint;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import model.Customer;
import model.Delivery;
import model.FileManager;
import model.ResturantOwner;

import javax.swing.*;
import java.io.IOException;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class  LoginMenu extends Application {

    public static Stage stage;
    private Label error = new Label();

    private Pane pane;
    @FXML
    private TextField Captcha;
    @FXML
    private CheckBox visibility;
    @FXML
    private Button register;
    private MediaPlayer mediaPlayer;

    private Button SecurityAnswer= new Button("forgot password");
    @FXML
    private PasswordField PasswordField;
    @FXML
    private TextField UserField;
    @FXML
    private ChoiceBox<String> EnterAs;
    private String[] Choices = {"Admin" , "User" , "Delivery"};
    @FXML
    private Button submit;

    private static int rand;
    private LoginMenuController loginMenuController = new LoginMenuController(this);
    private CostumerMenu costumerMenu;
    static int delayTime;

    public LoginMenu(LoginMenuController loginMenuController) {
        this.loginMenuController = loginMenuController;
    }
    public LoginMenu(MediaPlayer mediaPlayer) {
        this.mediaPlayer=mediaPlayer;
    }
    public LoginMenu(){

    }

    static void delayForWrongPassword() {
        if (delayTime < 15000)
            delayTime += 5000;
//
        System.out.println("The system is locked for " + delayTime / 1000 + " seconds. please don't type anything until the sleep time ends.");

        try {
            Thread.sleep(delayTime);
        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
        }

    }
    public void start(Stage stage) throws IOException
    {
        LoginMenu.stage = stage;
        stage.setMaximized(true);
        pane = FXMLLoader.load(new URL(LoginMenu.class.getResource("/FXML/LoginMenu.fxml").toExternalForm()));
        Paint paint = new ImagePattern(new Image(LoginMenu.class.getResource(Main.photLocation).toExternalForm()));
        BackgroundFill backgroundFill = new BackgroundFill(paint , CornerRadii.EMPTY, Insets.EMPTY);
        pane.setBackground(new Background(backgroundFill));
        ImageView imageView = new ImageView();
        imageView.setX(46);
        imageView.setY(450);
        Image imageCaptcha = new Image(LoginMenu.class.getResource(model.Captcha.getCaptcha().get(rand)).toExternalForm());
        imageView.setImage(imageCaptcha);
        pane.getChildren().add(imageView);
        if (stage.getScene() == null) {
            Scene scene = new Scene(pane);
            stage.setScene(scene);
        } else stage.getScene().setRoot(pane);
        SecurityAnswer.setLayoutX(46);
        SecurityAnswer.setLayoutY(270);
        SecurityAnswer.setFont( new Font("System Bold",24));
        SecurityAnswer.setMinSize(160,58);
        pane.getChildren().add(SecurityAnswer);
        SecurityAnswer.setOnAction(event -> {
            try {
                forgot();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });
        pane.getStylesheets().add(Main.class.getResource("/CSS/Goden.css").toExternalForm());
        stage.show();
    }

    @FXML
    public void initialize() throws Exception{
        EnterAs.getItems().addAll(Choices);
    }
    public void forgot() throws Exception {
        ForgotPasswordMenu forgotPasswordMenu = new ForgotPasswordMenu(mediaPlayer);
        forgotPasswordMenu.start(stage);
    }
    public void signup() throws IOException {
        RegisterMenu registerMenu = new RegisterMenu(mediaPlayer);
        registerMenu.start(stage);
    }

    public void login(MouseEvent mouseEvent) throws Exception {
        String situation = EnterAs.getValue();
        if (situation == null) {
            error.setText("Choose Who You Enter As");
        } else {
            if (situation.equals("Admin")) {
                String result ;
                    result = loginMenuController.logginResturantOwner(UserField.getText(), PasswordField.getText());
                    if (!result.equals("successful")) {
                        error.setText(result);
                        if(result.equals("Please enter your captcha correctly!"))
                        {
                            Changerand();
                            start(stage);
                        }
                    } else {
                        error.setText(result);
                        ResturantOwner resturantOwner;
                        resturantOwner=ResturantOwner.returnResturantOwnerbyname(UserField.getText());
                        AdminMenu adminMenu = new AdminMenu(resturantOwner);
                        adminMenu.start(LoginMenu.stage);
                    }
            } else if (situation.equals("User")) {
                String result ;
                    result = loginMenuController.logginCustomer(UserField.getText(), PasswordField.getText());
                    if (!result.equals("successful")) {
                        error.setText(result);
                        if(result.equals("Please enter your captcha correctly!"))
                        {
                            Changerand();
                            start(stage);
                        }
                    } else {
                        error.setText(result);
                        Customer customer;
                        customer = Customer.returncustomerbyname(UserField.getText());
                        int index = Customer.returnIndexFromObject(customer);
                        CostumerMenu costumerMenu = new CostumerMenu(customer,mediaPlayer);
                        costumerMenu.start(LoginMenu.stage);
                    }
            } else if (situation.equals("Delivery")) {
                String result ;
                    result = loginMenuController.logginDelivery(UserField.getText(), PasswordField.getText());
                    if (!result.equals("successful")) {
                        error.setText(result);
                        if(result.equals("Please enter your captcha correctly!"))
                        {
                            Changerand();
                            start(stage);
                        }
                    } else {
                        error.setText(result);
                        Delivery delivery;
                        delivery = Delivery.returnDeliverybyname(UserField.getText());
                        DeliveryManagementMenu deliveryManagementMenu = new DeliveryManagementMenu(delivery);
                       deliveryManagementMenu.start(LoginMenu.stage);
                    }
                }
        }
    }
    public void recoveryPassword()
    {

    }

    public int getRand() {
        return rand;
    }
    public TextField getCaptcha() {
        return Captcha;
    }
    public void Changerand(){
        rand = (rand+1)%8;
    }
//    public void run()
//{
//    System.out.println("Don't have an account? Whenever you want, type  (create a new account)  to enter Signup Menu.");
//    String r1 = "create a new account";
//    Pattern p1 = Pattern.compile(r1);
//    String r2 = "LOGIN ADMIN\\s+(?<nameAdmin>((\\w)|((\\s)|(\\W)))*)\\s+(?<passwordAdmin>((\\w)|((\\s)|(\\W)))*)";
//    Pattern p2 = Pattern.compile(r2);
//    String r3 = "LOGIN USER\\s+(?<nameUser>((\\w)|((\\s)|(\\W)))*)\\s+(?<passwordUser>((\\w)|((\\s)|(\\W)))*)";
//    Pattern p3 = Pattern.compile(r3);
//    String r4 = "exit";
//    Pattern p4 = Pattern.compile(r4);
//    String r5 = "Forgot password";
//    Pattern p5 = Pattern.compile(r5);
//    String r6 = "(?<nameAdmin1>((\\w)|((\\s)|(\\W)))*)\\s+ResturantOwner";
//    Pattern p6 = Pattern.compile(r6);
//    String r7 = "(?<nameCustomer1>((\\w)|((\\s)|(\\W)))*)\\s+Customer";
//    Pattern p7 = Pattern.compile(r7);
//    String r9 = "(?<nameDelivery1>((\\w)|((\\s)|(\\W)))*)\\s+Delivery";
//    Pattern p9 = Pattern.compile(r9);
//    String r8 = "LOGIN DELIVERY\\s+(?<nameDelivery>((\\w)|((\\s)|(\\W)))*)\\s+(?<passwordDelivery>((\\w)|((\\s)|(\\W)))*)";
//    Pattern p8 = Pattern.compile(r8);
//    String r10 = "Help";
//    Pattern p10 = Pattern.compile(r10);
//    String r101 = "adm-arya";
//    Pattern p101= Pattern.compile(r101);
//    String command ,result;
//    while (true){
//        command = Menu.getScanner().nextLine();
//        command = command.trim();
//        Matcher m1 = p1.matcher(command);
//        Matcher m2 = p2.matcher(command);
//        Matcher m3 = p3.matcher(command);
//        Matcher m4 = p4.matcher(command);
//        Matcher m5 = p5.matcher(command);
//        Matcher m8 = p8.matcher(command);
//        Matcher m10 = p10.matcher(command);
//        Matcher m101 = p101.matcher(command);
//        if (m1.matches())
//        {
//            System.out.println("Entered Sign up menu! (please enter name, password and node)");
//            registerMenu.run();
//        }
//        else if(m2.matches()){
//            String name = m2.group("nameAdmin");
//            String password = m2.group("passwordAdmin");
//            LoginMenuController.logginResturantOwner(name,password);
//        }
//        else if(m3.matches()){
//            String name = m3.group("nameUser");
//            String password = m3.group("passwordUser");
//            LoginMenuController.logginCustomer(name,password);
//        }
//        else if(m8.matches()){
//            String name = m8.group("nameDelivery");
//            String password = m8.group("passwordDelivery");
//            LoginMenuController.logginDelivery(name,password);
//        }
//        else if(m4.matches()){
//            FileManager.saveAllDatas();
//            return;
//        }
//        else if(m5.matches()){
//            System.out.println("please enter your name and your type (ResturantOwner or Customer or Delivery)");
//            command = Menu.getScanner().nextLine();
//            Matcher m6 = p6.matcher(command);
//            Matcher m7 = p7.matcher(command);
//            Matcher m9 = p9.matcher(command);
//            if(!m6.matches()&&!m7.matches()&&!m9.matches()){
//                System.out.println("False Format Please be more careful with the spelling of words");
//            }
//            else{
//                if(m6.matches()) {
//                    String name = m6.group("nameAdmin1");
//                    if (ResturantOwner.printindexbyResturantOwnername(name) > -1) {
//                        System.out.println("Security question: Write down your day, month, and year of birth");
//                        command = Menu.getScanner().nextLine();
//                        if (!ResturantOwner.checksecurityquestion(name, command)) {
//                            System.out.println("no match");
//                        } else {
//                            System.out.println("match! please enter new password");
//                            while (true) {
//                                command = Menu.getScanner().nextLine();
//                                result = loginMenuController.setANewPassword(command);
//                                if (!result.equals("Your account has been successfully created")) {
//                                    System.out.println(result);
//                                } else {
//                                    System.out.println("Your password has been changed successfully.");
//                                    ResturantOwner.setnewpassword(command, ResturantOwner.printindexbyResturantOwnername(name));
//                                    break;
//                                }
//                            }
//                        }
//                    }
//                    else{
//                        System.out.println("There is no account with this name");
//                    }
//                }
//                else if(m7.matches()) {
//                    String name = m7.group("nameCustomer1");
//                    if (Customer.printindexbycustomname(name) > -1) {
//                        System.out.println("Security question: Write down your day, month, and year of birth");
//                        command = Menu.getScanner().nextLine();
//                        if (!Customer.checksecurityquestion(name, command)) {
//                            System.out.println("no match");
//                        } else {
//                            System.out.println("match! please enter new password");
//                            while (true) {
//                                command = Menu.getScanner().nextLine();
    //                       result = loginMenuController.setANewPassword(command);
    //                              if (!result.equals("Your account has been successfully created")) {
//                                    System.out.println(result);
//                               } else {
//                                    System.out.println("Your password has been changed successfully.");
//                                    Customer.setnewpassword(command, Customer.printindexbycustomname(name));
//                                    break;
//                                }
//                            }
//                        }
//                    }
//                    else {
//                        System.out.println("There is no account with this name");
//                    }
//                }
//                else {
//                    String name = m9.group("nameDelivery1");
//                    if (Delivery.printindexbydeliveryname(name) > -1) {
//                        System.out.println("Security question: Write down your day, month, and year of birth");
//                        command = Menu.getScanner().nextLine();
//                        if (!Delivery.checksecurityquestion(name, command)) {
//                            System.out.println("no match");
//                        } else {
//                            System.out.println("match! please enter new password");
//                            while (true) {
//                                command = Menu.getScanner().nextLine();
//                                result = loginMenuController.setANewPassword(command);
//                                if (!result.equals("Your account has been successfully created")) {
//                                    System.out.println(result);
//                                } else {
//                                    System.out.println("Your password has been changed successfully.");
//                                    Delivery.setnewpassword(command, Delivery.printindexbydeliveryname(name));
//                                    break;
//                                }
//                            }
//                        }
//                    }
//                    else{
//                        System.out.println("There is no account with this name");
//                    }
//                }
//            }
//        } else if (m101.matches()) {
//            ResturantOwner resturantOwner = ResturantOwner.returnResturantOwnerbyname("admin_arya");
//            AdminMenu adminMenu = new AdminMenu(resturantOwner);
//            adminMenu.run();
//        } else if (command.trim().equals("WHERE AM I")) {
//            System.out.println("LoginMenu");
//        }
//        else if(m10.matches()){
//            System.out.println("Available options: ");
//            System.out.println(r1);
//            System.out.println("LOGIN ADMIN <NameAdmin> <PasswordAdmin>");
//            System.out.println("LOGIN USER <NameUser> <PasswordUser>");
//            System.out.println(r4);
//            System.out.println(r5);
//            System.out.println("LOGIN DELIVERY <NameDelivery> <PasswordDelivery>");
//        }
//        else{
//            System.out.println("Invalid Command");
//        }
//    }
//
//}

}

