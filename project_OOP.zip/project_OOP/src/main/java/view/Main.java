package view;

import controller.CustomerMenuController;
import controller.LoginMenuController;
import javafx.application.Application;
import javafx.stage.Stage;
import model.*;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Random;

import static view.LoginMenu.stage;

public class Main extends Application {
    public static String gold="-fx-background-color: rgb(188,158,93);" ;
    public static String dark ="-fx-background-color: rgb(35,36,39);";
    public static String photLocation = "/Image/gold.JPG";

    public static Stage stage;
    static FileManager fileManager;
    public static AdminResturantMenu adminResturantMenu;

    //    public static void main(String[] args) throws IOException {
//        FileManager.loadAllDatas();
//        LoginMenuController loginMenuController = new LoginMenuController();
//        LoginMenu loginMenu = new LoginMenu(loginMenuController);
//        loginMenu.start(stage);
//        FileManager.saveAllDatas();
//        FileManager.BackUp();
//    }
    String path = "music.mp3";
    Media sound = new Media(new File(path).toURI().toString());
    public  static  MediaPlayer mediaPlayer ;

    @Override
    public void start(Stage stage) throws Exception {
        Main.stage=stage;
        mediaPlayer= new MediaPlayer(sound);
//        mediaPlayer.play();

        FileManager.loadAllDatas();
        LoginMenu loginMenu = new LoginMenu(mediaPlayer);
        loginMenu.start(stage);
        FileManager.saveAllDatas();
        FileManager.BackUp();
    }
}