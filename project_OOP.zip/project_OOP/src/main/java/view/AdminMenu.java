package view;

import controller.AdminMenuController;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.paint.ImagePattern;
import javafx.scene.paint.Paint;
import javafx.stage.Stage;
import model.*;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AdminMenu extends Application {
    private AdminMenuController adminMenuController;
    private ResturantOwner resturantOwner;
    public AdminMenu(ResturantOwner loggedResturantOwner) {
        this.adminMenuController = new AdminMenuController(this);
        this.resturantOwner=loggedResturantOwner;
    }
    public ResturantOwner getResturantOwner(){
        return resturantOwner;
    }
//    public void run()
//    {
//        Matcher matcher;
//        String command ;
//        System.out.println("Welcome "+ resturantOwner.getName() +" to Admin menu");
//        adminMenuController.ShowOwnRestaurant(resturantOwner);
//        System.out.println("Write your next command or write Help");
//        Scanner scanner = Menu.getScanner();
//        String r1 = "Help";
//        Pattern p1 = Pattern.compile(r1);
//        String r5 = "back";
//        Pattern p5 = Pattern.compile(r5);
//        String r2 = "Create new restaurant";
//        Pattern p2 = Pattern.compile(r2);
//        String r3 = "SELECT (?<restaurantID>(\\d)+)";
//        Pattern p3 = Pattern.compile(r3);
//        while (true){
//            command = scanner.nextLine().trim();
//            Matcher m1 = p1.matcher(command);
//            Matcher m2 = p2.matcher(command);
//            Matcher m3 = p3.matcher(command);
//            Matcher m5 = p5.matcher(command);
//            if (m1.matches())
//            {
//                System.out.println("Available options :");
//                System.out.println("Create new restaurant");
//                System.out.println("SELECT <restaurant_id>");
//            } else if (m2.matches()) {
//                System.out.println("Write restaurant name");
//                adminMenuController.CreateRestaurant(resturantOwner);
//            } else if (m3.matches()) {
//                int id = Integer.parseInt(m3.group("restaurantID"));
//                adminMenuController.SelectResturant(id);
//            }
//            else if(m5.matches()){
//                return;
//            } else if (command.trim().equals("WHERE AM I")) {
//                System.out.println("AdminMenu");
//            } else {
//                System.out.println("Invalid Command");
//            }
//        }
//
//    }

    @Override
    public void start(Stage stage) throws Exception {
        Pane pane = new Pane();
        stage.setMaximized(true);
        Paint paint = new ImagePattern(new Image(LoginMenu.class.getResource("/Image/gold.JPG").toExternalForm()));
        BackgroundFill backgroundFill = new BackgroundFill(paint , CornerRadii.EMPTY, Insets.EMPTY);
        pane.setBackground(new Background(backgroundFill));
        if (stage.getScene() == null) {
            Scene scene = new Scene(pane);
            stage.setScene(scene);
        } else stage.getScene().setRoot(pane);
        ScrollPane scrollPane = new ScrollPane();
        VBox vBox = new VBox();
        vBox = adminMenuController.getVbox();
        vBox.setAlignment(Pos.TOP_RIGHT);
        vBox.setSpacing(2);
        vBox.setStyle("  -fx-background-color:rgb(188,158,93);");
        scrollPane.setContent(vBox);
        scrollPane.setMaxSize(850,800);
        scrollPane.setStyle("-fx-background-color:rgb(188,158,93);");
        pane.getChildren().add(scrollPane);
        scrollPane.setLayoutX(20);
        scrollPane.setLayoutY(20);
        Button button = new Button();
        button.setText("BACK");
        button.setMinSize(200,50);
        button.setLayoutX(1330);
        button.setLayoutY(720);
        button.setStyle(Main.gold);
        pane.getChildren().add(button);
        button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    new LoginMenu().start(stage);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        });
        for (int i = 0; i < adminMenuController.restauranttmps.size(); i++) {
            int finalI = i;
            ((Button)adminMenuController.restauranttmps.get(i).getInstance().getChildren().get(5)).setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    new AdminResturantMenu(resturantOwner,adminMenuController.restauranttmps.get(finalI).resturant);
                }
            });
        }
        stage.show();


    }
}
