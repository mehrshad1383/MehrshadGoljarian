package view;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.Pane;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Line;
import javafx.scene.shape.StrokeType;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import model.Map;
import model.Order;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

public class ShowDeliveryMenu extends Application {

    public static ArrayList<Integer> newbie1;
    private MediaPlayer mediaPlayer;
    public static ArrayList<Integer> newbie2;
    public static Label TimeLabel = new Label();
    private Order order;
    public ImageView icon = new ImageView();
    public ImageView icon2 = new ImageView();
    public ImageView icon3 = new ImageView();
    public Button back = new Button("back");

    public ShowDeliveryMenu()
    {

    }
    public ShowDeliveryMenu(Order order , MediaPlayer mediaPlayer)
    {
        this.order = order;
        newbie1 = order.getDistanceFromDeliveryToResturant();
        newbie2 = order.getDistanceFromDeliveryToCustomer();
        this.mediaPlayer = mediaPlayer;
    }
    public static Pane pane;
    public static Stage stage;
    public void start(Stage stage) throws Exception
    {
        System.out.println(newbie1.get(0));
        System.out.println(newbie2.get(0));
        TimeLabel.setLayoutX(650);
        TimeLabel.setLayoutY(10);
        TimeLabel.setPrefWidth(300);
        TimeLabel.setPrefHeight(100);
        this.stage = stage;
        stage.setMaximized(true);
        pane = FXMLLoader.load(new URL(LoginMenu.class.getResource("/FXML/ShowD.fxml").toExternalForm()));
        Paint paint = new ImagePattern(new Image(LoginMenu.class.getResource("/Image/map.JPG").toExternalForm()));
        BackgroundFill backgroundFill = new BackgroundFill(paint , CornerRadii.EMPTY, Insets.EMPTY);
        pane.setBackground(new Background(backgroundFill));
        pane.setPickOnBounds(true);
        Image pp = new Image(LoginMenu.class.getResource("/Image/delivery.PNG").toExternalForm());
        Image pp2 = new Image(LoginMenu.class.getResource("/Image/resturant.PNG").toExternalForm());
        Image pp3 = new Image(LoginMenu.class.getResource("/Image/customer.PNG").toExternalForm());
        icon.setImage(pp);
        icon.setFitHeight(30);
        icon.setFitWidth(30);
        icon2.setImage(pp2);
        icon2.setFitHeight(30);
        icon2.setFitWidth(30);
        icon2.setX(30);
        icon2.setY(30);
        icon3.setImage(pp3);
        icon3.setFitHeight(30);
        icon3.setFitWidth(30);
        icon3.setX(30);
        icon3.setY(30);
        Label label = new Label();
        label.setGraphic(icon);
        Label label2 = new Label();
        label2.setGraphic(icon2);
        Label label3 = new Label();
        label3.setGraphic(icon3);
        label2.setLayoutX(Map.getMapMatrixX()[order.getOwner().getNode()-1]-15);
        label2.setLayoutY(Map.getMapMatrixY()[order.getOwner().getNode()-1]-15);
        label3.setLayoutX(Map.getMapMatrixX()[order.getResturant().getLocation().getNode()-1]-15);
        label3.setLayoutY(Map.getMapMatrixY()[order.getResturant().getLocation().getNode()-1]-15);
        label.setLayoutX(order.getDelivery().x-15);
        label.setLayoutY(order.getDelivery().y-15);
        pane.getChildren().add(label2);
        pane.getChildren().add(label3);
        pane.getChildren().add(label);
        TimeLabel.setText(order.getFinaltime() - System.currentTimeMillis() + " milliseconds");
        back.setLayoutX(10);
        back.setLayoutY(10);
        back.setOnAction(event -> {
                    try {
                        mmd();
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                }
        );
        for(int i = 0 ; i<newbie1.size()-1 ; i++)
        {
            Line line = new Line(Map.getMapMatrixX()[newbie1.get(i)-1], Map.getMapMatrixY()[newbie1.get(i)-1]
                    ,Map.getMapMatrixX()[newbie1.get(i+1)-1] , Map.getMapMatrixY()[newbie1.get(i+1)-1]);
            line.setStrokeType(StrokeType.OUTSIDE);
            if(trafic(newbie1.get(i+1) , newbie1.get(i)).equals("Yellow")){
                line.setStroke(Color.YELLOW);}
            else if(trafic(newbie1.get(i+1) , newbie1.get(i)).equals("Red")){
                line.setStroke(Color.RED);}
            else{
                line.setStroke(Color.BLUE);}
            line.setStrokeWidth(3);
            pane.getChildren().addAll(line);
        }
        for(int i = 0 ; i<newbie2.size()-1 ; i++)
        {
            Line line = new Line(Map.getMapMatrixX()[newbie2.get(i)-1], Map.getMapMatrixY()[newbie2.get(i)-1]
                    ,Map.getMapMatrixX()[newbie2.get(i+1)-1] , Map.getMapMatrixY()[newbie2.get(i+1)-1]);
            line.setStrokeType(StrokeType.OUTSIDE);
            if(trafic(newbie2.get(i+1) , newbie2.get(i)).equals("Yellow")){
                line.setStroke(Color.YELLOW);}
            else if(trafic(newbie2.get(i+1) , newbie2.get(i)).equals("Red")){
                line.setStroke(Color.RED);}
            else{
                line.setStroke(Color.BLUE);}
            line.setStrokeWidth(3);
            pane.getChildren().addAll(line);
        }
        pane.getChildren().add(TimeLabel);
        pane.getChildren().add(back);

        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                label.setLayoutX(order.getDelivery().x-15);
                label.setLayoutY(order.getDelivery().y-15);
//                TimeLabel.setText(order.getFinaltime() - System.currentTimeMillis() + " milliseconds");
            }
        }, 5, 15);
//        pane.setOnMouseClicked(e -> {
////            Circle circle = new Circle();
////            circle.setCenterX(e.getX());
////            circle.setCenterY(e.getY());
////            circle.setRadius(5);
////            circle.setStroke(Color.DARKSLATEGREY);
////            System.out.println("["+e.getX()+", "+e.getY()+"]");
////            pane.getChildren().add(circle);
//            try {
//                start(stage);
//            } catch (IOException ex) {
//                throw new RuntimeException(ex);
//            } catch (Exception ex) {
//                throw new RuntimeException(ex);
//            }
//        });
        if (stage.getScene() == null) {
            Scene scene = new Scene(pane);
            stage.setScene(scene);
        } else stage.getScene().setRoot(pane);
        stage.show();
    }

    private void mmd() throws Exception {
        CostumerMenu costumerMenu = new CostumerMenu(order.getOwner() ,mediaPlayer );
        costumerMenu.start(stage);
    }

    public String trafic(int node1 , int node2)
    {
        if(Map.MapMatrixV2[node1][node2] - Map.getMapMatrix()[node1][node2] == 2)
        {
            return "Red";
        }
        if(Map.MapMatrixV2[node1][node2] - Map.getMapMatrix()[node1][node2] == 1)
        {
            return "Yellow";
        }

        return "Blue";
    }
}
