package view;

import controller.AdminMenuController;
import controller.AdminResturantMenuController;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.paint.ImagePattern;
import javafx.scene.paint.Paint;
import javafx.stage.Stage;
import model.*;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static java.util.regex.Pattern.compile;

public class  AdminResturantMenu extends Application {
    private AdminResturantMenuController adminResturantMenuController;
    private ResturantOwner resturantOwner;
    private Resturant resturant;
    public VBox changeBox;
    public AdminResturantMenuController getAdminResturantMenuController(){ return adminResturantMenuController;}
    public AdminResturantMenu(ResturantOwner resturantOwner, Resturant resturant) {
        this.resturant=resturant;
        this.resturantOwner=resturantOwner;
        adminResturantMenuController=new AdminResturantMenuController(this);
    }
    public void run(int indexRestaurant){
        resturant.UpdateOrders();
        String command;

        System.out.println("Welcome "+resturantOwner.getName()+" to "+resturant.getName()+" administrate menu, Write command or Help.");
        Scanner scanner = Menu.getScanner();
        String r1 = "Help";
        Pattern p1 = compile(r1);
        String r5 = "back";
        Pattern p5 = compile(r5);
        String r2 = "SHOW LOCATION";
        Pattern p2 = compile(r2);
        String r3 = "EDIT LOCATION";
        Pattern p3 = compile(r3);
        String r4 = "SHOW FOODTYPE";
        Pattern p4 = compile(r4);
        String r6 = "EDIT FOODTYPE(?<tps>.+)";
        Pattern p6 = compile(r6);
        String r7 = "SELECT MENU";
        Pattern p7= compile(r7);
        String r8 = "EDIT FOOD (?<id>\\d+) NAME (?<newName>.+)";
        Pattern p8= compile(r8);
        String r9 = "EDIT FOOD (?<id>\\d+) PRICE (?<newPrice>.+)";
        Pattern p9= compile(r9);
        String r10 = "EDIT FOOD (?<id>\\d+) DISCOUNT (?<newDiscount>.+)";
        Pattern p10= compile(r10);
        String r11 = "ADD FOOD (?<name>\\S+) (?<price>\\S+)";
        Pattern p11 = compile(r11);
        String r12 = "DELETE FOOD (?<id>\\d+)";
        Pattern p12 = compile(r12);
        String r13 = "DEACTIVE FOOD (?<id>\\d+)";
        Pattern p13 = compile(r13);
        String r14 = "ACTIVE FOOD (?<id>\\d+)";
        Pattern p14 = compile(r14);
        String r15 = "DISCOUNT FOOD (?<ID>\\d+) (?<PERCENT>\\S+) (?<TIMESTAMP>\\S+)";
        Pattern p15 = compile(r15);
        String r16 = "SELECT FOOD (?<id>\\d+)";
        Pattern p16 = compile(r16);
        String r17 = "DISPLAY OPEN ORDERS";
        Pattern p17 = compile(r17);
        String r18 ="EDIT ORDER (?<id>\\d+) STATUS";
        Pattern p18 = compile(r18);
        String r20 ="CONFIRM ORDER (?<id>\\d+)";
        Pattern p20 = compile(r20);
        String r19 = "SHOW ORDER HISTORY";
        Pattern p19 = compile(r19);
        while (true) {
            command = scanner.nextLine().trim();
            Matcher m1 = p1.matcher(command);
            Matcher m2 = p2.matcher(command);
            Matcher m3 = p3.matcher(command);
            Matcher m4 = p4.matcher(command);
            Matcher m5 = p5.matcher(command);
            Matcher m6 = p6.matcher(command);
            Matcher m7 = p7.matcher(command);
            Matcher m8 = p8.matcher(command);
            Matcher m9 = p9.matcher(command);
            Matcher m10 = p10.matcher(command);
            Matcher m14 = p14.matcher(command);
            Matcher m13 = p13.matcher(command);
            Matcher m12 = p12.matcher(command);
            Matcher m11 = p11.matcher(command);
            Matcher m15 = p15.matcher(command);
            Matcher m16 = p16.matcher(command);
            Matcher m17 = p17.matcher(command);
            Matcher m18 = p18.matcher(command);
            Matcher m19 = p19.matcher(command);
            Matcher m20 = p20.matcher(command);
            if (m1.matches()){
                adminResturantMenuController.Help();
            } else if (m5.matches()) {
                return;
            } else if (m2.matches()) {
                adminResturantMenuController.ShowLocation(resturant);
            } else if (m3.matches()) {
                System.out.println("enter your node");
                adminResturantMenuController.EditLocation(resturant);
            } else if (m4.matches()) {
                adminResturantMenuController.ShowFoodType(resturant);
            } else if (m6.matches()) {
                adminResturantMenuController.EditFoodType(resturant,m6);
            } else if (m7.matches()) {
                adminResturantMenuController.SlectMenu(resturant);
            } else if (m8.matches()) {
                adminResturantMenuController.EditNameFood(resturant,m8);
            }else if(m9.matches()){
                adminResturantMenuController.EditPriceFood(resturant,m9);
            } else if (m10.matches()) {
                adminResturantMenuController.EditDiscountFood(resturant,m10);
            } else if (m11.matches()) {
                adminResturantMenuController.AddFood(resturant,m11);
            }
            else if (m12.matches()) {
                adminResturantMenuController.DeleteFood(resturant,m12);
            }
            else if (m13.matches()) {
                adminResturantMenuController.DeactiveFood(resturant,m13);
            }
            else if (m14.matches()) {
                adminResturantMenuController.ActiveFood(resturant,m14);
            } else if (m15.matches()) {
                adminResturantMenuController.DiscountTimestampFood(resturant,m15);
            } else if (m16.matches()) {
                adminResturantMenuController.SelectFood(resturant,m16,indexRestaurant);
            } else if (m17.matches()) {
                System.out.println("WaitingForRestuarantConfirmation Orders:");
                adminResturantMenuController.DisplayOpenOrder(resturant);
            } else if (m19.matches()) {
                System.out.println("WaitingForRestuarantConfirmation Orders:");
                adminResturantMenuController.ShowOrderHistory(resturant);
            } else if (m18.matches()) {
                adminResturantMenuController.EditOrderStatus(resturant,m18);
            }
            else if (m20.matches()) {
                adminResturantMenuController.ConfirmOrder(resturant,m20);
            }
            else if (command.trim().equals("WHERE AM I")) {
                System.out.println("AdminResturantMenu");
            }
            else {
                System.out.println("Invalid Command");
            }

        }
    }

    @Override
    public void start(Stage stage) throws Exception {
        Pane pane = new Pane();
        stage.setMaximized(true);
        Paint paint = new ImagePattern(new Image(LoginMenu.class.getResource(Main.photLocation).toExternalForm()));
        BackgroundFill backgroundFill = new BackgroundFill(paint , CornerRadii.EMPTY, Insets.EMPTY);
        pane.setBackground(new Background(backgroundFill));
        if (stage.getScene() == null) {
            Scene scene = new Scene(pane);
            stage.setScene(scene);
        } else stage.getScene().setRoot(pane);
        ScrollPane scrollPane = new ScrollPane();
        VBox vBox = new VBox();
        vBox = adminResturantMenuController.getVbox();
        vBox.setAlignment(Pos.TOP_RIGHT);
        vBox.setSpacing(3);
        vBox.setStyle(Main.gold);
        scrollPane.setContent(vBox);
        scrollPane.setMaxSize(800,800);
        pane.getChildren().add(scrollPane);
        scrollPane.setLayoutX(780);
        scrollPane.setLayoutY(20);
        scrollPane.setStyle(Main.gold);
        changeBox=FXMLLoader.load(new URL(Main.class.getResource("/FXML/CHANGETMP.fxml").toExternalForm()));
        changeBox.setStyle(Main.dark);
        changeBox.setSpacing(3);
        changeBox.getStylesheets().add(Main.class.getResource("/CSS/Goden.css").toExternalForm());
        changeBox.setLayoutX(20);
        changeBox.setLayoutY(20);
        pane.getChildren().add(changeBox);
        Button button = new Button();
        Button button1 = new Button();
        button1.setText("BACK");
        button.setText("CREATE FOOD");
        //mi
        // 1-id change true/false
        // 2 food name
        // 3 food price
        // 4 food discount
        // 5 food activation t/f
        // 6 food deleting t/f
        // 7 fOOD DISCOUNT ACTIVATIION
        // ow
        ( (Label)(changeBox.getChildren().get(0))).setText("1_JUST WRITE WHAT U WANT 2 CHANGE\n 2-CREATING FOODS JUST NEED NAME \n AND PRICE OF THE NEW FOOD");
        button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if(((TextField)changeBox.getChildren().get(2)).getText().equals("") || ((TextField)changeBox.getChildren().get(3)).getText().equals("")){
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("NO INPUT");
                    alert.setHeaderText("DONT PLAY WITH ME ");
                    alert.setContentText("\t fill name and price at least");
                    alert.showAndWait();
                }
                else if(!AdminResturantMenuController.isJustDouble(((TextField)changeBox.getChildren().get(3)).getText())){
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("WRONG INPUT");
                    alert.setHeaderText("DONT PLAY WITH ME ");
                    alert.setContentText("\tPRICE SHOULD BE NUM ");
                    alert.showAndWait();
                }else if(!AdminResturantMenuController.isJustDouble(((TextField)changeBox.getChildren().get(4)).getText())) {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("WRONG INPUT");
                    alert.setHeaderText("DONT PLAY WITH ME ");
                    alert.setContentText("\t DISCOUNT SHOULD BE NUM ");
                    alert.showAndWait();
                }else {
                    if(((TextField)changeBox.getChildren().get(4)).getText().equals(""))
                        ((TextField)changeBox.getChildren().get(4)).setText("0");
                    Food food = new Food(((TextField)changeBox.getChildren().get(2)).getText(),2000000+resturant.getFoods().size(),Double.parseDouble(((TextField)changeBox.getChildren().get(3)).getText()),Double.parseDouble(((TextField)changeBox.getChildren().get(4)).getText()));
                    resturant.addFoodToFoods(food);
                    try {
                        new AdminResturantMenu(resturantOwner,resturant).start(Main.stage);
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                }
            }
        });
        button.setLayoutX(250);
        button.setLayoutY(600);
        button.setMinSize(200,50);
        button1.setLayoutX(50);
        button1.setLayoutY(600);
        button1.setMinSize(200,50);
        button1.setStyle(Main.gold);
        button.setStyle(Main.gold);
        button1.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    new AdminMenu(resturantOwner).start(stage);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });
        pane.getChildren().add(button1);
        pane.getChildren().add(button);
        stage.show();

    }
    public Resturant getResturant (){
        return resturant;
    }
    public ResturantOwner getResturantOwner (){
        return resturantOwner;
    }
}
