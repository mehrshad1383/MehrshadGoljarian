package view;

import model.FileManager;

public class DevelopersTestClass {
    public static void Arya(){
        System.out.println(FileManager.getMapMatrix().toString());
    }
}
