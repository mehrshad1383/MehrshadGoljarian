package view;

import controller.RegisterMenuController;
import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.Pane;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.ImagePattern;
import javafx.scene.paint.Paint;
import javafx.stage.Stage;
import model.Customer;
import model.Delivery;
import model.ResturantOwner;

import java.io.IOException;
import java.net.URL;

public class RegisterMenu extends Application {
    private static RegisterMenuController registerMenuController;

    private TextField Captcha = new TextField();
    @FXML
    private TextField NodeLabel;
    @FXML
    private Label error;
    @FXML
    private Button login;
    @FXML
    private TextField SecurityAnswer;
    @FXML
    private TextField PasswordField;
    @FXML
    private TextField UserField;
    @FXML
    private Button submit;
    @FXML
    private ChoiceBox <String> EnterAs;
    private String[] Choices = {"Admin" , "User" , "Delivery"};
    private LoginMenu loginMenu;
    private CostumerMenu costumerMenu;
    private Pane pane;
    private int rand;
    private MediaPlayer mediaPlayer;
    public RegisterMenu(MediaPlayer mediaPlayer) {
    registerMenuController = new RegisterMenuController(this);
    this.mediaPlayer = mediaPlayer;
    }
    public RegisterMenu(){

    }

    public void start(Stage stage) throws IOException
    {
        LoginMenu.stage = stage;
        stage.setMaximized(true);
        pane = FXMLLoader.load(new URL(RegisterMenu.class.getResource("/FXML/RegisterMenu.fxml").toExternalForm()));
        Paint paint = new ImagePattern(new Image(RegisterMenu.class.getResource("/Image/LoginMenu.JPG").toExternalForm()));
        BackgroundFill backgroundFill = new BackgroundFill(paint , CornerRadii.EMPTY, Insets.EMPTY);
        pane.setBackground(new Background(backgroundFill));
        ImageView imageView = new ImageView();
        imageView.setX(150);
        imageView.setY(700);
        Captcha.setLayoutX(350);
        Captcha.setLayoutY(720);
        Captcha.setPromptText("Enter Captcha");
        Image imageCaptcha = new Image(LoginMenu.class.getResource(model.Captcha.getCaptcha().get(rand)).toExternalForm());
        imageView.setImage(imageCaptcha);
        pane.getChildren().add(imageView);
        pane.getChildren().add(Captcha);
        if (stage.getScene() == null) {
            Scene scene = new Scene(pane);
            stage.setScene(scene);
        } else stage.getScene().setRoot(pane);
        stage.show();
    }

    public void initialize() throws Exception{
        EnterAs.getItems().addAll(Choices);
    }

    public void login() throws IOException {
       LoginMenu loginMenu = new LoginMenu();
        loginMenu.start(LoginMenu.stage);
    }

    public void signup(MouseEvent mouseEvent) throws Exception {
        String situation = EnterAs.getValue();
        if (situation == null) {
            error.setText("Choose Who You Enter As");
        } else {
            if (situation.equals("Admin")) {
                String result = registerMenuController.setANewPassword(PasswordField.getText());
                if (!result.equals("Your account has been successfully created")) {
                    error.setText(result);
                } else {
                    result = registerMenuController.setnewResturantOwner(UserField.getText(), PasswordField.getText()
                            ,Integer.parseInt(NodeLabel.getText()) ,SecurityAnswer.getText());

                    if (!result.equals("Registration was successful")) {
                        error.setText(result);
                        if(result.equals("Please enter your captcha correctly!"))
                        {
                            Changerand();
                            start(LoginMenu.stage);
                        }
                    } else {
                        error.setText(result);
                        ResturantOwner resturantOwner = new ResturantOwner(UserField.getText(), PasswordField.getText()
                                ,Integer.parseInt(NodeLabel.getText()) ,SecurityAnswer.getText());
                        AdminMenu adminMenu = new AdminMenu(resturantOwner);
                       adminMenu.start(LoginMenu.stage);
                    }
                }
            } else if (situation.equals("User")) {
                String result = registerMenuController.setANewPassword(PasswordField.getText());
                if (!result.equals("Your account has been successfully created")) {
                    error.setText(result);
                } else {
                    result = registerMenuController.setnewResturantOwner(UserField.getText(), PasswordField.getText()
                            ,Integer.parseInt(NodeLabel.getText()) ,SecurityAnswer.getText());
                    if (!result.equals("Registration was successful")) {
                        error.setText(result);
                        if(result.equals("Please enter your captcha correctly!"))
                        {
                            Changerand();
                            start(LoginMenu.stage);
                        }
                    } else {
                        error.setText(result);
                        Customer customer = new Customer(UserField.getText(), PasswordField.getText()
                                ,Integer.parseInt(NodeLabel.getText()) ,SecurityAnswer.getText());
                        CostumerMenu costumerMenu = new CostumerMenu(customer,mediaPlayer);
                        costumerMenu.start(LoginMenu.stage);
                    }
                }
            } else if (situation.equals("Delivery")) {
                String result = registerMenuController.setANewPassword(PasswordField.getText());
                if (!result.equals("Your account has been successfully created")) {
                    error.setText(result);
                } else {
                    result = registerMenuController.setnewResturantOwner(UserField.getText(), PasswordField.getText()
                            ,Integer.parseInt(NodeLabel.getText()) ,SecurityAnswer.getText());
                    if (!result.equals("Registration was successful")) {
                        error.setText(result);
                        if(result.equals("Please enter your captcha correctly!"))
                        {
                            Changerand();
                            start(LoginMenu.stage);
                        }
                    } else {
                        error.setText(result);
                        Delivery delivery = new Delivery(UserField.getText(), PasswordField.getText()
                                ,Integer.parseInt(NodeLabel.getText()) ,SecurityAnswer.getText());
                        DeliveryManagementMenu deliveryManagementMenu = new DeliveryManagementMenu(delivery);
                        deliveryManagementMenu.start(LoginMenu.stage);
                    }
                }
            }
        }
    }

    public int getRand() {
        return rand;
    }
    public TextField getCaptcha() {
        return Captcha;
    }
    public void Changerand(){
        rand = (rand+1)%8;
    }
//public static void run()
//{
//    String r1 = "ADD ADMIN\\s+(?<nameAdmin>((\\w)|((\\s)|(\\W)))*)\\s+(?<passwordAdmin>((\\w)|((\\s)|(\\W)))*)\\s(?<node>(\\d)+)";
//    Pattern p1 = Pattern.compile(r1);
//    String r2 = "ADD USER\\s+(?<nameUser>((\\w)|((\\s)|(\\W)))*)\\s+(?<passwordUser>((\\w)|((\\s)|(\\W)))*)\\s(?<node1>(\\d)+)";
//    Pattern p2 = Pattern.compile(r2);
//    String r3 = "back";
//    Pattern p3 = Pattern.compile(r3);
//    String r4 = "ADD DELIVERY\\s+(?<nameDelivery>((\\w)|((\\s)|(\\W)))*)\\s+(?<passwordDelivery>((\\w)|((\\s)|(\\W)))*)\\s(?<node2>(\\d)+)";
//    Pattern p4 = Pattern.compile(r4);
//    String r5 = "Help";
//    Pattern p5 = Pattern.compile(r5);
//    String command , result ;
//    while (true) {
//        command = Menu.getScanner().nextLine();
//        command = command.trim();
//        Matcher m1 = p1.matcher(command);
//        Matcher m2 = p2.matcher(command);
//        Matcher m3 = p3.matcher(command);
//        Matcher m4 = p4.matcher(command);
//        Matcher m5 = p5.matcher(command);
//        if (m1.matches())
//        {
//            String name = m1.group("nameAdmin");
//            String password = m1.group("passwordAdmin");
//            int node = Integer.parseInt(m1.group("node"));
//            if(ResturantOwner.printindexbyResturantOwnername(name)<0) {
//                result = registerMenuController.setANewPassword(password);
//                if(!result.equals("Your account has been successfully created"))
//                    System.out.println(result);
//                if (result.equals("Your account has been successfully created")) {
//                    System.out.println("Security question: Write down your day, month, and year of birth, and remember how to write it.");
//                    command = Menu.getScanner().nextLine();
//                    registerMenuController.setnewResturantOwner(name, password, node,command);
//                }
//            }
//            else {
//                System.out.println("This name already exists");
//            }
//        }
//        else if(m2.matches()){
//            String name = m2.group("nameUser");
//            String password = m2.group("passwordUser");
//            int node = Integer.parseInt(m2.group("node1"));
//            if(Customer.printindexbycustomname(name)<0) {
//                result = registerMenuController.setANewPassword(password);
//                if(!result.equals("Your account has been successfully created"))
//                    System.out.println(result);
//                if (result.equals("Your account has been successfully created")) {
//                    System.out.println("Security question: Write down your day, month, and year of birth, and remember how to write it.");
//                    command = Menu.getScanner().nextLine();
//                    registerMenuController.setnewCustomer(name, password, node,command);
//                }
//            }
//            else {
//                System.out.println("This name already exists");
//            }
//        }
//        else if(m4.matches()){
//            String name = m4.group("nameDelivery");
//            String password = m4.group("passwordDelivery");
//            int node = Integer.parseInt(m4.group("node2"));
//            if(Delivery.printindexbydeliveryname(name)<0) {
//                result = registerMenuController.setANewPassword(password);
//                if(!result.equals("Your account has been successfully created"))
//                    System.out.println(result);
//                if (result.equals("Your account has been successfully created")) {
//                    System.out.println("Security question: Write down your day, month, and year of birth, and remember how to write it.");
//                    command = Menu.getScanner().nextLine();
//                    registerMenuController.setnewDelivery(name, password, node,command);
//                }
//            }
//            else {
//                System.out.println("This name already exists");
//            }
//        }
//        else if(m3.matches()){
//            return;
//        }
//        else if (command.trim().equals("WHERE AM I")) {
//            System.out.println("RegisterMenu");
//        }
//        else if(m5.matches()){
//            System.out.println("Available options: ");
//            System.out.println("ADD ADMIN <NameAdmin> <PasswordAdmin> <Node>");
//            System.out.println("ADD USER <NameUser> <PasswordUser> <Node>");
//            System.out.println("ADD DELIVERY <NameDelivery> <PasswordDelivery> <Node>");
//            System.out.println(r3);
//        }
//        else{
//            System.out.println("Invalid Command");
//        }
//    }
//
//}



}
