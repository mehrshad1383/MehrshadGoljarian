package view;

import controller.OrderHistoryMenuController;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.ImagePattern;
import javafx.scene.paint.Paint;
import javafx.stage.Stage;
import model.*;

import java.io.IOException;

public class DeliveryManageMentOrderreview {

    private Order order;
    private Delivery delivery;
    public static Stage stage;
    private Pane pane = new Pane();
    private MediaPlayer mediaPlayer;

    public DeliveryManageMentOrderreview() {

    }
    public DeliveryManageMentOrderreview(Order order , Delivery delivery) {
        this.order = order;
        this.delivery = delivery;
    }

    //    public OrderHistoryMenu() {
//        this.customer = new Customer("pp" , "pp" , 4 , "pp");
//    }

    public void start(Stage stage) throws Exception {
        DeliveryManageMentOrderreview.stage=stage;
        stage.setMaximized(true);
        //pane = FXMLLoader.load(new URL(LoginMenu.class.getResource("/FXML/CustomerMenu.fxml").toExternalForm()));
        Paint paint = new ImagePattern(new Image(LoginMenu.class.getResource("/Image/LoginMenu.JPG").toExternalForm()));
        BackgroundFill backgroundFill = new BackgroundFill(paint , CornerRadii.EMPTY, Insets.EMPTY);
        pane.setBackground(new Background(backgroundFill));
        if (stage.getScene() == null) {
            Scene scene = new Scene(pane);
            stage.setScene(scene);
        } else stage.getScene().setRoot(pane);
        ScrollPane scrollPane = new ScrollPane();
        VBox vBox = new VBox();
        Label label = new Label();
        label.setLayoutX(300);
        label.setLayoutY(300);
        vBox = ShowAllOrder(vBox);
        if(vBox.getChildren().size()==0){
            pane.getChildren().add(label);
        }
        Button exitbutton = new Button("Exit");
        exitbutton.setLayoutX(10);
        exitbutton.setLayoutY(10);
        exitbutton.setStyle("-fx-background-color:rgba(32,253,143,0.65);");
        pane.getChildren().add(exitbutton);
        exitbutton.setOnAction(event -> {
            try {
                exit();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });
        vBox.setAlignment(Pos.CENTER);
        vBox.setSpacing(5);
        scrollPane.setContent(vBox);
        scrollPane.setMaxSize(800,800);
        pane.getChildren().add(scrollPane);
        scrollPane.setLayoutX(400);
        scrollPane.setLayoutY(20);
        stage.show();
    }
    public void exit() throws Exception {
        DeliveryManagementMenu deliveryManagementMenu = new DeliveryManagementMenu(delivery);
        deliveryManagementMenu.start(LoginMenu.stage);
    }

    public VBox ShowAllOrder(VBox vBox) throws IOException {
        String name ="";
        int id;
        String list="";
        String numorder;
        int cnt=0;
        cnt=0;
        list="";
        id = ( order.getId()+3000000);
        name=order.getResturant().getName();
        list = list+"Total price= "+order.getOrderedfoods().get(0).getCost()+"\n";
        for (int j = 0; j <order.getOrderedfoods().get(0).getFoods().size() ; j++) {
            cnt++;
            list = list+(cnt) + ". NAME FOOD= " + order.getOrderedfoods().get(0).getFoods().get(j).getName()+"\n";
        }
        vBox.getChildren().add(new Historytmp(name,list,"ORDER"+(1),"20000","/Image/pic2.png",id+"").getInstance()) ;
        return vBox;
    }
}
