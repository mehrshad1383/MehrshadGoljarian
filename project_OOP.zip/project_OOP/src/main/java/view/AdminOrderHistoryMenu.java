package view;

import controller.AdminOrderHistoryMenuController;
import controller.OrderHistoryMenuController;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.ImagePattern;
import javafx.scene.paint.Paint;
import javafx.stage.Stage;
import model.Customer;
import model.Resturant;

public class AdminOrderHistoryMenu extends Application {
    private AdminOrderHistoryMenuController adminOrderHistoryMenuController;
    private Resturant resturant;

    public static Stage stage;
    private Pane pane = new Pane();
    private MediaPlayer mediaPlayer;

    public AdminOrderHistoryMenu(Resturant resturant) {
        this.adminOrderHistoryMenuController = new AdminOrderHistoryMenuController(this);
        this.resturant = resturant;
    }

    //    public OrderHistoryMenu() {
//        this.customer = new Customer("pp" , "pp" , 4 , "pp");
//    }
    @Override
    public void start(Stage stage) throws Exception {
        OrderHistoryMenu.stage=stage;
        stage.setMaximized(true);
        //pane = FXMLLoader.load(new URL(LoginMenu.class.getResource("/FXML/CustomerMenu.fxml").toExternalForm()));
        Paint paint = new ImagePattern(new Image(LoginMenu.class.getResource("/Image/LoginMenu.JPG").toExternalForm()));
        BackgroundFill backgroundFill = new BackgroundFill(paint , CornerRadii.EMPTY, Insets.EMPTY);
        pane.setBackground(new Background(backgroundFill));
        if (stage.getScene() == null) {
            Scene scene = new Scene(pane);
            stage.setScene(scene);
        } else stage.getScene().setRoot(pane);
        ScrollPane scrollPane = new ScrollPane();
        VBox vBox = new VBox();
        Label label = new Label();
        label.setLayoutX(300);
        label.setLayoutY(300);
        if("pp"=="pp")
        {
            //        vBox = adminOrderHistoryMenuController.ShowAllOrder(resturant,vBox);
        }
        else{

        }
        if(vBox.getChildren().size()==0){
            pane.getChildren().add(label);
        }
        Button exitbutton = new Button("Exit");
        exitbutton.setLayoutX(10);
        exitbutton.setLayoutY(10);
        exitbutton.setStyle("-fx-background-color:rgba(32,253,143,0.65);");
        pane.getChildren().add(exitbutton);
        exitbutton.setOnAction(event -> {
            try {
                exit();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });
        vBox.setAlignment(Pos.CENTER);
        vBox.setSpacing(5);
        scrollPane.setContent(vBox);
        scrollPane.setMaxSize(800,800);
        pane.getChildren().add(scrollPane);
        scrollPane.setLayoutX(400);
        scrollPane.setLayoutY(20);
        stage.show();
    }
    public void exit() throws Exception {
//        AdminResturantMenu adminResturantMenu = new AdminResturantMenu(resturant.getResturantOwner(),resturant,mediaPlayer);
//        adminResturantMenu.start(LoginMenu.stage);
    }
}
