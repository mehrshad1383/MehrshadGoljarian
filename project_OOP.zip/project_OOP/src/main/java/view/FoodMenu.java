package view;

import controller.FoodMenuController;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import model.Customer;
import model.Food;
import model.Resturant;

import java.util.regex.Matcher;
import java.util.regex.Pattern;




public class FoodMenu extends Application {
    private FoodMenuController foodMenuController;
    private Food food;
    private Customer customer;
    private Resturant resturant;
    private String checker;
    public static Stage stage;
    private Button newcomment = new Button("ADD NEW COMMENT");
    private Button editCommit = new Button("EDIT COMMENT");
    private Button subrate = new Button("SUBMIT RATING");
    private Button editrating = new Button("EDIT RATING");
    private Pane pane = new Pane();
    private int index;
    private int indexcustomer;
    private Label label = new Label();
    private String result;
    private int indexFood;
    private TextField textField = new TextField();
    private Button button = new Button("submit");
    private Button add = new Button("ADD THIS FOOD TO CART");
    private Button back = new Button("Back");
    private MediaPlayer mediaPlayer;

    public FoodMenu(Food food, Customer customer, Resturant resturant,MediaPlayer mediaPlayer) {
        this.foodMenuController = new FoodMenuController(this);
        this.food = food;
        this.customer = customer;
        this.resturant = resturant;
        this.mediaPlayer = mediaPlayer;
    }


    @Override
    public void start(Stage stage) throws Exception {
        FoodMenu.stage = stage;
        indexcustomer = Customer.returnIndexFromObject(customer);
        indexFood = Resturant.ReturnIndexFood(index, food);
        index = Resturant.ReturnIndexFromRestaurant(resturant);
        stage.setMaximized(true);
        //pane = FXMLLoader.load(new URL(LoginMenu.class.getResource("/FXML/CustomerMenu.fxml").toExternalForm()));
        Paint paint = new ImagePattern(new Image(LoginMenu.class.getResource("/Image/LoginMenu.JPG").toExternalForm()));
        BackgroundFill backgroundFill = new BackgroundFill(paint, CornerRadii.EMPTY, Insets.EMPTY);
        pane.setBackground(new Background(backgroundFill));
        if (stage.getScene() == null) {
            Scene scene = new Scene(pane);
            stage.setScene(scene);
        } else stage.getScene().setRoot(pane);
        buttonrunner(pane);
        ScrollPane scrollPane = new ScrollPane();
        VBox vBox = new VBox();
        vBox = foodMenuController.showAllComment(index, indexFood, vBox);
        vBox.setAlignment(Pos.TOP_RIGHT);
        vBox.setSpacing(5);
        scrollPane.setContent(vBox);
        scrollPane.setMaxSize(800, 800);
        if(vBox.getChildren().size()!=0)
            pane.getChildren().add(scrollPane);
        else {
            ImageView imageView = new ImageView();
            imageView.setX(850);
            imageView.setY(200);
            Image imagepoker = new Image(LoginMenu.class.getResource("/Image/poker.png").toExternalForm());
            imageView.setImage(imagepoker);
            Rectangle rectangle = new Rectangle(930,100,360,50);
            rectangle.setFill(Color.web("#226537"));
            Label label1 = new Label("THERE IS NO COMMENT");
            label1.setLayoutX(950);
            label1.setLayoutY(112);
            label1.setStyle("-fx-font-family: Arial;-fx-text-fill: red;-fx-font-size: 25");
            pane.getChildren().add(rectangle);
            pane.getChildren().add(label1);
            pane.getChildren().add(imageView);
        }
        scrollPane.setLayoutX(780);
        scrollPane.setLayoutY(20);
        add.setOnAction(event -> addtocart(pane));
        newcomment.setOnAction(event -> addNewComment(pane));
        editCommit.setOnAction(event -> editComment(pane));
        subrate.setOnAction(event -> subRating(pane));
        editrating.setOnAction(event -> editRating(pane));
        button.setOnAction(event -> {
            try {
                compile(pane);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });
        back.setOnAction(event -> {
            try {
                returnnn();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });
        stage.show();
    }

    public void returnnn() throws Exception {
        pane.getChildren().remove(textField);
        pane.getChildren().remove(button);
        new ResturantMenu(resturant, Customer.getLoggedInCustomer(),mediaPlayer).start(LoginMenu.stage);
    }

    public void addtocart(Pane pane) {
        pane.getChildren().remove(textField);
        label.setText("");
        pane.getChildren().remove(button);
        if (food.isActivated()) {
            foodMenuController.AddToCart(indexcustomer, food, resturant, customer);
            label.setText("ADDED SUCCESSFULLY");
        } else {
            label.setText("This food is inactivate");
        }
        pane.requestFocus();
    }

    public void addNewComment(Pane pane) {
        pane.getChildren().remove(label);
        pane.getChildren().add(label);
        if (!foodMenuController.checkOrderFood(customer, food,index)) {
            label.setText("You did not order this food before");
        } else if (!foodMenuController.CheckforCommitOrnot(customer, index, indexFood)) {
            label.setText("You already comment it, maybe you need to edit it");
        } else {
            label.setText("");
            checker = "newcomment";
            textField.setText("");
            textField.setPromptText("WRITE YOUR OPINION");
            pane.getChildren().remove(textField);
            pane.getChildren().remove(button);
            pane.getChildren().add(textField);
            pane.getChildren().add(button);
            pane.requestFocus();
        }
    }

    public void editComment(Pane pane) {
        pane.getChildren().remove(label);
        pane.getChildren().remove(textField);
        pane.getChildren().remove(button);
        textField.setText("");
        textField.setPromptText("Enter id of comment");
        pane.getChildren().add(textField);
        pane.getChildren().add(button);
        checker="Editcomment";
        pane.requestFocus();
    }

    public void subRating(Pane pane) {
        pane.getChildren().remove(label);
        pane.getChildren().add(label);
        int id = Resturant.CheckForCommitOrNot(index, indexFood, customer);
        if (id < 0) {
            label.setText("Please write your comment first Then give your score from 0 to 10");
        } else {
            int idcomment = foodMenuController.returnindexComment(customer, index, indexFood);
            if (foodMenuController.returnrating(index, indexFood, idcomment) > -1) {
                label.setText("You already rated it, maybe you need to edit it");
            }
            else{
                textField.setText("");
                textField.setPromptText("Enter your opinion");
                pane.getChildren().add(textField);
                pane.getChildren().add(button);
                checker="subrate";
            }
        }
    }

    public void editRating(Pane pane) {
        pane.getChildren().remove(label);
        pane.getChildren().add(label);
        int id = Resturant.CheckForCommitOrNot(index,indexFood,customer);
        if(id<0){
            label.setText("Please write your comment first Then give your score from 0 to 10");
        }
        else if(Resturant.ReturnRatingOfFood(index,indexFood,id)==-1){
            label.setText("You have not rated yet");
        }
        else {
            label.setText("");
            checker = "editrate";
            textField.setText("");
            textField.setPromptText("num 0 to 10");
            pane.getChildren().add(textField);
            pane.getChildren().add(button);
            pane.requestFocus();
        }
    }

    public void buttonrunner(Pane pane) {
        back.setLayoutX(10);
        back.setLayoutY(10);
        add.setLayoutY(180);
        add.setLayoutX(180);
        label.setLayoutY(260);
        label.setLayoutX(140);
        newcomment.setLayoutX(120);
        newcomment.setLayoutY(100);
        newcomment.setStyle("-fx-background-color:rgba(32,253,143,0.65);");
        pane.getChildren().add(newcomment);
        editCommit.setLayoutX(510);
        editCommit.setLayoutY(100);
        textField.setLayoutX(300);
        textField.setLayoutY(620);
        button.setLayoutX(347);
        button.setLayoutY(670);
        button.setStyle("-fx-background-color:rgba(32,253,143,0.65);");
        subrate.setLayoutX(335);
        subrate.setLayoutY(100);
        subrate.setStyle("-fx-background-color:rgba(32,253,143,0.65);");
        editrating.setLayoutX(400);
        editrating.setLayoutY(180);
        editrating.setStyle("-fx-background-color:rgba(32,253,143,0.65);");
        pane.getChildren().add(editrating);
        pane.getChildren().add(subrate);
        editCommit.setStyle("-fx-background-color:rgba(32,253,143,0.65);");
        pane.getChildren().add(editCommit);
        label.setStyle("-fx-text-fill: #ff0000;-fx-font-family: Arial;-fx-font-size: 20");
        pane.getChildren().add(label);
        add.setStyle("-fx-background-color:rgba(32,253,143,0.65);");
        pane.getChildren().add(add);
        back.setStyle("-fx-background-color:rgba(32,253,143,0.65);");
        pane.getChildren().add(back);
    }
    public void compile(Pane pane) throws Exception {
        int id=0;
        pane.getChildren().remove(label);
        pane.getChildren().remove(textField);
        pane.getChildren().remove(button);
        if(checker.equals("newcomment")){
            String command = textField.getText();
            foodMenuController.AddnewComment(customer,command,index,indexFood);
            label.setText("YOUR COMMENT ADDED SUCCESSFULLY");
            pane.getChildren().add(label);
        }
        else if(checker.equals("Editcomment")){
            pane.getChildren().add(label);
            id = Integer.parseInt(textField.getText());
            if(Resturant.returnnumCommitForFood(index,indexFood)<=id){
                System.out.println(Resturant.ReturnNumberOfComment(index));
                label.setText("There is no comment with this id");
            }
            else if(!Resturant.checkCommitFoodByCustomer(index,indexFood,customer,id)){
                label.setText("This comment is not for you");
            }
            else{
                pane.getChildren().remove(label);
                textField.setText("");
                textField.setPromptText("Enter your opinion");
                pane.getChildren().add(textField);
                pane.getChildren().add(button);
                checker="editcomment1";
            }
            pane.requestFocus();
        }
        else if(checker.equals("editcomment1")){
            String content = textField.getText();
            foodMenuController.EditComment(index,indexFood,id,content);
            pane.getChildren().remove(textField);
            pane.getChildren().remove(button);
            pane.getChildren().add(label);
            label.setText("CHANGED SUCCESSFULLY");
            pane.requestFocus();
        }
        else if(checker.equals("subrate")){
            pane.getChildren().add(label);
            id = Resturant.CheckForCommitOrNot(index, indexFood, customer);
            double rate = Double.parseDouble(textField.getText());
            foodMenuController.SubmitRating(index,indexFood,rate,id);
            label.setText("SUBMIT SUCCESSFULLY");
            pane.getChildren().remove(button);
            pane.getChildren().remove(textField);
        }
        else if(checker.equals("editrate")){
            id = Resturant.CheckForCommitOrNot(index,indexFood,customer);
            pane.getChildren().add(label);
            double rate = Double.parseDouble(textField.getText());
            foodMenuController.EditRating(index,indexFood,rate,id);
            label.setText("CHANGED SUCCESSFULLY");
        }
    }
}
    /*
    public void run(int indexResturant, int indexFood, Customer customer)
    {
        int indexcustomer = Customer.returnIndexFromObject(customer);
        System.out.println("Entered "+food.getName()+" menu, you can enter Help to see available option");
        Resturant resturant = Resturant.returnResturantByIndex(indexResturant);
        String r1 = "DISPLAY COMMENTS";
        Pattern p1 = Pattern.compile(r1);
        String r2 = "ADD NEW COMMENT";
        Pattern p2 = Pattern.compile(r2);
        String r3 = "ADD THIS FOOD TO CART";
        Pattern p3 = Pattern.compile(r3);
        String r4 = "EDIT COMMENT (?<ID>(\\d)+)";
        Pattern p4 = Pattern.compile(r4);
        String r5 = "SUBMIT RATING";
        Pattern p5 = Pattern.compile(r5);
        String r6 = "EDIT RATING";
        Pattern p6 = Pattern.compile(r6);
        String r7 = "DISPLAY RATING";
        Pattern p7 = Pattern.compile(r7);
        String r8 = "back";
        Pattern p8 = Pattern.compile(r8);
        String r9 = "Help";
        Pattern p9 = Pattern.compile(r9);
        String r10 = "SHOW RESPONSE OWNER";
        Pattern p10 = Pattern.compile(r10);
        String command;
        while (true) {
            command = Menu.getScanner().nextLine();
            command = command.trim();
            Matcher m1 = p1.matcher(command);
            Matcher m2 = p2.matcher(command);
            Matcher m3 = p3.matcher(command);
            Matcher m4 = p4.matcher(command);
            Matcher m5 = p5.matcher(command);
            Matcher m6 = p6.matcher(command);
            Matcher m7 = p7.matcher(command);
            Matcher m8 = p8.matcher(command);
            Matcher m9 = p9.matcher(command);
            Matcher m10 = p10.matcher(command);
            if(m1.matches()){
                foodMenuController.showAllComment(indexResturant,indexFood);
            }
            else if(m2.matches()){
                Food food1 = Resturant.returnFoodByIndex(indexFood,indexResturant);
                foodMenuController.AddnewComment(customer,food1,indexResturant,indexFood);
            }
            else if(m3.matches()){
                if(food.isActivated()){
                    foodMenuController.AddToCart(indexcustomer, food, resturant, customer);
                }
                else{
                    System.out.println("This food is inactivate");
                }
            }
            else if(m4.matches()){
                int id = Integer.parseInt(m4.group("ID"));
                foodMenuController.EditComment(indexResturant,indexFood,id,customer);
            }
            else if(m5.matches()){
                foodMenuController.SubmitRating(indexResturant,indexFood,customer);
            }
            else if(m6.matches()){
                foodMenuController.EditRating(indexResturant,indexFood,customer);
            }
            else if(m7.matches()){
                foodMenuController.DisplayRatings(indexResturant,indexFood);
            }
            else if (command.trim().equals("WHERE AM I")) {
                System.out.println("FoodMenu");
            }
            else if(m8.matches()){
                return;
            }
            else if(m9.matches()){
                System.out.println("Available options: ");
                System.out.println(r1);
                System.out.println(r2);
                System.out.println(r3);
                System.out.println("EDIT COMMENT <ID>");
                System.out.println(r5);
                System.out.println(r6);
                System.out.println(r7);
                System.out.println(r8);
                System.out.println(r10);
            }
            else if(m10.matches()){
                foodMenuController.ShowResponse(indexResturant,indexFood,customer);
            }
            else{
                System.out.println("Invalid Command");
            }
        }
    }
}

     */
