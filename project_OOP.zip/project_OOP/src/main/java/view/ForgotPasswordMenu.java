package view;

import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.Pane;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.ImagePattern;
import javafx.scene.paint.Paint;
import javafx.stage.Stage;
import model.Customer;
import model.Delivery;
import model.ResturantOwner;

import java.io.IOException;
import java.net.URL;

public class ForgotPasswordMenu extends Application {
    public static Stage stage;
    private Pane pane = new Pane();
    private Button back = new Button("back");
    private ChoiceBox EnterAs = new ChoiceBox<String>();
    private Label choice = new Label("select who you enter as");
    private String[] Choices = {"Admin" , "User" , "Delivery"};
    private Label label = new Label();
    private TextField textField = new TextField();
    private TextField textField1 = new TextField();
    private Button button = new Button("submit");
    private String checker="";
    private String situation;
    private String nameUser;
    private String nameAdmin;
    private String nameDelivery;
    private MediaPlayer mediaPlayer;
    public ForgotPasswordMenu(MediaPlayer mediaPlayer)
    {
        this.mediaPlayer=mediaPlayer;
    }
    @Override
    public void start(Stage stage) throws Exception {
        ForgotPasswordMenu.stage=stage;
        textField.setPromptText("Enter your name");
        LoginMenu.stage = stage;
        stage.setMaximized(true);
        Paint paint = new ImagePattern(new Image(LoginMenu.class.getResource("/Image/LoginMenu.JPG").toExternalForm()));
        BackgroundFill backgroundFill = new BackgroundFill(paint , CornerRadii.EMPTY, Insets.EMPTY);
        pane.setBackground(new Background(backgroundFill));
        if (stage.getScene() == null) {
            Scene scene = new Scene(pane);
            stage.setScene(scene);
        } else stage.getScene().setRoot(pane);
        buttonrun();
        EnterAs.getItems().addAll(Choices);
        button.setOnAction(event -> compile(pane));
        back.setOnAction(event -> {
            try {
                returnn();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

        });
        stage.show();
    }
    public void returnn() throws IOException {
        LoginMenu loginMenu =new LoginMenu();
        loginMenu.start(stage);
    }
    public void compile(Pane pane){
        if(checker.equals("")){
           situation = (String) EnterAs.getValue();
            if (situation == null) {
                label.setText("Choose Who You Enter As");
            }
            else if(situation.equals("User")){
                nameUser = textField.getText();
                if (Customer.printindexbycustomname(nameUser) > -1)
                {
                    textField.setText("");
                    label.setText("");
                    textField.setPromptText("answer security question");
                    checker = "check";
                }
                else {
                    label.setText("There is no account with this name");
                    textField.setText("");
                }
            }
            else if(situation.equals("Admin")){
                 nameAdmin = textField.getText();
                if (ResturantOwner.printindexbyResturantOwnername(nameAdmin) > -1)
                {
                    textField.setText("");
                    label.setText("");
                    textField.setPromptText("answer security question");
                    checker = "check";
                }
                else{
                    label.setText("There is no account with this name");
                    textField.setText("");
                }
            }
            else if(situation.equals("Delivery")){
                 nameDelivery = textField.getText();
                if (Delivery.printindexbydeliveryname(nameDelivery) > -1)
                {
                    textField.setText("");
                    label.setText("");
                    textField.setPromptText("answer security question");
                    checker = "check";
                }
                else{
                    label.setText("There is no account with this name");
                    textField.setText("");
                }
            }
        }
        else if(checker.equals("check")){
            if(situation.equals("User")){
                String code = textField.getText();
                if (Customer.checksecurityquestion(nameUser, code))
                {
                    label.setText("match! please enter new password");
                    textField.setText("");
                    textField.setPromptText("enter new password");
                    textField1.setPromptText("re_enter new password");
                    pane.getChildren().add(textField1);
                    checker="checkfinal";
                }
                else{
                    label.setText("no match, please re_enter your answer");
                    textField.setText("");
                }
            }
            else if(situation.equals("Admin")){
                String code = textField.getText();
                if (!ResturantOwner.checksecurityquestion(nameAdmin, code))
                {
                    label.setText("match! please enter new password");
                    textField.setText("");
                    textField.setPromptText("re-enter new password");
                    textField1.setPromptText("enter new password");
                    pane.getChildren().add(textField1);
                    checker="checkfinal";
                }
                else{
                    label.setText("no match, please re_enter your answer");
                    textField.setText("");
                }
            }
            else if(situation.equals("Delivery")){
                String code = textField.getText();
                if (!Customer.checksecurityquestion(nameDelivery, code))
                {
                    label.setText("match! please enter new password");
                    textField.setText("");
                    textField.setPromptText("enter new password");
                    textField1.setPromptText("re_enter new password");
                    pane.getChildren().add(textField1);
                    checker="checkfinal";
                }
                else{
                    label.setText("no match, please re_enter your answer");
                    textField.setText("");
                }
            }
        }
        else if(checker.equals("checkfinal")) {
            if (situation.equals("User")) {
                String pass1 = textField.getText();
                String pass2 = textField1.getText();
                if (!pass1.equals(pass2)) {
                    label.setText("your passwords not match with together");
                    textField.setText("");
                    textField1.setText("");
                } else {
                    String result;
                    result = setANewPassword(pass1);
                    if (result.equals("Your account has been successfully created")) {
                          label.setText("Your password has been changed successfully.");
                          Customer.setnewpassword(pass1, Customer.printindexbycustomname(nameUser));
                    } else {
                        label.setText(result);
                        textField.setText("");
                        textField1.setText("");
                    }
                }
            } else if (situation.equals("Admin")) {
                String pass1 = textField.getText();
                String pass2 = textField1.getText();
                if (!pass1.equals(pass2)) {
                    label.setText("your passwords not match with together");
                    textField.setText("");
                    textField1.setText("");
                } else {
                    String result;
                    result = setANewPassword(pass1);
                    if (result.equals("Your account has been successfully created")) {
                        label.setText("Your password has been changed successfully.");
                        ResturantOwner.setnewpassword(pass1, ResturantOwner.printindexbyResturantOwnername(nameAdmin));
                    } else {
                        label.setText(result);
                        textField.setText("");
                        textField1.setText("");
                    }
                }
            } else if (situation.equals("Delivery")) {
                String pass1 = textField.getText();
                String pass2 = textField1.getText();
                if (!pass1.equals(pass2)) {
                    label.setText("your passwords not match with together");
                    textField.setText("");
                    textField1.setText("");
                } else {
                    String result;
                    result = setANewPassword(pass1);
                    if(result.equals("Your account has been successfully created")){
                        label.setText("Your password has been changed successfully.");
                        Delivery.setnewpassword(pass1, Delivery.printindexbydeliveryname(nameDelivery));
                    }
                else{
                        label.setText(result);
                        textField.setText("");
                        textField1.setText("");
                    }
                }
            }
        }
        pane.requestFocus();
    }
    public String setANewPassword(String newPassword) {
        newPassword = newPassword.trim();
        if (newPassword.length() < 6 || !newPassword.matches(".*[a-z].*") || !newPassword.matches(".*[A-Z].*") || !newPassword.matches(".*[0-9].*") || !newPassword.matches(".*[^a-zA-Z0-9|_].*"))
            return handlePasswordErrors(newPassword);

        return "Your account has been successfully created";
    }
    public String handlePasswordErrors(String password) {
        if (password.length() < 6)
            return "Weak password! Password length should be more than 5.";

        if (!password.matches(".*[a-z].*"))
            return "Weak password! Password should have at least one small English letter.";

        if (!password.matches(".*[A-Z].*"))
            return "Weak password! Password should have at least one capital English letter.";

        if (!password.matches(".*[0-9].*"))
            return "Weak password! Password should have at least one digit.";

        if (!password.matches(".*[^a-zA-Z0-9|_].*"))
            return "Weak password! Password should have at least one character except english letters and digits.";

        else return "";
    }
    public void buttonrun(){
        back.setLayoutY(10);
        back.setLayoutX(10);
        back.setStyle("-fx-background-color:rgba(32,253,143,0.65);");
        pane.getChildren().add(back);
        EnterAs.setLayoutX(60);
        EnterAs.setLayoutY(220);
        pane.getChildren().add(EnterAs);
        choice.setLayoutY(190);
        choice.setLayoutX(60);
        pane.getChildren().add(choice);
        choice.setStyle("-fx-font-size: 15;-fx-font-family: Arial;-fx-text-fill: red");
        textField.setLayoutX(300);
        textField.setLayoutY(620);
        textField1.setLayoutX(300);
        textField1.setLayoutY(570);
        button.setLayoutX(347);
        button.setLayoutY(670);
        button.setStyle("-fx-background-color:rgba(32,253,143,0.65);");
        label.setLayoutY(260);
        label.setLayoutX(140);
        label.setStyle("-fx-text-fill: #ff0000;-fx-font-family: Arial;-fx-font-size: 20");
        pane.getChildren().add(label);
        pane.getChildren().add(textField);
        pane.getChildren().add(button);
    }
}
