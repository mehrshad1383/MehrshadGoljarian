package model;

import javafx.scene.control.Button;
import javafx.scene.image.ImageView;

import javax.swing.*;

public class ButtonV2 {
    private Order order;
    private Button button = new Button();
    public ButtonV2(ImageView imageView , Order order)
    {
        button.setGraphic(imageView);
        this.order = order;
    }

    public Order getOrder() {
        return order;
    }

    public Button getButton() {
        return button;
    }
}
