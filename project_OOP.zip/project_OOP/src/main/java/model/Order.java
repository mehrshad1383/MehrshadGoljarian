package model;

import controller.OrderController;

import java.sql.Time;
import java.util.AbstractMap;
import java.util.ArrayList;

public class Order {

    private int DeliveryCost;
    private String owner;
    private int id;
    private long resturant;
    private String delivery;
    private String Status;
    private long timefordeliverytorestaurant;

    public ArrayList<Integer> getDistanceFromDeliveryToResturant() {
        return DistanceFromDeliveryToResturant;
    }

    public ArrayList<Integer> getDistanceFromDeliveryToCustomer() {
        return DistanceFromDeliveryToCustomer;
    }

    private ArrayList<Integer> DistanceFromDeliveryToResturant;
    private ArrayList<Integer> DistanceFromDeliveryToCustomer;
    private long finaltime;
    public void setFinaltime(long finaltime) {
        this.finaltime = finaltime;
    }
    public long getFinaltime() {
        return finaltime;
    }

    private long timefordeliverytoCustomer;

//   1 WaitingForRestuarantConfirmation
//   2 Confirmed_IsCooking
//   3 Delivery
//   4 Recieved
//   5 UserCommented_FullyFinished
//   6 Not ordered

    public String translateStatus(){
        if(Status.equals("1")){
            return "WaitingForRestuarantConfirmation";
        }
        if(Status.equals("2")){
            return "Confirmed_IsCooking";
        }
        if(Status.equals("3")){
            return "Delivery";
        }
        if(Status.equals("4")){
            return "Recieved";
        }
        if(Status.equals("5")){
            return "UserCommented_FullyFinished";
        }
        return "Not ordered";
    }
    private ArrayList<Cart> orderedfoods = new ArrayList<>();

    public long getTimefordeliverytorestaurant() {
        return timefordeliverytorestaurant;
    }

    public long getTimefordeliverytoCustomer() {
        return timefordeliverytoCustomer;
    }

    public void setTimefordeliverytorestaurant(long timefordeliverytorestaurant) {
        this.timefordeliverytorestaurant = timefordeliverytorestaurant;
    }

    public void setDelivery(Delivery delivery) {
        this.delivery = delivery.getName();
    }

    public int getDeliveryCost() {
        return DeliveryCost;
    }

    public Delivery getDelivery() {
        for (int i = 0; i < FileManager.getFileManagerInstance().deliveries.size(); i++) {

            if(FileManager.getFileManagerInstance().deliveries.get(i).getName().equals(delivery))
                return FileManager.getFileManagerInstance().deliveries.get(i);
        }
        return null;
    }

    public void setDistanceFromDeliveryToResturant(ArrayList<Integer> distanceFromDeliveryToResturant) {
        DistanceFromDeliveryToResturant = distanceFromDeliveryToResturant;
    }

    public Order(Customer customer, Resturant resturant, int id, Cart cart ,
                 long timefordeliverytoCustomer , int DeliveryCost , ArrayList<Integer> DistanceFromDeliveryToCustomer){
        this.id=id;
        this.owner=customer.getName();
        this.resturant = resturant.getId();
        this.orderedfoods.add(cart);
        this.Status="WaitingForRestuarantConfirmation";
        this.timefordeliverytoCustomer=timefordeliverytoCustomer;
        this.DeliveryCost = DeliveryCost;
        this.finaltime= 0;
        this.delivery = "not_set";
//        this.orderSituation="";
        this.timefordeliverytorestaurant=0;
        this.orderprice=0;
        this.DistanceFromDeliveryToCustomer = DistanceFromDeliveryToCustomer;
    }
    public Order(){

    }
    public String allFoodStrings(){
        StringBuilder a = new StringBuilder("");
        for (int i = 0; i < orderedfoods.size(); i++) {
            for (int j = 0; j <orderedfoods.get(i).getFoods().size() ; j++) {
                a.append(orderedfoods.get(i).getFoods().get(j).getName());
            }
        }
        return a.toString();
    }
    public void setOwner(Customer owner) {
        this.owner = owner.getName();
    }


    public void setId(int id) {
        this.id = id;
    }


    public Resturant getResturant() {
        for (int i = 0; i < FileManager.getFileManagerInstance().resturants.size(); i++) {
            if(FileManager.getFileManagerInstance().resturants.get(i).getId()==resturant)
                return FileManager.getFileManagerInstance().resturants.get(i);
        }
        return null;
    }

    public void setResturant(Resturant resturant) {
        this.resturant = resturant.getId();
    }

    public void setOrderprice(double orderprice) {
        this.orderprice = orderprice;
    }

//    public void setOrderSituation(String orderSituation) {
//        this.orderSituation = orderSituation;
//    }

    public void setStatus(String status) {

        Status = status;

    }

    private double orderprice = 0;

//    private String orderSituation;

    public Customer getOwner() {
        for (int i = 0; i <FileManager.getFileManagerInstance().customers.size() ; i++) {
            if(FileManager.getFileManagerInstance().customers.get(i).getName().equals(owner))
                return FileManager.getFileManagerInstance().customers.get(i);
        }
        return null;
    }


    public int getId() {
        return id;
    }

    public ArrayList<Cart> getOrderedfoods() {
        return orderedfoods;
    }

    public void setOrderedfoods(ArrayList<Cart> orderedfoods) {
        this.orderedfoods = orderedfoods;
    }

    public double getOrderprice() {
        return orderprice;
    }

//    public String getOrderSituation() {
//        return orderSituation;
//    }

    public String getStatus() {
        return Status;
    }

}
