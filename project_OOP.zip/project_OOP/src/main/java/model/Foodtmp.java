package model;

import controller.AdminResturantMenuController;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import view.*;

import java.io.IOException;
import java.net.URL;

public class Foodtmp extends Pane {

    String name;
    String id;
    String price;
    String info;
    String rate ;
    String picturePlace ;
    Food food;
    Resturant resturant;
    boolean isAdmin = false;
    public AdminResturantMenu adminResturantMenu;

    public Foodtmp(String nm , String pr, String rt , String inof , String url , String idd,Food food,Resturant resturant){
        this.name=nm;
        this.price=pr;
        this.rate=rt;
        this.info=inof;
        this.picturePlace=url;
        this.id=idd;
        this.food=food;
        this.resturant = resturant;
    }
    public Foodtmp(String nm , String pr, String rt , String inof , String url , String idd,Food food,Resturant resturant,boolean a , AdminResturantMenu b){
        this.name=nm;
        this.price=pr;
        this.rate=rt;
        this.info=inof;
        this.picturePlace=url;
        this.id=idd;
        this.food=food;
        this.resturant = resturant;
        isAdmin=true;
        adminResturantMenu=b;
    }
    public Pane getInstance() throws IOException {

        Pane pane =   FXMLLoader.load(new URL(Main.class.getResource("/FXML/mio.fxml").toExternalForm()));
// first one is the picture!
        ImageView imageView = (ImageView)(pane.getChildren().get(0));
        Image image = new Image(Main.class.getResource(picturePlace).toExternalForm());
        imageView.setImage(image);

// next one is name
        ((Label)pane.getChildren().get(1)).setText(name);
// next one is price
        ((Label)pane.getChildren().get(2)).setText(price);
// next one is info
        ((Label)pane.getChildren().get(3)).setText(info);
// next one is id
        ((Label)pane.getChildren().get(4)).setText(id);
// next one is order button
        ((Button)pane.getChildren().get(5)).setText("SELECT");
        if(isAdmin)
            ((Button)pane.getChildren().get(5)).setText("EDIT");
        if(isAdmin)
        {((Button) pane.getChildren().get(5)).setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                Main.adminResturantMenu.getAdminResturantMenuController().EditFood(food,adminResturantMenu);
            }
        });
        }else {
            ((Button) pane.getChildren().get(5)).setOnMouseClicked(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent event) {
                    try {
                        new FoodMenu(food, Customer.getLoggedInCustomer(), resturant, Main.mediaPlayer).start(LoginMenu.stage);
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                }
            });
        }
// next one is rate
        ((Label)pane.getChildren().get(6)).setText(rate);
        String Loc = Main.class.getResource("/CSS/try.css").toExternalForm();
        pane.getStylesheets().add(Loc);
        pane.setStyle("  -fx-background-radius: 20,10,0; -fx-background-color: rgb(35,36,39);");

        return pane;
    }
}
