
package model;

import javafx.scene.layout.VBox;
import javafx.scene.media.MediaPlayer;

import java.io.IOException;
import java.util.ArrayList;

public class Resturant {
    private String name;
    private int id;
    private String resturantOwner;
    private Mapi Location;
    private ArrayList<Food> foods;
    private ArrayList<String> restaurantType;
    private ArrayList<Order> orders;
    private ArrayList<Comment> comments;
    public static ArrayList<Restauranttmp> restauranttmps = new ArrayList<>();
    public static ArrayList<Foodtmp> foodtmps = new ArrayList<>();
    public static ArrayList<CommentTmp> commentTmps = new ArrayList<>();
//    private static ArrayList<Resturant> Allresturants = FileManager.getFileManagerInstance().resturants;

    public Resturant(String name, int id, Mapi location,ArrayList<String> types) {
        this.name = name;
        this.id = id;
        this.Location = location;
        this.foods = new ArrayList();
        this.orders = new ArrayList();
        this.comments = new ArrayList();
        this.restaurantType=types;
        this.resturantOwner = "";
        FileManager.getFileManagerInstance().resturants.add(this);
        FileManager.saveAllDatas();
    }

    public static ArrayList<Restauranttmp> getRestauranttmps() {
        return restauranttmps;
    }

    public static ArrayList<Foodtmp> getFoodtmps() {
        return foodtmps;
    }

    public static ArrayList<CommentTmp> getCommentTmps() {
        return commentTmps;
    }

    public static void setCommentTmps(ArrayList<CommentTmp> commentTmps) {
        Resturant.commentTmps = commentTmps;
    }

    public static void setFoodtmps(ArrayList<Foodtmp> foodtmps) {
        Resturant.foodtmps = foodtmps;
    }

    public static void setRestauranttmps(ArrayList<Restauranttmp> restauranttmps) {
        Resturant.restauranttmps = restauranttmps;
    }

    public ArrayList<Comment> getComments() {
        return this.comments;
    }

    public void setComments(ArrayList<Comment> comments) {
        this.comments = comments;
    }

    public static String searchResturant(String name) {
        String list = "";

        for(int i = 0; i < FileManager.getFileManagerInstance().resturants.size(); ++i) {
            if (((Resturant)FileManager.getFileManagerInstance().resturants.get(i)).name.equals(name)) {
                list = list + ((Resturant)FileManager.getFileManagerInstance().resturants.get(i)).name + "  Id= " + ((Resturant)FileManager.getFileManagerInstance().resturants.get(i)).id + "\n";
            }
        }

        return list;
    }
    public ArrayList<String> getRestaurantType(){return restaurantType;}

    public static int returnindexbyname(int id) {
        String list = "";

        for(int i = 0; i < FileManager.getFileManagerInstance().resturants.size(); ++i) {
            if (((Resturant)FileManager.getFileManagerInstance().resturants.get(i)).id == id) {
                return id;
            }
        }

        return -1;
    }

    public static Resturant returnResturantByIndex(int id) {
        for (int i = 0; i < FileManager.getFileManagerInstance().resturants.size(); i++) {
            if(FileManager.getFileManagerInstance().resturants.get(i).getId()==id){
                return FileManager.getFileManagerInstance().resturants.get(i);
            }
        }
        return null;
    }
    public static int[] sortrestaurant(Customer customer){
        int[] list = new int[FileManager.getFileManagerInstance().resturants.size()];
        for(int i=0;i<FileManager.getFileManagerInstance().resturants.size();i++){
            list[i]=0;
        }
        int[] sort = new int[FileManager.getFileManagerInstance().resturants.size()];
        for(int i=0;i<FileManager.getFileManagerInstance().resturants.size();i++){
            sort[i]=i;
        }
        for(int i=0;i<customer.getCompletedorders().size();i++){
            list[customer.getCompletedorders().get(i).getResturant().getId()-1000000]++;
        }
        int check=0;
        int index=0;
        for(int i=0;i<FileManager.getFileManagerInstance().resturants.size();i++){
            check=list[i];
            index=i;
            for (int j=i;j<FileManager.getFileManagerInstance().resturants.size();j++){
                if(check<list[j]){
                    check = list[j];
                    index = j;
                }
            }
            int a=list[index];
            list[index]=list[i];
            list[i]=a;
            a=sort[index];
            sort[index]=sort[i];
            sort[i]=a;
        }
        return sort;
    }
    public static void swapp(int a,int b){
        int c=a;
        a=b;
        b=c;
    }
    public static VBox showallresturant(Customer customer, VBox vBox, MediaPlayer mediaPlayer) throws IOException {
        String type="";
        String name;
        double rating;
        String rate="";
        int id;
        int sort[] = sortrestaurant(customer);
        for(int i = 0; i < FileManager.getFileManagerInstance().resturants.size(); ++i) {
            name= ((Resturant) FileManager.getFileManagerInstance().resturants.get(sort[i])).name ;
             id=  ((Resturant) FileManager.getFileManagerInstance().resturants.get(sort[i])).id;
             rating = DisplayRating(sort[i]+1000000);
             if(rating==-1)
                 rating=0;
             rate=rating+" from ";
             rate=rate+NumberOfRating(sort[i]+1000000)+" vote";
            for (int j = 0; j < ((Resturant) FileManager.getFileManagerInstance().resturants.get(sort[i])).restaurantType.size(); j++) {
                type= type+  ((Resturant) FileManager.getFileManagerInstance().resturants.get(sort[i])).restaurantType.get(j)+"-";
            }
            StringBuilder b = new StringBuilder(type.trim());
            type= b.deleteCharAt(b.length()-1).toString();
            Restauranttmp restauranttmp =new Restauranttmp(name,type,rate+"","20000","/Image/pic2.png",id+"",FileManager.getFileManagerInstance().resturants.get(sort[i]));
            restauranttmps.add(restauranttmp);
            vBox.getChildren().add(restauranttmp.getInstance());
        }

        return vBox;
    }

    public static VBox ListOfResturant(int index,VBox vBox,Resturant resturant,MediaPlayer mediaPlayer) throws IOException {
        String list = "";
        String name;
        double price;
        String rating1;
        int id;
        double rating;
        int index1=index-1000000;
        for(int i = 0; i < ((Resturant)FileManager.getFileManagerInstance().resturants.get(index1)).foods.size(); ++i) {
            list="";
            rating=RatingFood(index,(i+2000000));
            if (rating<0){
                rating=0;
            }
            rating1 = rating +" from "+numOfRatingFood(index,i+2000000)+" vote";
             name= ((Food)((Resturant)FileManager.getFileManagerInstance().resturants.get(index1)).foods.get(i)).getName() ;
                    id= ((Food)((Resturant)FileManager.getFileManagerInstance().resturants.get(index1)).foods.get(i)).getId() ;
            price= ((Food)((Resturant)FileManager.getFileManagerInstance().resturants.get(index1)).foods.get(i)).getPrice() ;
                    list=list+ "THE FOOD's DISCOUNT= " + ((Food)((Resturant)FileManager.getFileManagerInstance().resturants.get(index1)).foods.get(i)).getDiscount() + "%  \n";
            if (((Food)((Resturant)FileManager.getFileManagerInstance().resturants.get(index1)).foods.get(i)).isActivated()) {
                list = list + "THE FOOD IS Active  ";
            } else {
                list = list + "THE FOOD IS Inactive  ";
            }
            Foodtmp foodtmp =new Foodtmp(name,price+"",rating1,list,"/Image/pic1.png",id+"",FileManager.getFileManagerInstance().resturants.get(index1).getFoods().get(i),resturant);
            foodtmps.add(foodtmp);
            vBox.getChildren().add(foodtmp.getInstance());
        }
        return vBox;
    }

    public static VBox SearchFood(int index, String name,VBox vBox,Resturant resturant,MediaPlayer mediaPlayer) throws IOException {
        String list = "";
        String name1;
        double price;
        String rating1="";
        int id;
        int index1=index-1000000;
        for(int i = 0; i < ((Resturant)FileManager.getFileManagerInstance().resturants.get(index1)).foods.size(); ++i) {
            if (((Food)((Resturant)FileManager.getFileManagerInstance().resturants.get(index1)).foods.get(i)).getName().equals(name)) {
                name1= ((Food)((Resturant)FileManager.getFileManagerInstance().resturants.get(index1)).foods.get(i)).getName() ;
                 id= ((Food)((Resturant)FileManager.getFileManagerInstance().resturants.get(index1)).foods.get(i)).getId() ;
                price=((Food)((Resturant)FileManager.getFileManagerInstance().resturants.get(index1)).foods.get(i)).getPrice() ;
                list=list+ "THE FOOD's DISCOUNT= "+ ((Food)((Resturant)FileManager.getFileManagerInstance().resturants.get(index1)).foods.get(i)).getDiscount() + "%  ";
                if (((Food)((Resturant)FileManager.getFileManagerInstance().resturants.get(index1)).foods.get(i)).isActivated()) {
                    list = list + "THE FOOD IS Active  ";
                } else {
                    list = list + "THE FOOD IS Inactive  ";
                }
                rating1 = rating1 +"RATING= "+ ((Food)((Resturant)FileManager.getFileManagerInstance().resturants.get(index1)).foods.get(i)).getRating()+" from "+numOfRatingFood(index,i+2000000)+" vote\n";
                Foodtmp foodtmp =new Foodtmp(name,price+"",rating1,list,"/Image/pic1.png",id+"",FileManager.getFileManagerInstance().resturants.get(index1).getFoods().get(i),resturant);
                foodtmps.add(foodtmp);
                vBox.getChildren().add(foodtmp.getInstance());
            }
        }

        return vBox;
    }

    public static int returnIndexRefid(int id, int index) {
        index = index-1000000;
        id = id ;
        for(int i = 0; i < ((Resturant)FileManager.getFileManagerInstance().resturants.get(index)).foods.size(); i++) {
            if (((Food)((Resturant)FileManager.getFileManagerInstance().resturants.get(index)).foods.get(i)).getId() == id) {
                return i;
            }
        }

        return -1;
    }

    public static Food returnFoodByIndex(int indexFood, int indexResturant) {
        indexResturant=indexResturant-1000000;
        indexFood = indexFood - 2000000;
        return (Food)((Resturant)FileManager.getFileManagerInstance().resturants.get(indexResturant)).foods.get(indexFood);
    }

    public static VBox ShowAllCommand(int index,VBox vBox) throws IOException {
        String list = "";
        String name;
        String id;
        String rating="";
        double rate;
            for(int i = 0; i < ((Resturant)FileManager.getFileManagerInstance().resturants.get(index)).comments.size(); ++i) {
                id="ID= "+i;
                 list=((Comment)((Resturant)FileManager.getFileManagerInstance().resturants.get(index)).comments.get(i)).getContent() ;
                 name=((Resturant)FileManager.getFileManagerInstance().resturants.get(index)).comments.get(i).getCustomer().getName();
                 rate=((Resturant)FileManager.getFileManagerInstance().resturants.get(index)).comments.get(i).getRating();
                 if(rate<0){
                     rate = 0;
                 }
                 rating = "Rating= "+rate;
                 if(rate==0){
                     rating = "no rated";
                 }
                CommentTmp commentTmp = new CommentTmp(name, list, rating , "/Image/pic1.png", id );
                commentTmps.add(commentTmp);
                vBox.getChildren().add(commentTmp.getInstance());
            }

            return vBox;
        }

    public static void ADDNewComment(String content, Customer customer, int index) {
        Comment comment = new Comment(customer, content);
        ((Resturant)FileManager.getFileManagerInstance().resturants.get(index)).comments.add(comment);
    }

    public static int ReturnNumberOfComment(int index) {
        return ((Resturant)FileManager.getFileManagerInstance().resturants.get(index)).comments.size() - 1;
    }

    public static Customer ReturnCustomerFromid(int index, int id) {
        return ((Comment)((Resturant)FileManager.getFileManagerInstance().resturants.get(index)).comments.get(id)).getCustomer();
    }

    public static void EditComment(String content, int index, int id) {
        ((Comment)((Resturant)FileManager.getFileManagerInstance().resturants.get(index)).comments.get(id)).setContent(content);
    }

    public static double DisplayRating(int index) {
        int cnt = 0;
        double sum = 0.0;
        index=index-1000000;
        for(int i = 0; i < ((Resturant)FileManager.getFileManagerInstance().resturants.get(index)).comments.size(); ++i) {
            if (((Comment)((Resturant)FileManager.getFileManagerInstance().resturants.get(index)).comments.get(i)).getRating() >= 0.0) {
                ++cnt;
                sum += ((Comment)((Resturant)FileManager.getFileManagerInstance().resturants.get(index)).comments.get(i)).getRating();
            }
        }

        if (cnt == 0) {
            return -1.0;
        } else {
            return sum / (double)cnt;
        }
    }

    public static int NumberOfRating(int index) {
        int cnt = 0;
        index=index-1000000;
        for(int i = 0; i < ((Resturant)FileManager.getFileManagerInstance().resturants.get(index)).comments.size(); ++i) {
            if (((Comment)((Resturant)FileManager.getFileManagerInstance().resturants.get(index)).comments.get(i)).getRating() >= 0.0) {
                cnt++;
            }
        }

        return cnt;
    }

    public static int CheckForHisRating(Customer customer, int index) {
        for(int i = 0; i < ((Resturant)FileManager.getFileManagerInstance().resturants.get(index)).comments.size(); ++i) {
            if (((Comment)((Resturant)FileManager.getFileManagerInstance().resturants.get(index)).comments.get(i)).getCustomer().equals(customer)) {
                return i;
            }
        }

        return -1;
    }

    public static VBox showAllComment(int indexresturant, int indexfood,VBox vBox) throws IOException {
        String list="";
        String name;
        String rating="";
        int id;
        String answer="";
        //if (((Food)((Resturant)FileManager.getFileManagerInstance().resturants.get(indexresturant)).foods.get(indexfood)).getComments().size() < 1) {
           // list=list+"There are no comments for this food";
       // }
            for(int i = 0; i < ((Food)((Resturant)FileManager.getFileManagerInstance().resturants.get(indexresturant)).foods.get(indexfood)).getComments().size(); ++i) {
                if (((Food) ((Resturant) FileManager.getFileManagerInstance().resturants.get(indexresturant)).foods.get(indexfood)).getComments().get(i).isAnswered())
                {
                    id = i;
                    answer = ((Food)((Resturant)FileManager.getFileManagerInstance().resturants.get(indexresturant)).foods.get(indexfood)).getComments().get(i).getResponse();
                    list = ((Comment) ((Food) ((Resturant) FileManager.getFileManagerInstance().resturants.get(indexresturant)).foods.get(indexfood)).getComments().get(i)).getContent();
                    name = ((Comment) ((Food) ((Resturant) FileManager.getFileManagerInstance().resturants.get(indexresturant)).foods.get(indexfood)).getComments().get(i)).getCustomer().getName();
                    rating = rating + "RATING= " + ((Food) ((Resturant) FileManager.getFileManagerInstance().resturants.get(indexresturant)).foods.get(indexfood)).getComments().get(i).getRating() ; ;
                    if(((Food) ((Resturant) FileManager.getFileManagerInstance().resturants.get(indexresturant)).foods.get(indexfood)).getComments().get(i).getRating()<0){
                        rating = "no rated";
                    }
                    CommentTmp commentTmp = new CommentTmp(name, list, rating,answer , "/Image/pic1.png", id + "");
                    commentTmps.add(commentTmp);
                    vBox.getChildren().add(commentTmp.getInstance());
            }
                else{
                    id = i;
                    list = ((Comment) ((Food) ((Resturant) FileManager.getFileManagerInstance().resturants.get(indexresturant)).foods.get(indexfood)).getComments().get(i)).getContent();
                    name = ((Comment) ((Food) ((Resturant) FileManager.getFileManagerInstance().resturants.get(indexresturant)).foods.get(indexfood)).getComments().get(i)).getCustomer().getName();
                    rating = rating + "RATING= " + ((Food) ((Resturant) FileManager.getFileManagerInstance().resturants.get(indexresturant)).foods.get(indexfood)).getComments().get(i).getRating() ;
                    if(((Food) ((Resturant) FileManager.getFileManagerInstance().resturants.get(indexresturant)).foods.get(indexfood)).getComments().get(i).getRating()<0){
                        rating = "no rated";
                    }
                    CommentTmp commentTmp = new CommentTmp(name, list, rating , "/Image/pic1.png", id + "");
                    commentTmps.add(commentTmp);
                    vBox.getChildren().add(commentTmp.getInstance());
                }

            }

        return vBox;
    }

    public static void setrating(int indexresturant, int indexcomment, double rating) {
        ((Comment)((Resturant)FileManager.getFileManagerInstance().resturants.get(indexresturant)).comments.get(indexcomment)).setRating(rating);
    }
    public static Double getrating(int indexrestaurant,int indexcomment){
        return ((Comment)((Resturant)FileManager.getFileManagerInstance().resturants.get(indexrestaurant)).comments.get(indexcomment)).getRating();
    }

    public static void commentForFood(int indexresturant, int indexfood, String content, Customer customer) {
        Comment comment = new Comment(customer, content);
        ((Food)((Resturant)FileManager.getFileManagerInstance().resturants.get(indexresturant)).foods.get(indexfood)).getComments().add(comment);
    }

    public static int returnnumCommitForFood(int indexresturant, int indexfood) {
        return ((Food)((Resturant)FileManager.getFileManagerInstance().resturants.get(indexresturant)).foods.get(indexfood)).getComments().size();
    }

    public static boolean checkCommitFoodByCustomer(int indexresturant, int indexfood, Customer customer, int id) {
        return ((Comment)((Food)((Resturant)FileManager.getFileManagerInstance().resturants.get(indexresturant)).foods.get(indexfood)).getComments().get(id)).getCustomer().equals(customer);
    }

    public static void EditCommitForFood(int id, String content, int indexresturant, int indexfood) {
        ((Comment)((Food)((Resturant)FileManager.getFileManagerInstance().resturants.get(indexresturant)).foods.get(indexfood)).getComments().get(id)).setContent(content);
    }

    public static int CheckForCommitOrNot(int indexresturant, int indexfood, Customer customer) {
        for(int i = 0; i < ((Food)((Resturant)FileManager.getFileManagerInstance().resturants.get(indexresturant)).foods.get(indexfood)).getComments().size(); ++i) {
            if (((Comment)((Food)((Resturant)FileManager.getFileManagerInstance().resturants.get(indexresturant)).foods.get(indexfood)).getComments().get(i)).getCustomer().equals(customer)) {
                return i;
            }
        }

        return -1;
    }

    public static void SubmitRatingForFood(int indexresturant, int indexfood, double rating, int id) {
        ((Comment)((Food)((Resturant)FileManager.getFileManagerInstance().resturants.get(indexresturant)).foods.get(indexfood)).getComments().get(id)).setRating(rating);
    }

    public static double ReturnRatingOfFood(int indexresturant, int indexfood, int id) {
        return ((Comment)((Food)((Resturant)FileManager.getFileManagerInstance().resturants.get(indexresturant)).foods.get(indexfood)).getComments().get(id)).getRating();
    }

    public static double RatingFood(int indexresturant, int indexfood) {
        indexresturant=indexresturant-1000000;
        indexfood=indexfood-2000000;
        double sum = 0.0;
        int cnt = 0;
        for(int i = 0; i < ((Food)((Resturant)FileManager.getFileManagerInstance().resturants.get(indexresturant)).foods.get(indexfood)).getComments().size(); ++i) {
            if (((Comment)((Food)((Resturant)FileManager.getFileManagerInstance().resturants.get(indexresturant)).foods.get(indexfood)).getComments().get(i)).getRating() >= 0.0) {
                sum += ((Comment)((Food)((Resturant)FileManager.getFileManagerInstance().resturants.get(indexresturant)).foods.get(indexfood)).getComments().get(i)).getRating();
                ++cnt;
            }
        }
        if (cnt == 0) {
            return -1.0;
        } else {
            return sum / (double)cnt;
        }
    }

    public static int numOfRatingFood(int indexresturant, int indexfood) {
        int cnt = 0;
        indexresturant=indexresturant-1000000;
        indexfood=indexfood-2000000;
        for(int i = 0; i < ((Food)((Resturant)FileManager.getFileManagerInstance().resturants.get(indexresturant)).foods.get(indexfood)).getComments().size(); ++i) {
            if (((Comment)((Food)((Resturant)FileManager.getFileManagerInstance().resturants.get(indexresturant)).foods.get(indexfood)).getComments().get(i)).getRating() >= 0.0) {
                ++cnt;
            }
        }
        return cnt;
    }

    public String getName() {
        return this.name;
    }

    public int getId() {
        return this.id;
    }

    public ResturantOwner getResturantOwner() {
        for (int i = 0; i < FileManager.getFileManagerInstance().resturantOwners.size(); i++) {
            if(FileManager.getFileManagerInstance().resturantOwners.get(i).getName().equals(resturantOwner))
                return FileManager.getFileManagerInstance().resturantOwners.get(i);
        }
        return null;
    }

    public ArrayList<Food> getFoods() {
        return this.foods;
    }

    public ArrayList<Order> getOrders() {
        return this.orders;
    }

    public static ArrayList<Resturant> getAllresturants() {
        return FileManager.getFileManagerInstance().resturants;
    }

    public Mapi getLocation() {
        return this.Location;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setResturantOwner(ResturantOwner resturantOwner) {
        this.resturantOwner = resturantOwner.getName();
    }

    public void setFoods(ArrayList<Food> foods) {
        this.foods = foods;
    }

    public void setOrders(ArrayList<Order> orders) {
        this.orders = orders;
    }

    public static void setAllresturants(ArrayList<Resturant> allresturants) {
        FileManager.getFileManagerInstance().resturants = allresturants;
    }

    public void setLocation(Mapi location) {
        this.Location = location;
    }

//    static {
//        FileManager.getFileManagerInstance().resturants = FileManager.getFileManagerInstance().resturants;
//    }

    public boolean hasActiveOrder(){
        for (int i = 0; i < orders.size(); i++) {
            if(orders.get(i).getStatus().equals("4") ||orders.get(i).getStatus().equals("5") ){
            }
            else {
                return true;
            }
        }
        return false;
    }
    public boolean hasActiveOrder(Food a){
        for (int i = 0; i < orders.size(); i++) {
            if(orders.get(i).getStatus().equals("4") ||orders.get(i).getStatus().equals("5") ){
            } else if (orders.get(i).getOrderedfoods().contains(a)) {
                return true;
            }
        }
        return false;
    }
    public void setRestaurantType(ArrayList<String> a){
        restaurantType=a;
    }
    public Food findFoodByID(int a){
        for (int i = 0; i < this.foods.size(); i++) {
            if(this.foods.get(i).getId()==a)
                return this.foods.get(i);
        }
        return null;
    }
    public boolean checkIdfood(int a){
        for (int i = 0; i < this.foods.size(); i++) {
            if(this.foods.get(i).getId()==a)
                return true;
        }
        return false;
    }
    public void addFoodToFoods(Food a){
        foods.add(a);
    }
    public static int ReturnIndexFromRestaurant(Resturant resturant){
        for(int i=0;i<FileManager.getFileManagerInstance().resturants.size();i++){
            if(FileManager.getFileManagerInstance().resturants.get(i).equals(resturant)){
                return i;
            }
        }
        return -1;
    }
    public static int ReturnIndexFood(int indexrestaurant,Food food){
        for(int i=0;i<FileManager.getFileManagerInstance().resturants.get(indexrestaurant).getFoods().size();i++){
            if(FileManager.getFileManagerInstance().resturants.get(indexrestaurant).getFoods().get(i).equals(food)){
                return i;
            }
        }
        return -1;
    }

    public void UpdateOrders()
    {
        System.out.println(this.name);
        ArrayList<Order> temp = new ArrayList<>();
        for(int i = 0 ; i<FileManager.getFileManagerInstance().customers.size() ; i++)
        {
            for(int j = 0 ; j<FileManager.getFileManagerInstance().customers.get(i).getCompletedorders().size() ; j++)
            {
                if(FileManager.getFileManagerInstance().customers.get(i).getCompletedorders().get(j).getResturant().getId()==this.id)
                {
                    temp.add(FileManager.getFileManagerInstance().customers.get(i).getCompletedorders().get(j));
                }
            }
        }
        this.orders = temp;
    }

}