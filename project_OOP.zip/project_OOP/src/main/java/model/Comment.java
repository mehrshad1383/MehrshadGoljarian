package model;

public class Comment {
    private String customer;
    private double rating;
    private String content;
    private boolean isAnswered;
    private String response;
    private int id ;
    public Comment(Customer customer, String content) {
        this.customer = customer.getName();
        this.rating =-1;
        this.content = content;
        this.response="";
        this.isAnswered = false;
        FileManager.saveAllDatas();
    }
    public Comment(){

    }
    public void Answer(String response){
        this.response=response;
        isAnswered=true;
    }

    public void setId(int a){
        id=a;
    }
    public int getId(){
        return id;
    }
    public void setCustomer(Customer customer) {
      this.customer=customer.getName();
    }

    public void setRating(double rating) {
        this.rating = rating;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public void setAnswered(boolean answered) {
        isAnswered = answered;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public Customer getCustomer() {
        for (int i = 0; i < FileManager.getFileManagerInstance().customers.size(); i++) {
            if(FileManager.getFileManagerInstance().customers.get(i).getName().equals(customer))
                return FileManager.getFileManagerInstance().customers.get(i);
        }
        return null;
    }

    public double getRating() {
        return rating;
    }

    public String getContent() {
        return content;
    }

    public boolean isAnswered() {
        return isAnswered;
    }

    public String getResponse() {
        return response;
    }
}
