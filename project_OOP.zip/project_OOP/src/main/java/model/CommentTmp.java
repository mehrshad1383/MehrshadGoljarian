package model;

import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import view.Main;

import java.io.IOException;
import java.net.URL;

public class CommentTmp extends Pane
{
    String User_Name;
    String Comment_Info;
    String rate ;
    String Answer;
    String picturePlace;
    String Order_id;
    public CommentTmp(String User_Name,
                      String Comment_Info,
                      String rate ,
                      String Answer,
                      String picturePlace,
                      String Order_id){
        this.User_Name=User_Name;
        this.Comment_Info=Comment_Info;
        this.Answer =Answer;
        this.rate=rate;
        this.picturePlace=picturePlace;
        this.picturePlace=picturePlace;
        this.Order_id=Order_id;
    }
    public CommentTmp(String User_Name,
                      String Comment_Info,
                      String rate ,
                      String picturePlace,
                      String Order_id){
        this.User_Name=User_Name;
        this.Comment_Info=Comment_Info;
        this.rate=rate;
        this.Answer ="not answered";
        this.picturePlace=picturePlace;
        this.picturePlace=picturePlace;
        this.Order_id=Order_id;
    }
    public void tapOnChoose(){
//        write
//        anyThing
//        it
//        needs
    }
    public Pane getInstance() throws IOException {

        Pane pane =   FXMLLoader.load(new URL(Main.class.getResource("/FXML/comment.fxml").toExternalForm()));
// first one is the picture!
        ImageView imageView = (ImageView)(pane.getChildren().get(0));
        Image image = new Image(Main.class.getResource(picturePlace).toExternalForm());
        imageView.setImage(image);
        imageView.setStyle("    -fx-padding: 200;\n" +
                "    -fx-background-color: #8c00ff;\n" +
                "    -fx-background-radius: 15;\n" +
                "    -fx-image-radius: 20,10,0;\n" +
                "    -fx-image-insets: 0,10,20;");
// next one is name
        ((Label)pane.getChildren().get(1)).setText(User_Name);
// next one is rate
        ((Label)pane.getChildren().get(2)).setText(rate);
// next one is detail
        ((Label)pane.getChildren().get(3)).setText(Comment_Info);
// next one is answer
        ((Label)pane.getChildren().get(4)).setText(Answer);
        if(Answer.equals("not answered"))
            ((Label)pane.getChildren().get(4)).setVisible(false);
// next one is id
        ((Label)pane.getChildren().get(5)).setText(Order_id);
        ((Label)pane.getChildren().get(5)).setAlignment(Pos.CENTER);
// next one is button order
        String Loc = Main.class.getResource("/CSS/try.css").toExternalForm();
        pane.getStylesheets().add(Loc);
        pane.setStyle("  -fx-background-radius: 20,10,0; -fx-background-color:rgba(229,8,184,0.12);");

        return pane;
    }
}
