package model;

import java.util.ArrayList;

public class Cart {
    private String customer;
    private String resturant;
    private ArrayList<Food> foods;
    private double cost;

    public Cart(Customer customer,Resturant resturan,double cost){
        this.customer=customer.getName();
        this.resturant=resturan.getName();
        this.cost=cost;
        foods = new ArrayList<>();
        FileManager.saveAllDatas();
    }
    public Cart(){

    }

    public Customer getCustomer() {
        for (int i = 0; i < FileManager.getFileManagerInstance().customers.size(); i++) {
            if(FileManager.getFileManagerInstance().customers.get(i).getName().equals(customer)){
                return FileManager.getFileManagerInstance().customers.get(i);
            }
        }
        return null;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer.getName();
    }

    public Resturant getResturant(){
        for (int i = 0; i < FileManager.getFileManagerInstance().resturants.size(); i++) {
            if(FileManager.getFileManagerInstance().resturants.get(i).getName().equals(resturant))
                return FileManager.getFileManagerInstance().resturants.get(i);
        }
        return null;
    }


    public void setResturant(Resturant resturant) {
        this.resturant = resturant.getName();
    }

    public ArrayList<Food> getFoods() {
        return foods;
    }

    public void setFoods(ArrayList<Food> foods) {
        this.foods = foods;
    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }
}
