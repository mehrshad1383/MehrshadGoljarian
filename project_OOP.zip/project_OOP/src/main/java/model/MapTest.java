//package model;
//
//import controller.OrderControllertest;
//import controller.TraficMaker;
//import javafx.animation.AnimationTimer;
//import javafx.application.Application;
//import javafx.fxml.FXML;
//import javafx.fxml.FXMLLoader;
//import javafx.geometry.Insets;
//import javafx.scene.Scene;
//import javafx.scene.control.Label;
//import javafx.scene.image.Image;
//import javafx.scene.image.ImageView;
//import javafx.scene.layout.Background;
//import javafx.scene.layout.BackgroundFill;
//import javafx.scene.layout.CornerRadii;
//import javafx.scene.layout.Pane;
//import javafx.scene.paint.Color;
//import javafx.scene.paint.ImagePattern;
//import javafx.scene.paint.Paint;
//import javafx.scene.shape.Circle;
//import javafx.scene.shape.Line;
//import javafx.scene.shape.StrokeType;
//import javafx.scene.text.Text;
//import javafx.stage.Stage;
//import view.LoginMenu;
//
//import java.io.IOException;
//import java.net.URL;
//import java.util.ArrayList;
//import java.util.Timer;
//import java.util.TimerTask;
//
//public class MapTest extends Application {
//
//    private Pane pane;
//    public static int mmd = 0;
//    public static ArrayList<Integer> newbie = Map.dijkstraPrinter(23  ,  61);
//    public static OrderControllertest  orderControllertest = new OrderControllertest(Map.dijkstraPrinter(23  ,  61));
//    public Stage stage;
//
//    public static int i = 28;
//
//    public ImageView icon = new ImageView();
//    public ImageView icon2 = new ImageView();
//    public ImageView icon3 = new ImageView();
//    public MapTest()
//    {
//
//    }
//
//    public void start(Stage stage) throws Exception
//    {
////        new Timer().scheduleAtFixedRate(new TimerTask() {
////            public void run() {
////                try {
////                    start(stage);
////                } catch (Exception e) {
////                    throw new RuntimeException(e);
////                }
////            }
////        }, 2000, 2000);new AnimationTimer() {
//
//        if(mmd==0)
//        {
//            initialize();
//        }
//        mmd++;
//        this.stage = stage;
//        stage.setMaximized(true);
//        pane = FXMLLoader.load(new URL(LoginMenu.class.getResource("/FXML/mapTest.fxml").toExternalForm()));
//        Paint paint = new ImagePattern(new Image(LoginMenu.class.getResource("/Image/map.JPG").toExternalForm()));
//        BackgroundFill backgroundFill = new BackgroundFill(paint , CornerRadii.EMPTY, Insets.EMPTY);
//        pane.setBackground(new Background(backgroundFill));
//        pane.setPickOnBounds(true);
//        Image pp = new Image(LoginMenu.class.getResource("/Image/delivery.PNG").toExternalForm());
//        Image pp2 = new Image(LoginMenu.class.getResource("/Image/resturant.PNG").toExternalForm());
//        Image pp3 = new Image(LoginMenu.class.getResource("/Image/customer.PNG").toExternalForm());
//        icon.setImage(pp);
//        icon.setFitHeight(30);
//        icon.setFitWidth(30);
//        icon2.setImage(pp2);
//        icon2.setFitHeight(30);
//        icon2.setFitWidth(30);
//        icon2.setX(30);
//        icon2.setY(30);
//        icon3.setImage(pp3);
//        icon3.setFitHeight(30);
//        icon3.setFitWidth(30);
//        icon3.setX(30);
//        icon3.setY(30);
//        Label label = new Label();
//        label.setGraphic(icon);
//        Label label2 = new Label();
//        label2.setGraphic(icon2);
//        Label label3 = new Label();
//        label3.setGraphic(icon3);
//        label2.setLayoutX(Map.getMapMatrixX()[22]-15);
//        label2.setLayoutY(Map.getMapMatrixY()[22]-15);
//        label3.setLayoutX(Map.getMapMatrixX()[60]-15);
//        label3.setLayoutY(Map.getMapMatrixY()[60]-15);
//        label.setLayoutX(orderControllertest.x-15);
//        label.setLayoutY(orderControllertest.y-15);
//        System.out.println(newbie.get(0));
//        System.out.println(orderControllertest.node);
//        for(int i = 0 ; i<newbie.size()-1 ; i++)
//        {
//            Line line = new Line(Map.getMapMatrixX()[newbie.get(i)-1], Map.getMapMatrixY()[newbie.get(i)-1]
//                    ,Map.getMapMatrixX()[newbie.get(i+1)-1] , Map.getMapMatrixY()[newbie.get(i+1)-1]);
//            line.setStrokeType(StrokeType.OUTSIDE);
//            if(trafic(newbie.get(i+1) , newbie.get(i)).equals("Yellow")){
//                line.setStroke(Color.YELLOW);}
//            else if(trafic(newbie.get(i+1) , newbie.get(i)).equals("Red")){
//                line.setStroke(Color.RED);}
//            else{
//                line.setStroke(Color.BLUE);}
//            line.setStrokeWidth(3);
//            pane.getChildren().addAll(line);
//        }Timer timer = new Timer();
//        pane.getChildren().add(label);
//        pane.getChildren().add(label2);
//        pane.getChildren().add(label3);
//        timer.scheduleAtFixedRate(new TimerTask() {
//            @Override
//            public void run() {
//                label.setLayoutX(orderControllertest.x-15);
//                label.setLayoutY(orderControllertest.y-15);
//            }
//        }, 0, 2);
//        pane.setOnMouseClicked(e -> {
////            Circle circle = new Circle();
////            circle.setCenterX(e.getX());
////            circle.setCenterY(e.getY());
////            circle.setRadius(5);
////            circle.setStroke(Color.DARKSLATEGREY);
////            System.out.println("["+e.getX()+", "+e.getY()+"]");
////            pane.getChildren().add(circle);
//            try {
//                start(stage);
//            } catch (IOException ex) {
//                throw new RuntimeException(ex);
//            } catch (Exception ex) {
//                throw new RuntimeException(ex);
//            }
//        });
//        if (stage.getScene() == null) {
//            Scene scene = new Scene(pane);
//            stage.setScene(scene);
//        } else stage.getScene().setRoot(pane);
//        stage.show();
//    }
//    @FXML
//    public void initialize() throws Exception
//    {
//        System.out.println("pp");
//        Circle circle = new Circle();
//        circle.setCenterX(50);
//        circle.setCenterY(50);
//        circle.setRadius(5);
//        orderControllertest.start();
//    }
//    public String trafic(int node1 , int node2)
//    {
//        TraficMaker traficMaker = new TraficMaker();
//        traficMaker.start();
//        if(Map.MapMatrixV2[node1][node2] - Map.getMapMatrix()[node1][node2] == 2)
//        {
//            return "Red";
//        }
//        if(Map.MapMatrixV2[node1][node2] - Map.getMapMatrix()[node1][node2] == 1)
//        {
//            return "Yellow";
//        }
//
//        return "Blue";
//    }
//}
