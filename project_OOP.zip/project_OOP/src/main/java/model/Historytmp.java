package model;

import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import view.*;

import java.io.IOException;
import java.net.URL;

public class Historytmp extends Pane
{
    String name;
    String info;
    String rate ;
    String postPrice;
    String picturePlace;
    String id;

    public Historytmp(String name,
                         String info,
                         String rate ,
                         String postPrice,
                         String picturePlace,
                         String id
                         ){
        this.name=name;
        this.info=info;
        this.rate =rate;
        this.postPrice=postPrice;
        this.picturePlace=picturePlace;
        this.id=id;
    }
    public Pane getInstance() throws IOException {

        Pane pane =   FXMLLoader.load(new URL(Main.class.getResource("/FXML/history.fxml").toExternalForm()));
// first one is the picture!
        ImageView imageView = (ImageView)(pane.getChildren().get(0));
        Image image = new Image(Main.class.getResource(picturePlace).toExternalForm());
        imageView.setImage(image);
        imageView.setStyle("    -fx-padding: 200;\n" +
                "    -fx-background-color: #8c00ff;\n" +
                "    -fx-background-radius: 15;\n" +
                "    -fx-image-radius: 20,10,0;\n" +
                "    -fx-image-insets: 0,10,20;");
// next one is name
        ((Label)pane.getChildren().get(1)).setText(name);
// next one is price
        ((Label)pane.getChildren().get(2)).setText(postPrice);
// next one is info
        ((Label)pane.getChildren().get(3)).setText(info);
// next one is id
        ((Label)pane.getChildren().get(4)).setText(id);
// next one is order button
// next one is rate
        ((Label)pane.getChildren().get(5)).setText(rate);
        String Loc = Main.class.getResource("/CSS/try.css").toExternalForm();
        pane.getStylesheets().add(Loc);
        pane.setStyle("  -fx-background-radius: 20,10,0; -fx-background-color:rgba(229,8,184,0.12);");

        return pane;
    }
}
