package model;

import java.util.ArrayList;

public class ResturantOwner extends User {
//    private static ArrayList<ResturantOwner> allResturantOwner= FileManager.getFileManagerInstance().resturantOwners;
    private ArrayList<Resturant> Resturants = new ArrayList();

    static String whoIsBetter(String a, String b) {
        for(int i = 0; i < Math.min(a.length(), b.length()); ++i) {
            if (a.charAt(i) != b.charAt(i)) {
                if (a.charAt(i) > b.charAt(i)) {
                    return b;
                }

                return a;
            }
        }

        if (a.length() > b.length()) {
            return b;
        } else {
            return a;
        }
    }

    public ArrayList<Resturant> getSortedRestaurants() {
        String[] names = new String[this.Resturants.size()];
        Resturant[] rests = new Resturant[this.Resturants.size()];

        int i;
        for(i = 0; i < this.Resturants.size(); ++i) {
            names[i] = ((Resturant)this.Resturants.get(i)).getName();
            rests[i] = (Resturant)this.Resturants.get(i);
        }

        int j;
        for(i = 0; i < this.Resturants.size(); ++i) {
            for(j = 0; j < this.Resturants.size(); ++j) {
                String tmp;
                Resturant t;
                if (names[i].equals(names[j])) {
                    if (rests[i].getId() < rests[j].getId()) {
                        tmp = names[i];
                        names[i] = names[j];
                        names[j] = tmp;
                        t = rests[i];
                        rests[i] = rests[j];
                        rests[j] = t;
                    }
                } else if (whoIsBetter(names[i], names[j]).equals(names[j])) {
                    tmp = names[i];
                    names[i] = names[j];
                    names[j] = tmp;
                    t = rests[i];
                    rests[i] = rests[j];
                    rests[j] = t;
                }
            }
        }

        ArrayList<Resturant> miow = new ArrayList();

        for(j = 0; j < rests.length; ++j) {
            miow.add(rests[j]);
        }

        return miow;
    }

    public ResturantOwner(String name, String password, int node, String securityquestion) {
        super(name, password, node, securityquestion);
        Resturants = new ArrayList<>();
        FileManager.getFileManagerInstance().resturantOwners.add(this);
        FileManager.saveAllDatas();    }

    public static void setAllResturantOwner(ArrayList<ResturantOwner> allResturantOwner) {
//        ResturantOwner.allResturantOwner = allResturantOwner;
    }

    public void setResturants(ArrayList<Resturant> resturants) {
        this.Resturants = resturants;
    }

    public static ArrayList<ResturantOwner> getAllResturantOwner() {
        return FileManager.getFileManagerInstance().resturantOwners;
    }

    public ArrayList<Resturant> getResturants() {
        return this.Resturants;
    }

    public void AddToResturants(Resturant resturants) {
        this.Resturants.add(resturants);
    }

    public static int printindexbyResturantOwnername(String name) {
        for(int i = 0; i < FileManager.getFileManagerInstance().resturantOwners.size(); ++i) {
            if (FileManager.getFileManagerInstance().resturantOwners.get(i).getName().equals(name)) {
                return i;
            }
        }

        return -1;
    }

    public static ResturantOwner returnResturantOwnerbyname(String name) {
        for (int i = 0; i < FileManager.getFileManagerInstance().resturantOwners.size(); i++) {
            if(FileManager.getFileManagerInstance().resturantOwners.get(i).getName().equals(name)){
                return FileManager.getFileManagerInstance().resturantOwners.get(i);
            }
        }
        return null;

    }

    public static boolean checkpasswor(String password, int index) {
        return FileManager.getFileManagerInstance().resturantOwners.get(index).getPassword().equals(password);
    }

    public static boolean checksecurityquestion(String name, String question) {
        return (FileManager.getFileManagerInstance().resturantOwners.get(printindexbyResturantOwnername(name))).getSecurityQuestion().equals(question);
    }

    public static void setnewpassword(String password, int index) {
        ((ResturantOwner)FileManager.getFileManagerInstance().resturantOwners.get(index)).setPassword(password);
    }


//    static {
//        FileManager.getFileManagerInstance().resturantOwners = FileManager.getFileManagerInstance().resturantOwners;
//    }
}