package model;

import java.util.ArrayList;
import java.util.Random;

public class Customer extends User{
    public boolean hasCart;
//    static private ArrayList<Customer> allcustomer = FileManager.getFileManagerInstance().customers;
    private ArrayList<Cart> carts;
    private ArrayList<Order> completedorders;
    private double accountmoney;
    private ArrayList<String> discountcodes;
    private ArrayList<Double> valueDiscount;
    private static Customer LoggedInCustomer;
    public Customer(String name , String password,int node,String sequrityquestion)
    {
       super(name , password,node,sequrityquestion);
       this.carts =new ArrayList<>();
       completedorders=new ArrayList<>();
       discountcodes = new ArrayList<>();
       valueDiscount = new ArrayList<>();
        this.hasCart=false;
        this.accountmoney = 0;
        FileManager.getFileManagerInstance().customers.add(this);
        FileManager.getFileManagerInstance().saveAllDatas();
    }

    public ArrayList<String> getDiscountcodes() {
        return discountcodes;
    }

    public static Customer getLoggedInCustomer() {
        return LoggedInCustomer;
    }

    public void setLoggedInCustomer(Customer loggedInCustomer) {
        LoggedInCustomer = loggedInCustomer;
    }

    public void setDiscountcodes(ArrayList<String> discountcodes) {
        this.discountcodes = discountcodes;
    }

    public ArrayList<Double> getValueDiscount() {
        return valueDiscount;
    }

    public void setValueDiscount(ArrayList<Double> valueDiscount) {
        this.valueDiscount = valueDiscount;
    }

    public double getAccountmoney() {
        return accountmoney;
    }

    public void setAccountmoney(double accountmoney) {
        this.accountmoney = accountmoney;
    }

    public ArrayList<Order> getOrders() {
        return completedorders;
    }

    public void setOrders(ArrayList<Order> orders) {
        this.completedorders = orders;
    }

    public ArrayList<Order> getCompletedorders() {
        return completedorders;
    }

    public void setCompletedorders(ArrayList<Order> completedorders) {
        this.completedorders = completedorders;
    }

    public ArrayList<Cart> getCarts() {
        return carts;
    }

    public static void setAllcustomer(ArrayList<Customer> allcustomer) {
        FileManager.getFileManagerInstance().customers = allcustomer;
    }

    public void setCarts(ArrayList<Cart> carts) {
        this.carts = carts;
    }

    public static ArrayList<Customer> getAllcustomer() {
        return FileManager.getFileManagerInstance().customers;
    }
    public static int printindexbycustomname(String name){
        for(int i=0;i<FileManager.getFileManagerInstance().customers.size();i++){
            if(FileManager.getFileManagerInstance().customers.get(i).getName().equals(name)){
                return i;
            }
        }
        return -1;
    }
    public static Customer returncustomerbyname(String name){
        return FileManager.getFileManagerInstance().customers.get(printindexbycustomname(name));
    }
    public static boolean checkpasswor(String password,int index){
        if(FileManager.getFileManagerInstance().customers.get(index).getPassword().equals(password)){
            return true;
        }
        return false;
    }
    public static boolean checksecurityquestion(String name,String question){
        if(FileManager.getFileManagerInstance().customers.get(printindexbycustomname(name)).getSecurityQuestion().equals(question)){
            return true;
        }
        return false;
    }
    public static void setnewpassword(String password,int index){
        FileManager.getFileManagerInstance().customers.get(index).setPassword(password);
    }
    public static int returnIndexFromObject(Customer customer){
        int m=0;
        for(int i=0;i<FileManager.getFileManagerInstance().customers.size();i++){
            if(FileManager.getFileManagerInstance().customers.get(i).equals(customer)){
                return i;
            }
        }
        return -1;
    }
    public static Order findOrderByID(int f) {
        f=f-3000000;
        for (int i = 0; i < FileManager.getFileManagerInstance().customers.size(); i++) {
            for (int j = 0; j < FileManager.getFileManagerInstance().customers.get(i).getCompletedorders().size(); j++) {
                if (FileManager.getFileManagerInstance().customers.get(i).completedorders.get(j).getId() == f)
                    return FileManager.getFileManagerInstance().customers.get(i).getCompletedorders().get(j);
            }
        }
        return null;
    }
    public static String getDiscountCode(){
        Random random = new Random();
        String result="";
        for(int i=0;i<8;i++){
            int a = random.nextInt(26);
            a+=65;
            char b = (char) a;
            result+=b;
        }
        return result;
    }
    public static void setdiscount(String discountcode,double value,int index){
        FileManager.getFileManagerInstance().customers.get(index).getDiscountcodes().add(discountcode);
        FileManager.getFileManagerInstance().customers.get(index).getValueDiscount().add(value);
    }
    public static int checkDiscountCode(int index,String discountcode){
        for(int i=0;i<FileManager.getFileManagerInstance().customers.get(index).getDiscountcodes().size();i++){
            if(FileManager.getFileManagerInstance().customers.get(index).getDiscountcodes().get(i).equals(discountcode)){
                return i;
            }
        }
        return -1;
    }
    public static void deleteDiscountCode(int indexCustomer,int indexDiscountcode){
        FileManager.getFileManagerInstance().customers.get(indexCustomer).getDiscountcodes().remove(indexDiscountcode);
        FileManager.getFileManagerInstance().customers.get(indexCustomer).getValueDiscount().remove(indexDiscountcode);
    }
}

