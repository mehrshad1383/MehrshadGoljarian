package model;

import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import view.*;

import java.io.IOException;
import java.net.URL;

public class Restauranttmp extends Pane
{
    String name;
    String info;
    String rate ;
    String postPrice;
    String picturePlace;
    String id;
    public Resturant resturant;
    boolean isForAdmin = false;
    public Restauranttmp(String name,
                         String info,
                         String rate ,
                         String postPrice,
                         String picturePlace,
                         String id,
                         Resturant resturant){
        this.name=name;
        this.info=info;
        this.rate =rate;
        this.postPrice=postPrice;
        this.picturePlace=picturePlace;
        this.id=id;
        this.resturant=resturant;
    }
    public Restauranttmp(String name,
                         String info,
                         String rate ,
                         String postPrice,
                         String picturePlace,
                         String id,
                         Resturant resturant,boolean a){
        this.name=name;
        this.info=info;
        this.rate =rate;
        this.postPrice=postPrice;
        this.picturePlace=picturePlace;
        this.id=id;
        this.resturant=resturant;
        isForAdmin=true;
    }
    public Pane getInstance() throws IOException {

        Pane pane =   FXMLLoader.load(new URL(Main.class.getResource("/FXML/resturant.fxml").toExternalForm()));
// first one is the picture!
        ImageView imageView = (ImageView)(pane.getChildren().get(0));
        Image image = new Image(Main.class.getResource(picturePlace).toExternalForm());
        imageView.setImage(image);
        imageView.setStyle("    -fx-padding: 200;\n" +
                "    -fx-background-radius: 15;\n" +
                "    -fx-image-radius: 20,10,0;\n" +
                "    -fx-image-insets: 0,10,20;");
// next one is name
        ((Label)pane.getChildren().get(1)).setText(name);
// next one is price
        ((Label)pane.getChildren().get(2)).setText(postPrice);
// next one is info
        ((Label)pane.getChildren().get(3)).setText(info);
// next one is id
        ((Label)pane.getChildren().get(4)).setText(id);
// next one is order button
        ((Button)pane.getChildren().get(5)).setText("SELECT");
        if(isForAdmin) {
            ((Button) pane.getChildren().get(5)).setOnMouseClicked(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent event) {
                    try {
                        System.out.println("moiw");
                        AdminResturantMenu adminResturantMenu = new AdminResturantMenu(resturant.getResturantOwner(), resturant);
                        Main.adminResturantMenu = adminResturantMenu;
                        adminResturantMenu.start(Main.stage);
                    } catch (Exception e) {
                        System.out.println("bullsiit");
                        throw new RuntimeException(e);
                    }
                }
            });
        }
        else {
            ((Button) pane.getChildren().get(5)).setOnMouseClicked(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent event) {
                    try {
                        new ResturantMenu(resturant, Customer.getLoggedInCustomer(),Main.mediaPlayer).start(LoginMenu.stage);
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                }
            });
        }
// next one is rate
        ((Label)pane.getChildren().get(6)).setText(rate);
        String Loc = Main.class.getResource("/CSS/try.css").toExternalForm();
        pane.getStylesheets().add(Loc);
        pane.setStyle("  -fx-background-color:rgb(18,18,19);");

        return pane;
    }
}
