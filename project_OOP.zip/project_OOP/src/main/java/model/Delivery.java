package model;

import java.util.ArrayList;

public class Delivery extends User{

//    private static ArrayList<Delivery> AllDelivery = FileManager.getFileManagerInstance().deliveries;
    private Cart cart;
    private Resturant resturant;
    private Customer customer;

    public double x;
    public double y;

    public Customer getCustomer() {
        return customer;
    }

    private Order order;

    public void setOrder(Order order) {
        this.order = order;
    }

    public Order getOrder() {
        return order;
    }
//    public static ArrayList<Order> getAvailibleOrders() {
//        return AvailibleOrders;
//    }
//
//    public static void AddToAvailibleOrders(Order order)
//    {
//        AvailibleOrders.add(order);
//    }
//
//    public static void RemoveFromAvailibleorders(Order order)
//    {
//        AvailibleOrders.remove(order);
//    }
//    private static ArrayList<Order> AvailibleOrders = new ArrayList<>();

    public Delivery(String name , String password,int node,String sequrityquestion)
    {
        super(name , password,node,sequrityquestion);
        this.order = new Order();
        FileManager.getFileManagerInstance().deliveries.add(this);
        FileManager.saveAllDatas();
    }
    public Delivery(){
        super();

    }
    public static void setAllDelivery(ArrayList<Delivery> allDelivery) {
        FileManager.getFileManagerInstance().deliveries = allDelivery;
    }

    public void setCart(Cart cart) {
        this.cart = cart;
    }

    public void setResturant(Resturant resturant) {
        this.resturant = resturant;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public static ArrayList<Delivery> getAllDelivery() {
        return FileManager.getFileManagerInstance().deliveries;
    }

    public Cart getCart() {
        return cart;
    }

    public Resturant getResturant() {
        return resturant;
    }
    public static int printindexbydeliveryname(String name){
        for(int i=0;i<FileManager.getFileManagerInstance().deliveries.size();i++){
            if(FileManager.getFileManagerInstance().deliveries.get(i).getName().equals(name)){
                return i;
            }
        }
        return -1;
    }

    public static Delivery returnDeliverybyname(String name){
        return FileManager.getFileManagerInstance().deliveries.get(printindexbydeliveryname(name));
    }
    public static boolean checkpasswor(String password,int index){
        if(FileManager.getFileManagerInstance().deliveries.get(index).getPassword().equals(password)){
            return true;
        }
        return false;
    }
    public static boolean checksecurityquestion(String name,String question){
        if(FileManager.getFileManagerInstance().deliveries.get(printindexbydeliveryname(name)).getSecurityQuestion().equals(question)){
            return true;
        }
        return false;
    }
    public static void setnewpassword(String password,int index){
        FileManager.getFileManagerInstance().deliveries.get(index).setPassword(password);
    }

    public static Delivery getDeliveryByNode(int node)
    {
        for(int i = 0 ; i<FileManager.getFileManagerInstance().deliveries.size() ; i++)
        {
            if(FileManager.getFileManagerInstance().deliveries.get(i).getNode() == node)
                return FileManager.getFileManagerInstance().deliveries.get(i);
        }
        return null;
    }


}

