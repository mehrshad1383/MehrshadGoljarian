package controller;

import model.Comment;
import model.Food;
import model.Resturant;
import view.AdminFoodMenu;

import java.util.regex.Matcher;

public class AdminFoodMenuController {
    private  AdminFoodMenu adminFoodMenu;
    public AdminFoodMenuController (AdminFoodMenu adminFoodMenu){
        this.adminFoodMenu=adminFoodMenu;
    }
    public void DisplayComments(Food food) {
        if (food.getComments().size() > 0) {
            for (int i = 0; i < food.getComments().size(); i++) {
                int u = i + 1;
                if(food.getComments().get(i).getRating()>=0)
                    System.out.println(u + "_ CONTENT= " + food.getComments().get(i).getContent() + "   Rating= " + food.getComments().get(i).getRating() +"   ID= " + i);
                else
                    System.out.println(u + "_ " + food.getComments().get(i).getContent() + " NO RATED " + " ID: " + i);
            }
        }
        else{
            System.out.println("no comment");
        }
    }
    public void ADDResponse(Food food, Matcher m4){
        String a = m4.group("id");
        String b = m4.group("message");
        int id = Integer.parseInt(a);
        Comment t =new Comment();
        if(food.ReturnCountOfComment()>id) {
            t = food.findCommenetByID(id);
        }
        if(food.ReturnCountOfComment()<=id){
            System.out.println("There is no comment with this id");
        }
        else if(t.isAnswered()){
            System.out.println("You already responsed it, maybe you need to edit it");
        }else {
            t.Answer(b);
            System.out.println("response saved successfully");
        }
    }
    public void EditResponse(Food food,Matcher m6){
        String a = m6.group("id");
        String b = m6.group("message");
        int id = Integer.parseInt(a);
        Comment t =new Comment();
        if(food.ReturnCountOfComment()>id) {
            t = food.findCommenetByID(id);
        }
        if(food.ReturnCountOfComment()<=id){
            System.out.println("There is no comment with this id");
        }
        else if(t.isAnswered()==false){
            System.out.println("You already have not responsed it, maybe you need to add new response");
        }else {
            t.Answer(b);
            System.out.println("response edited successfully");
        }
    }
}
