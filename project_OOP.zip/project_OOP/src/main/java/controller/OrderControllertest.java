//package controller;
//
//import model.Map;
//
//import java.util.ArrayList;
//
//public class OrderControllertest extends Thread{
//
//    public int node;
//    public double x;
//    public double y;
//    public ArrayList<Integer> distance;
//    public OrderControllertest(ArrayList<Integer> pp)
//    {
//        node = pp.get(0);
//        distance = pp;
//        this.x = Map.getMapMatrixX()[pp.get(0)-1];
//        this.y = Map.getMapMatrixY()[pp.get(0)-1];
//    }
//
//    public void run()
//    {
//
//        for(int i = 0 ; i<distance.size()-1 ; i++)
//        {
//            int mmd = Map.getMapMatrix()[distance.get(i)][distance.get(i+1)]* 1000;
//            double dx = (Map.getMapMatrixX()[distance.get(i+1)-1] - Map.getMapMatrixX()[distance.get(i)-1])/mmd;
//            double dy = (Map.getMapMatrixY()[distance.get(i+1)-1] - Map.getMapMatrixY()[distance.get(i)-1])/mmd;
//            for(int j = 0 ; j<mmd ; j++)
//            {
//                x+=dx;
//                y+=dy;
//                try {
//                    Thread.sleep(mmd/1000);
//                } catch (InterruptedException e) {
//                    throw new RuntimeException(e);
//                }
//            }
//            this.node = distance.get(i+1);
//            this.x = Map.getMapMatrixX()[node-1];
//            this.y = Map.getMapMatrixY()[node-1];
//            System.out.println(node);
////            try {
////                Thread.sleep(Map.getMapMatrix()[distance.get(i)]
////                        [distance.get(i+1)]* 1000);
////                this.node = distance.get(i+1);
////            } catch (InterruptedException e) {
////                throw new RuntimeException(e);
////            }
//        }
//    }
//}
