package controller;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import model.*;
import view.AdminFoodMenu;
import view.AdminResturantMenu;
import view.Main;
import view.Menu;

import java.io.IOException;
import java.util.ArrayList;
import java.util.regex.Matcher;

import static model.Resturant.RatingFood;
import static model.Resturant.numOfRatingFood;

public class AdminResturantMenuController {
    private AdminResturantMenu adminResturantMenu;
    public ArrayList<Foodtmp> foodtmps ;
    public AdminResturantMenuController(AdminResturantMenu adminResturantMenu){
        this.adminResturantMenu=adminResturantMenu;
    }
    public VBox getVbox() throws IOException {
        foodtmps= new ArrayList<>();
        VBox vBox = new VBox();
        String list = "";
        String name;
        double price;
        String rating1;
        int id;
        double rating;
        Resturant resturant = adminResturantMenu.getResturant();
        ResturantOwner resturantOwner=adminResturantMenu.getResturantOwner();


        for(int i = 0; i <resturant.getFoods().size(); ++i) {
            Food food =resturant.getFoods().get(i);
            list="";
            int u =0 ;
            for (int j = 0; j < food.getComments().size(); j++) {
                u+=food.getComments().get(j).getRating();
            }
            if(food.getComments().size()!=0)
                u/=food.getComments().size();

            rating=u;
            if (rating<0){
                rating=0;
            }
            rating1 = rating +" from "+String.valueOf(food.getComments().size())+" vote";
            name= food.getName() ;
            id= food.getId() ;
            price= food.getPrice() ;
            list=list+ "THE FOOD's DISCOUNT= " + food.getDiscount() + "%  \n";
            if (food.isActivated()) {
                list = list + "THE FOOD IS Active  ";
            } else {
                list = list + "THE FOOD IS Inactive  ";
            }
            Foodtmp foodtmp =new Foodtmp(name,price+"",rating1,list,"/Image/pic1.png",id+"",food,resturant,true,adminResturantMenu);
            foodtmps.add(foodtmp);
            vBox.getChildren().add(foodtmp.getInstance());
        }
        return vBox;
    }
    public void EditFood(Food food , AdminResturantMenu adminResturantMenu){
        VBox changeBox = adminResturantMenu.changeBox;
        //mi
        // 1-id change true/false
        // 2 food name
        // 3 food price
        // 4 food discount
        // 5 food activation t/f
        // 6 food deleting t/f
        // 7 fOOD DISCOUNT ACTIVATIION t/f
        // ow
        if(!((TextField)changeBox.getChildren().get(1)).getText().equals("")){
            String text = ((TextField)changeBox.getChildren().get(1)).getText();
            if(!text.equals("true") && !text.equals("false")){
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("BAD INPUT");
                alert.setHeaderText("DONT PLAY WITH ME ");
                alert.setContentText("\t just write true or false");
                alert.showAndWait();
            }else {
                boolean a = true;
                if(text.equals("false"))
                    a=false;
                if(a)
                    food.setId(food.getId()+250);
            }
        }
        if(!((TextField)changeBox.getChildren().get(2)).getText().equals("")){
            String text = ((TextField)changeBox.getChildren().get(2)).getText();
            food.setName(text.trim());

        }
        if(!((TextField)changeBox.getChildren().get(3)).getText().equals("")){
            String text = ((TextField)changeBox.getChildren().get(3)).getText();
            if(!AdminResturantMenuController.isJustDouble(text.trim())){
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("BAD INPUT");
                alert.setHeaderText("DONT PLAY WITH ME ");
                alert.setContentText("\t  PRICE MUST BE NUM");
                alert.showAndWait();
            }else {
                food.setPrice(Double.parseDouble(text.trim()));
            }
        }
        if(!((TextField)changeBox.getChildren().get(4)).getText().equals("")){
            String text = ((TextField)changeBox.getChildren().get(4)).getText();
            if(!AdminResturantMenuController.isJustDouble(text.trim())){
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("BAD INPUT");
                alert.setHeaderText("DONT PLAY WITH ME ");
                alert.setContentText("\t  DISCOUNT MUST BE NUM");
                alert.showAndWait();
            }else {
                food.setDiscount(Double.parseDouble(text.trim()));
            }
        }
        if(!((TextField)changeBox.getChildren().get(5)).getText().equals("")){
            String text = ((TextField)changeBox.getChildren().get(5)).getText();
            if(!text.equals("true") && !text.equals("false")){
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("BAD INPUT");
                alert.setHeaderText("DONT PLAY WITH ME ");
                alert.setContentText("\t just write true or false");
                alert.showAndWait();
            }
            else {
                boolean a = true;
                if(text.equals("false"))
                    a=false;
                if(a){
                    food.setActivated(true);
                }else {
                    food.setActivated(false);
                }
            }
        }
        if(!((TextField)changeBox.getChildren().get(6)).getText().equals("")){
            String text = ((TextField)changeBox.getChildren().get(6)).getText();
            if(!text.equals("true") && !text.equals("false")){
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("BAD INPUT");
                alert.setHeaderText("DONT PLAY WITH ME ");
                alert.setContentText("\t just write true or false");
                alert.showAndWait();
            }
            else {
                boolean a = true;
                if(text.equals("false"))
                    a=false;
                if(a){
                    adminResturantMenu.getResturant().getFoods().remove(food);
                }else {

                }

            }
        }
        if(!((TextField)changeBox.getChildren().get(7)).getText().equals("")){
            String text = ((TextField)changeBox.getChildren().get(7)).getText();
            if(!text.equals("true") && !text.equals("false")){
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("BAD INPUT");
                alert.setHeaderText("DONT PLAY WITH ME ");
                alert.setContentText("\t just write true or false");
                alert.showAndWait();
            }
            else {
                boolean a = true;
                if(text.equals("false"))
                    a=false;
                if(a){

                }else {
                    food.setDiscount(0);
                }

            }
        }

        try {
            adminResturantMenu.start(Main.stage);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }




    }
    public void Help(){
        System.out.println("Available options :");
        System.out.println("SHOW LOCATION");
        System.out.println("EDIT LOCATION");
        System.out.println("SHOW FOODTYPE");
        System.out.println("back");
        System.out.println("EDIT FOODTYPE <tps>");
        System.out.println("SELECT MENU");
        System.out.println("EDIT FOOD <id> NAME <newName>");
        System.out.println("EDIT FOOD <id> PRICE <newPrice>");
        System.out.println("EDIT FOOD <id> DISCOUNT <newDiscount>");
        System.out.println("ADD FOOD <name> <price>");
        System.out.println("DELETE FOOD <id>");
        System.out.println("ACTIVE FOOD <id>");
        System.out.println("DEACTIVE FOOD <id>");
        System.out.println("DISCOUNT FOOD <FOOD ID> <DISCOUNT PERCENT> <TIMESTAMP>");
        System.out.println("SELECT FOOD <FOOD ID>");
        System.out.println("DISPLAY OPEN ORDERS");
        System.out.println("EDIT ORDER <ORDER ID> STATUS");
        System.out.println("SHOW ORDER HISTORY");
    }
    public void ShowLocation(Resturant resturant){
        System.out.println(resturant.getLocation().showLocation());
    }
    public void EditLocation(Resturant resturant){
        int a = Integer.parseInt(Menu.getScanner().nextLine());
        resturant.setLocation(new Mapi(a));
    }
    public void ShowFoodType(Resturant resturant){
        for (int i = 0; i < resturant.getRestaurantType().size(); i++) {
            System.out.println((i+1)+"_ "+resturant.getRestaurantType().get(i));
        }
    }
    public void EditFoodType(Resturant resturant, Matcher m6){
        if(resturant.hasActiveOrder()){
            System.out.println("You can't do this right now , You have active orders");
        }else {
            System.out.println("ARE YOU SURE YOU WANT TO CHANGE YOUR RESTAURANT TYPE?(YES or NO)");
            String c = Menu.getScanner().nextLine();
            if(c.equals("YES")) {
                String[] tmp = m6.group("tps").trim().split("-");
                ArrayList<String> t2 = new ArrayList<>();
                for (int i = 0; i < tmp.length; i++) {
                    t2.add(tmp[i]);
                }
                resturant.setRestaurantType(t2);
                resturant.setFoods(new ArrayList<>());
            }
        }
    }
    public void SlectMenu(Resturant resturant){
        for (int i = 0; i < resturant.getFoods().size(); i++) {
            System.out.println((i+1)+"_ "+resturant.getFoods().get(i).getName()+" id: "+resturant.getFoods().get(i).getId()+" price: "+resturant.getFoods().get(i).getPrice()+" Discount: "+resturant.getFoods().get(i).getDiscount()+"% Activation: "+resturant.getFoods().get(i).isActivated()+" rating: "+resturant.getFoods().get(i).getRating());
        }
    }
    public void EditNameFood(Resturant resturant,Matcher m8){
        String name = m8.group("newName");
        String idd = m8.group("id");
        int id = Integer.parseInt(idd);
        Food t = resturant.findFoodByID(id);
        t.setName(name);
        System.out.println("Name set successfully");
    }
    public void EditPriceFood(Resturant resturant,Matcher m9){
        String price = m9.group("newPrice");
        String idd = m9.group("id");
        int id = Integer.parseInt(idd);
        Food t = resturant.findFoodByID(id);
        double p = Double.parseDouble(price);
        t.setPrice(p);
        System.out.println("Price set successfully");
    }
    public void EditDiscountFood(Resturant resturant,Matcher m10){
        String discount = m10.group("newDiscount");
        String idd = m10.group("id");
        int id = Integer.parseInt(idd);
        Food t = resturant.findFoodByID(id);
        double p = Double.parseDouble(discount);
        t.setDiscount(p);
        System.out.println("Discount set successfully");
    }
    public void AddFood(Resturant resturant,Matcher m11){
        String name = m11.group("name");
        String idd = m11.group("price");
        double price = Double.parseDouble(idd);
        int u = 2000000+resturant.getFoods().size();
        Food t = new Food(name,u,price,0);
        resturant.addFoodToFoods(t);
    }
    public void DeleteFood(Resturant resturant,Matcher m12){
        String idd = m12.group("id");
        int id = Integer.parseInt(idd);
        Food t = resturant.findFoodByID(id);
        if(resturant.hasActiveOrder(t)){
            System.out.println("You can't do this right now , You have active orders");
        }else {
            ArrayList<Food> tmp = resturant.getFoods();
            tmp.remove(t);
            resturant.setFoods(tmp);
        }
    }
    public void DeactiveFood(Resturant resturant,Matcher m13){
        String idd = m13.group("id");
        int id = Integer.parseInt(idd);
        Food t = resturant.findFoodByID(id);
        if(resturant.hasActiveOrder(t)){
            System.out.println("You can't do this right now , You have active orders");
        }else {
            t.setActivated(false);
        }
    }
    public void ActiveFood(Resturant resturant,Matcher m14){
        String idd = m14.group("id");
        int id = Integer.parseInt(idd);
        Food t = resturant.findFoodByID(id);
        t.setActivated(true);
    }
    public void DiscountTimestampFood(Resturant resturant,Matcher m15){
        String idd = m15.group("ID");
        int id = Integer.parseInt(idd);
        Food t = resturant.findFoodByID(id);
        double a =Double.parseDouble(m15.group("PERCENT"));
        double b =Double.parseDouble(m15.group("TIMESTAMP"));
        if(t.getDiscount()!=0){
            System.out.println("There is an active discount");
        }else if(a>50) {
            System.out.println("This is not acceptable , please choose a number below 50");
        }else {
            t.setDiscount(a);
            t.setTIMESTAMP(b);
            Double pr = (t.getPrice()/100)*(100-t.getDiscount());
            System.out.println("price with discount is : "+pr);
        }
    }
    public void SelectFood(Resturant resturant,Matcher m16,int indexRestaurant) {
        String idd = m16.group("id");
        int id = Integer.parseInt(idd);
        if (!resturant.checkIdfood(id)) {
            System.out.println("There is no food with this id");
        } else {
            Food t = resturant.findFoodByID(id);
            AdminFoodMenu adminFoodMenu = new AdminFoodMenu(t, resturant);
            adminFoodMenu.run(indexRestaurant,(id-2000000));
        }
    }
    public void DisplayOpenOrder(Resturant resturant){
        System.out.println(resturant.getOrders().size());
        for (int i = 0; i < resturant.getOrders().size(); i++) {
            if(resturant.getOrders().get(i).getStatus().equals("WaitingForRestuarantConfirmation")){
                int u = i+1;
                System.out.println(u+"_ ID:"+(resturant.getOrders().get(i).getId()+3000000) + " Foods:"+resturant.getOrders().get(i).allFoodStrings());
            }
        }
        System.out.println("Confirmed_IsCooking Orders:");
        for (int i = 0; i < resturant.getOrders().size(); i++) {
            if(resturant.getOrders().get(i).getStatus().equals("Confirmed_IsCooking")){
                int u = i+1;
                System.out.println(u+"_ ID:"+(resturant.getOrders().get(i).getId() +3000000)+ " Foods:"+resturant.getOrders().get(i).allFoodStrings());
            }
        }
        System.out.println("Delivery Orders:");
        for (int i = 0; i < resturant.getOrders().size(); i++) {
            if(resturant.getOrders().get(i).getStatus().equals("Delivery")){
                int u = i+1;
                System.out.println(u+"_ ID:"+(resturant.getOrders().get(i).getId() +3000000)+ " Foods:"+resturant.getOrders().get(i).allFoodStrings());
            }
        }
    }
    public void ShowOrderHistory(Resturant resturant){
        for (int i = 0; i < resturant.getOrders().size(); i++) {
            if(resturant.getOrders().get(i).getStatus().equals("WaitingForRestuarantConfirmation")){
                int u = i+1;
                System.out.println(u+"_ ID:"+(resturant.getOrders().get(i).getId() +3000000)+ " Foods:"+resturant.getOrders().get(i).allFoodStrings());
            }
        }
        System.out.println("Confirmed_IsCooking Orders:");
        for (int i = 0; i < resturant.getOrders().size(); i++) {
            if(resturant.getOrders().get(i).getStatus().equals("Confirmed_IsCooking")){
                int u = i+1;
                System.out.println(u+"_ ID:"+(resturant.getOrders().get(i).getId()+3000000) + " Foods:"+resturant.getOrders().get(i).allFoodStrings());
            }
        }
        System.out.println("Delivery Orders:");
        for (int i = 0; i < resturant.getOrders().size(); i++) {
            if(resturant.getOrders().get(i).getStatus().equals("Delivery")){
                int u = i+1;
                System.out.println(u+"_ ID:"+(resturant.getOrders().get(i).getId()+3000000) + " Foods:"+resturant.getOrders().get(i).allFoodStrings());
            }
        }
        System.out.println("Recieved Orders:");
        for (int i = 0; i < resturant.getOrders().size(); i++) {
            if(resturant.getOrders().get(i).getStatus().equals("Recieved")){
                int u = i+1;
                System.out.println(u+"_ ID:"+(resturant.getOrders().get(i).getId()+3000000) + " Foods:"+resturant.getOrders().get(i).allFoodStrings());
            }
        }
        System.out.println("UserCommented_FullyFinished Orders:");
        for (int i = 0; i < resturant.getOrders().size(); i++) {
            if(resturant.getOrders().get(i).getStatus().equals("UserCommented_FullyFinished")){
                int u = i+1;
                System.out.println(u+"_ ID:"+(resturant.getOrders().get(i).getId()+3000000) + " Foods:"+resturant.getOrders().get(i).allFoodStrings());
            }
        }
    }
    public void EditOrderStatus(Resturant resturant,Matcher m18){
        System.out.println("type \n1 for WaitingForRestuarantConfirmation\n" +
                "2 for Confirmed_IsCooking\n" +
                "3 for Delivery\n"+
                "4 for Recieved\n"+
                "5 for UserCommented_FullyFinished");
        while (true){
            String num = Menu.getScanner().nextLine().trim();
            if( num.equals("1") ||num.equals("2") ||num.equals("3") ||num.equals("4") ||num.equals("5") ){
                String idd = m18.group("id");
                int id = Integer.parseInt(idd);
                Order t = Customer.findOrderByID(id);
                t.setStatus(num);
                System.out.println("Status updated successfully");
            }
            else {
                System.out.println("enter a valid number");
            }
        }

        //   1 WaitingForRestuarantConfirmation
        //   2 Confirmed_IsCooking
        //   3 Delivery
        //   4 Recieved
        //   5 UserCommented_FullyFinished
    }
    public void ConfirmOrder(Resturant resturant , Matcher m20)
    {
        String idd = m20.group("id");
        int id = Integer.parseInt(idd);
        Order t = Customer.findOrderByID(id);
        t.setStatus("Confirmed_IsCooking");
//        OrderController orderController = new OrderController(t.getTimefordeliverytorestaurant() , t.getTimefordeliverytoCustomer() , t);
//        orderController.start();
    }
    public static boolean isJustDouble(String a){
        for (int i = 0; i < a.length(); i++) {
            if(Character.isDigit(a.charAt(i))==true || a.charAt(i)=='.'){
            }
            else {
                return false;
            }
        }
        return true;
    }
}
