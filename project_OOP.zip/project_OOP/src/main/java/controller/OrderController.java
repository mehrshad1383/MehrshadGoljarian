package controller;

import model.Delivery;
import model.Map;
import model.Order;

import java.util.ArrayList;

public class OrderController extends Thread {

    public long timefordeliverytorestaurant;
    public long timefordeliverytoCustomer;

    public Order order;
    private final ArrayList<Integer> DistanceFromDeliveryToResturant;
    private final ArrayList<Integer> DistanceFromDeliveryToCustomer;

    public Delivery delivery;

    public OrderController(Order order, Delivery delivery) {
        this.timefordeliverytorestaurant = order.getTimefordeliverytorestaurant();
        this.timefordeliverytoCustomer = order.getTimefordeliverytoCustomer();
        this.order = order;
        this.delivery = delivery;
        this.DistanceFromDeliveryToCustomer = order.getDistanceFromDeliveryToCustomer();
        this.DistanceFromDeliveryToResturant = order.getDistanceFromDeliveryToResturant();
        delivery.x = Map.getMapMatrixX()[DistanceFromDeliveryToResturant.get(0) -1];
        delivery.y = Map.getMapMatrixY()[DistanceFromDeliveryToResturant.get(0) -1];
    }

    @Override
    public void run() {

        order.setStatus("Delivery");

        for (int i = 0; i < DistanceFromDeliveryToResturant.size() - 1; i++) {
            int mmd = Map.getMapMatrix()[DistanceFromDeliveryToResturant.get(i)][DistanceFromDeliveryToResturant.get(i + 1)] * 1000;
            double dx = (Map.getMapMatrixX()[DistanceFromDeliveryToResturant.get(i + 1) - 1] - Map.getMapMatrixX()[DistanceFromDeliveryToResturant.get(i) - 1]) / mmd;
            double dy = (Map.getMapMatrixY()[DistanceFromDeliveryToResturant.get(i + 1) - 1] - Map.getMapMatrixY()[DistanceFromDeliveryToResturant.get(i) - 1]) / mmd;
            for (int j = 0; j < mmd; j++) {
//                System.out.println(delivery.x);
//                System.out.println(delivery.y);
                delivery.x += dx;
                delivery.y += dy;
                try {
                    Thread.sleep(1);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }

            delivery.setNode(DistanceFromDeliveryToResturant.get(i + 1));
            delivery.x = Map.getMapMatrixX()[delivery.getNode() - 1];
            delivery.y = Map.getMapMatrixY()[delivery.getNode() - 1];
            System.out.println(delivery.getNode());
        }
        order.setStatus("Delivery");
        for (int i = 0; i < DistanceFromDeliveryToCustomer.size() - 1; i++) {
            int mmd = Map.getMapMatrix()[DistanceFromDeliveryToCustomer.get(i)][DistanceFromDeliveryToCustomer.get(i + 1)] * 1000;
            double dx = (Map.getMapMatrixX()[DistanceFromDeliveryToCustomer.get(i + 1) - 1] - Map.getMapMatrixX()[DistanceFromDeliveryToCustomer.get(i) - 1]) / mmd;
            double dy = (Map.getMapMatrixY()[DistanceFromDeliveryToCustomer.get(i + 1) - 1] - Map.getMapMatrixY()[DistanceFromDeliveryToCustomer.get(i) - 1]) / mmd;
            for (int j = 0; j < mmd; j++) {
                delivery.x += dx;
                delivery.y += dy;
                try {
                    Thread.sleep(1);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
            delivery.setNode(DistanceFromDeliveryToCustomer.get(i + 1));
            delivery.x = Map.getMapMatrixX()[delivery.getNode() - 1];
            delivery.y = Map.getMapMatrixY()[delivery.getNode() - 1];
            System.out.println(delivery.getNode());
            order.setStatus("Recieved");
            delivery.setOrder(null);
//        for(int i = 0 ; i<DistanceFromDeliveryToResturant.size()-1 ; i++)
//        {
//            try {
//                Thread.sleep(Map.getMapMatrix()[DistanceFromDeliveryToResturant.get(i)]
//                        [DistanceFromDeliveryToResturant.get(i+1)]* 100L);
//                delivery.setNode(DistanceFromDeliveryToResturant.get(i+1));
//            } catch (InterruptedException e) {
//                throw new RuntimeException(e);
//            }
//        }
//        order.setStatus("Delivery");
//        for(int i = 0 ; i<DistanceFromDeliveryToCustomer.size()-1 ; i++)
//        {
//            try {
//                Thread.sleep(Map.getMapMatrix()[DistanceFromDeliveryToCustomer.get(i)]
//                        [DistanceFromDeliveryToCustomer.get(i+1)]* 100L);
//                delivery.setNode(DistanceFromDeliveryToCustomer.get(i+1));
//            } catch (InterruptedException e) {
//                throw new RuntimeException(e);
//            }
//        }
        }
    }
}

