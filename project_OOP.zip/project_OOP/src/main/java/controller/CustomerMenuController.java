package controller;


import javafx.scene.layout.VBox;
import javafx.scene.media.MediaPlayer;
import model.*;
import view.CostumerMenu;
import view.Menu;
import view.RegisterMenu;
import view.ResturantMenu;

import java.io.IOException;
import java.util.ArrayList;

public class CustomerMenuController {

    private CostumerMenu CostomerMenu;

    public CustomerMenuController(CostumerMenu costumerMenu) {
        this.CostomerMenu=costumerMenu;
    }

    public  String ShowDeliveryTime(Customer customer) {
        String returner="";
        if(customer.getCompletedorders().size()<1){
            returner="Nothing";
        }
        for(int i = 0 ; i<customer.getCompletedorders().size() ; i++)
        {
            returner+=(i+1)+". ";
            returner += (customer.getCompletedorders().get(i).getId()+3000000)+" - ";
            if(customer.getCompletedorders().get(i).getStatus().equals("Recieved"))
            {
                returner += "Recieved";
            }
            else if(customer.getCompletedorders().get(i).getStatus().equals("UserCommented_FullyFinished"))
            {
                returner += "UserCommented_FullyFinished";
            }
            else {
                if(customer.getCompletedorders().get(i).getFinaltime()-System.currentTimeMillis()<0)
                {
                    customer.getCompletedorders().get(i).setStatus("Recieved");
                    customer.getCompletedorders().get(i).getDelivery().setOrder(null);
                    returner += "Recieved";
                }
                else {
                    returner += customer.getCompletedorders().get(i).getFinaltime() - System.currentTimeMillis() + " miliseconds";
                }
            }
            returner+="\n";
        }
        return returner;
    }

    public String SearchResturant(String name)
{
    String list;
    list = Resturant.searchResturant(name);
   if(list.equals("")){
       return "there is no resturant with this name";
   }
   else{
       return list;
   }
}
    public int returnindexbyid(int id){
        int result;
        result = Resturant.returnindexbyname(id);
        return result;
    }

    public VBox showallResturant(Customer customer, VBox vBox, MediaPlayer mediaPlayer) throws IOException {
        vBox = Resturant.showallresturant(customer,vBox,mediaPlayer);
        return vBox;
    }

public String DisplayCartStatus(int index)
{
    return showCart(index);
}

    public String confirmOrder(int index,Customer customer,String code,boolean checker) {
        double cost1, cost2;
        String result = "";
        cost1 = customer.getAccountmoney();
        cost2 = FileManager.getFileManagerInstance().customers.get(index).getCarts().get(0).getCost();
        if (checker){
            int check = Customer.checkDiscountCode(index, code);
        if (check < 0) {
            return  "there is no discount code with this name you can try again or enter no";
        } else {
            result = result + "Discount code applied your order amount changed from " + cost2 + "\n";
            cost2 = cost2 - FileManager.getFileManagerInstance().customers.get(index).getValueDiscount().get(check);
            result=result+" to " + cost2;
            Double price = FileManager.getFileManagerInstance().customers.get(index).getCarts().get(0).getCost();
            FileManager.getFileManagerInstance().customers.get(index).getCarts().get(0).setCost(price - FileManager.getFileManagerInstance().customers.get(index).getValueDiscount().get(check));
            Customer.deleteDiscountCode(index, check);
        }
    }
            customer.setAccountmoney(cost1-cost2);
//        long t1 = estimateTime1(searchforthebestdelivery(FileManager.getFileManagerInstance().customers.get(index).getCarts().get(0).getResturant().getLocation().getNode()).getNode() , FileManager.getFileManagerInstance().customers.get(index).getCarts().get(0).getResturant().getLocation().getNode() );
            long t2 = estimateTime2(FileManager.getFileManagerInstance().customers.get(index).getCarts().get(0).getResturant().getLocation().getNode(), customer.getNode());
            Resturant resturant = FileManager.getFileManagerInstance().customers.get(index).getCarts().get(0).getResturant();
            int id = getIdOfOrder();
            Cart cart = FileManager.getFileManagerInstance().customers.get(index).getCarts().get(0);
        ArrayList<Integer> newbie = Map.dijkstraPrinter(FileManager.getFileManagerInstance().customers.get(index).getCarts().get(0).getResturant().getLocation().getNode()
                ,customer.getNode());
        Order order = new Order(customer, resturant, id, cart, t2, (int) t2 , newbie);
            order.setStatus("WaitingForRestuarantConfirmation");
            FileManager.getFileManagerInstance().customers.get(index).getCarts().clear();
            customer.hasCart = false;
            FileManager.getFileManagerInstance().customers.get(index).getCompletedorders().add(order);
            result=result+"The order was successfully placed\n";
            if(cost2>20000){
                String discountcode = Customer.getDiscountCode();
                double amount = (double) cost2/10;
                Customer.setdiscount(discountcode,amount,index);
                result=result+"Congratulations, ("+discountcode+") discount code for the amount\n of ("+amount+") has been awarded to you\n";
            }
            return result;
        }
    public void chargeaccount(int index,double money){
        double price = FileManager.getFileManagerInstance().customers.get(index).getAccountmoney();
        FileManager.getFileManagerInstance().customers.get(index).setAccountmoney(money+price);
    }
    public int getIdOfOrder(){
        int cnt=0;
        for(int i=0;i<FileManager.getFileManagerInstance().customers.size();i++){
            for(int j=0;j<FileManager.getFileManagerInstance().customers.get(i).getCompletedorders().size();j++){
               cnt++;
            }
        }
        return cnt;
    }
    public String DisplayChargeAccount(int index){
        String result="";
        if(FileManager.getFileManagerInstance().customers.get(index).getAccountmoney()==0){
            result="Your wallet is empty";
            return result;
        }
        else{
            result="Your account's money is = ";
            result=result+FileManager.getFileManagerInstance().customers.get(index).getAccountmoney();
            return result;
        }
    }
    public String showCart(int index){
        String list = "";
        if(FileManager.getFileManagerInstance().customers.get(index).getCarts().size()==0){
            list=list+"Your cart is empty";
        }
        else{
            if(FileManager.getFileManagerInstance().customers.get(index).getCarts().get(0).getFoods().size()==0){
                list = list+"Your cart is empty";
            }
            else {
                list = list + "The name of the resturant: " + FileManager.getFileManagerInstance().customers.get(index).getCarts().get(0).getResturant().getName();
                list = list + "    Total price: " + FileManager.getFileManagerInstance().customers.get(index).getCarts().get(0).getCost() + "\n";
                for (int i = 0; i < FileManager.getFileManagerInstance().customers.get(index).getCarts().get(0).getFoods().size(); i++) {
                    list = list + (i + 1) + ". " + FileManager.getFileManagerInstance().customers.get(index).getCarts().get(0).getFoods().get(i).getName();
                    double price = (double) ((100 - FileManager.getFileManagerInstance().customers.get(index).getCarts().get(0).getFoods().get(i).getDiscount()) * FileManager.getFileManagerInstance().customers.get(index).getCarts().get(0).getFoods().get(i).getPrice()) / 100;
                    list = list + "    ID= " + FileManager.getFileManagerInstance().customers.get(index).getCarts().get(0).getFoods().get(i).getId();
                    list = list + "    price= " + price + "\n";
                }
            }
        }
        return list;
    }
    public String DeleteCart(int index,int id){
        boolean check = true;
        if(FileManager.getFileManagerInstance().customers.get(index).getCarts().size()==0){
            return "There is no food with this id in your cart";
        }
        for(int i=0;i<FileManager.getFileManagerInstance().customers.get(index).getCarts().get(0).getFoods().size();i++){
            if(FileManager.getFileManagerInstance().customers.get(index).getCarts().get(0).getFoods().get(i).getId()==id){
                check = false;
                double COST1,COST2;
                COST1 = FileManager.getFileManagerInstance().customers.get(index).getCarts().get(0).getCost();
                COST2 = (double) ((100 - FileManager.getFileManagerInstance().customers.get(index).getCarts().get(0).getFoods().get(i).getDiscount()) * FileManager.getFileManagerInstance().customers.get(index).getCarts().get(0).getFoods().get(i).getPrice()) / 100;
                FileManager.getFileManagerInstance().customers.get(index).getCarts().get(0).getFoods().remove(i);
                FileManager.getFileManagerInstance().customers.get(index).getCarts().get(0).setCost(COST1-COST2);
                return "Delete was successful";
            }
        }
        if(check){
            return "There is no food with this id in your cart";
        }
        return "";
    }


//ShowEstimatesdeliveryTime


//    public Delivery searchforthebestdelivery(int ResturantNode)
//    {
//        int Min = Map.dijkstra(FileManager.getFileManagerInstance().deliveries.get(0).getNode() , ResturantNode);
//        for(int i = 0 ; i<FileManager.getFileManagerInstance().deliveries.size() ; i++)
//        {
//            if(Min>Map.dijkstra(FileManager.getFileManagerInstance().deliveries.get(i).getNode() , ResturantNode))
//            {
//                Min = Map.dijkstra(FileManager.getFileManagerInstance().deliveries.get(0).getNode() , ResturantNode);
//            }
//        }
//        return Delivery.getDeliveryByNode(Min);
//    }
//
//    public long estimateTime1(int deliveryNode , int ResturantNode)
//    {
//        return (Map.dijkstra(deliveryNode , ResturantNode))*100;
//    }

    public long estimateTime2(int ResturantNode , int CustomerNode)
    {
        return (Map.dijkstra(ResturantNode , CustomerNode))*6000;
    }




}
