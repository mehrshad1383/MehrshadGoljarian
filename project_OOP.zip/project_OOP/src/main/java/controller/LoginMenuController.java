package controller;

import model.*;
import view.*;

public class LoginMenuController {
    private static LoginMenu loginMenu;
    public LoginMenuController(LoginMenu loginMenu){
        this.loginMenu = loginMenu;
    }
    public static String logginCustomer(String name,String password){
        if(Customer.printindexbycustomname(name)<0){
            System.out.println(FileManager.getFileManagerInstance().customers.size());
            return "There is no account with this name";
        }
        else{
            if(!Customer.checkpasswor(password,Customer.printindexbycustomname(name))){
                return "your password is wrong";
            }
            else if(!loginMenu.getCaptcha().getText().equals(Captcha.getCaptcha().get(loginMenu.getRand()).substring(7, 11))) {
                System.out.println(Captcha.getCaptcha().get(loginMenu.getRand()).substring(7, 11));
                return "Please enter your captcha correctly!";
            }
        }
        return "successful";
    }
    public static String logginResturantOwner(String name,String password){
        if(ResturantOwner.printindexbyResturantOwnername(name)<0){
            return "There is no account with this name";
        }
        else{
            if(!ResturantOwner.checkpasswor(password,ResturantOwner.printindexbyResturantOwnername(name))){
                return "your password is wrong";
            }
            else if(!loginMenu.getCaptcha().getText().equals(Captcha.getCaptcha().get(loginMenu.getRand() ).substring(7, 11))){
                return "Please enter your captcha correctly!";}

        }
        return "successful";
    }
    public static String logginDelivery(String name,String password){
        if(Delivery.printindexbydeliveryname(name)<0){
            return "There is no account with this name";
        }
        else{
            if(!Delivery.checkpasswor(password,Delivery.printindexbydeliveryname(name))){
                return "your password is wrong";
            }
            else if(!loginMenu.getCaptcha().getText().equals(Captcha.getCaptcha().get(loginMenu.getRand() ).substring(7, 11))){
                  return "Please enter your captcha correctly!";
            }

        }
        return "successful";
    }
    public String setANewPassword(String newPassword) {
        newPassword = newPassword.trim();
        if (newPassword.length() < 6 || !newPassword.matches(".*[a-z].*") || !newPassword.matches(".*[A-Z].*") || !newPassword.matches(".*[0-9].*") || !newPassword.matches(".*[^a-zA-Z0-9|_].*"))
            return handlePasswordErrors(newPassword);

        return "Your account has been successfully created";
    }
    public String handlePasswordErrors(String password) {
        if (password.length() < 6)
            return "Weak password! Password length should be more than 5.";

        if (!password.matches(".*[a-z].*"))
            return "Weak password! Password should have at least one small English letter.";

        if (!password.matches(".*[A-Z].*"))
            return "Weak password! Password should have at least one capital English letter.";

        if (!password.matches(".*[0-9].*"))
            return "Weak password! Password should have at least one digit.";

        if (!password.matches(".*[^a-zA-Z0-9|_].*"))
            return "Weak password! Password should have at least one character except english letters and digits.";

        else return "";
    }

    public static String CheckOut()
    {

        return "";
    }
}
