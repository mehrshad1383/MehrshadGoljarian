package controller;

import javafx.scene.layout.VBox;
import javafx.scene.media.MediaPlayer;
import model.Customer;
import model.FileManager;
import model.Food;
import model.Resturant;
import view.FoodMenu;
import view.Menu;
import view.ResturantMenu;

import java.io.IOException;

public class ResturantMenuController {

    private Customer CurrentCustomer;
    private ResturantMenu resturantMenu;
    private Resturant resturant;

    public ResturantMenuController(ResturantMenu resturantMenu) {
        this.resturantMenu = resturantMenu;
    }
    public VBox showListFood(int index,VBox vBox,Resturant resturant,MediaPlayer mediaPlayer) throws IOException {
        vBox=Resturant.ListOfResturant(index+1000000,vBox,resturant,mediaPlayer);
        return vBox;
    }
    public VBox SearchFood(int index, String name, VBox vBox, Resturant resturant, MediaPlayer mediaPlayer) throws IOException {
       vBox= Resturant.SearchFood(index+1000000,name,vBox,resturant,mediaPlayer);
       return vBox;
    }
    public String DisplayOpenOrders()
    {
        return "";
    }

    public String EditOrder()
    {
        return "";
    }

    public String ShowOrderHistory()
    {
        return "";
    }
/*
    public void SelectFood(int indexResturant,int idFood,Customer customer){
        int indexFood = Resturant.returnIndexRefid(idFood,indexResturant);
        if(indexFood==-1){
            System.out.println("There is no food with this id");
        }
        else{
            indexFood=indexFood+2000000;
            Food food;
            food = Resturant.returnFoodByIndex(indexFood,indexResturant);
            FoodMenu foodMenu = new FoodMenu(food);
            foodMenu.run(indexResturant,indexFood,customer);
        }
    }

 */
    public VBox ShowAllCommand(int index,VBox vBox) throws IOException {
       vBox= Resturant.ShowAllCommand(index,vBox);
       return vBox;
    }
    public void ADDNewcomment(Customer customer,int index,String command){
        Resturant.ADDNewComment(command,customer,index);
    }
    public void Editcomment(int index,int id,String command){
            Resturant.EditComment(command,index,id);
        }

    public boolean checkCommentOrNot(Customer customer,int index){
        for(int i=0;i<FileManager.getFileManagerInstance().resturants.get(index).getComments().size();i++){
            if(FileManager.getFileManagerInstance().resturants.get(index).getComments().get(i).getCustomer().equals(customer)){
                return false;
            }
        }
        return true;
    }
    public void DisplayRating(int index)
    {
        double rating = Resturant.DisplayRating(index);
        if(rating==-1){
            System.out.println("No rated");
        }
        else {
            System.out.println(rating+" from "+Resturant.NumberOfRating(index)+" vote");
        }
    }

    public void SubmitRating(int index,int indexOfcomment,double rating)
    {
            Resturant.setrating(index,indexOfcomment,rating);

    }

    public void EditRating(int index,int indexOfcomment,double rating)
    {
            Resturant.setrating(index,indexOfcomment,rating);
    }
}
