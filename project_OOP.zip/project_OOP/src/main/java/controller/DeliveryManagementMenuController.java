package controller;

import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.StrokeType;
import model.*;
import view.DeliveryManagementMenu;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.regex.Matcher;

public class DeliveryManagementMenuController {
    private DeliveryManagementMenu deliveryManagementMenu;
    public ArrayList<Order> AvailibleOrders = new ArrayList<>();
    public DeliveryManagementMenuController(DeliveryManagementMenu deliveryManagementMenu) {
        this.deliveryManagementMenu=deliveryManagementMenu;
    }

//    public void ShowOrders(Delivery delivery) {
//        AvailibleOrders = new ArrayList<>();
////        String returner = "";
//        for (int i = 0; i < FileManager.getFileManagerInstance().customers.size(); i++) {
//            for (int j = 0; j < FileManager.getFileManagerInstance().customers.get(i).getCompletedorders().size(); j++) {
//                if (FileManager.getFileManagerInstance().customers.get(i).getCompletedorders().get(j).getStatus().equals("Confirmed_IsCooking")) {
////                    returner += FileManager.getFileManagerInstance().customers.get(i).getCompletedorders().get(j).getId()+" "+
////                            FileManager.getFileManagerInstance().customers.get(i).getCompletedorders().get(j).getOwner().getNode()+" "+
////                            FileManager.getFileManagerInstance().customers.get(i).getCompletedorders().get(j).getResturant().getLocation().getNode()+" "+
////                            FileManager.getFileManagerInstance().customers.get(i).getCompletedorders().get(j).getDeliveryCost()+"\n";
//                    AvailibleOrders.add(FileManager.getFileManagerInstance().customers.get(i).getCompletedorders().get(j));
//                }
//            }
//        }
//        for (int i = 0; i < AvailibleOrders.size(); i++) {
//            ButtonV2 buttonV2 = new ButtonV2(icon, AvailibleOrders.get(i));
//            buttonV2.getButton().setLayoutX(Map.getMapMatrixX()[AvailibleOrders.get(i).getResturant().getLocation().getNode()]);
//            buttonV2.getButton().setLayoutY(Map.getMapMatrixY()[AvailibleOrders.get(i).getResturant().getLocation().getNode()]);
//            buttonV2.getButton().setPrefWidth(30);
//            buttonV2.getButton().setPrefHeight(30);
//            buttonV2.getButton().setOnAction(MouseEvent ->
//            {
////                ConfirmOrder(   , delivery );
//            });
//        }
//    }

    public void ShowRoad(Delivery delivery) {
        System.out.println(delivery.getOrder());
//        if(delivery.getOrder()==null)
//        {
//           return "you dont have any order to go for";
//        }
//
//       return Map.dijkstraPrinter(delivery.getNode()
//                ,delivery.getOrder().getResturant().getLocation().getNode());
        if(delivery.getOrder()==null)
        {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("you dont have any order");
            alert.showAndWait();
        }
        else{
            Order order = delivery.getOrder();
            for(int i = 0 ; i<order.getDistanceFromDeliveryToResturant().size()-1 ; i++) {
                Line line = new Line(Map.getMapMatrixX()[order.getDistanceFromDeliveryToResturant()
                        .get(i) - 1], Map.getMapMatrixY()[order.getDistanceFromDeliveryToResturant().get(i) - 1]
                        , Map.getMapMatrixX()[order.getDistanceFromDeliveryToResturant()
                        .get(i + 1) - 1], Map.getMapMatrixY()[order.getDistanceFromDeliveryToResturant().get(i + 1) - 1]);
                line.setStrokeType(StrokeType.OUTSIDE);
                if (trafic(order.getDistanceFromDeliveryToResturant().get(i + 1), order.getDistanceFromDeliveryToResturant().get(i)).equals("Blue"))
                    line.setStroke(Color.BLUE);
                else if (trafic(order.getDistanceFromDeliveryToResturant().get(i + 1), order.getDistanceFromDeliveryToResturant()
                        .get(i)).equals("Yellow"))
                    line.setStroke(Color.YELLOW);
                else if (trafic(order.getDistanceFromDeliveryToResturant().get(i + 1), order.getDistanceFromDeliveryToResturant()
                        .get(i)).equals("Red"))
                    line.setStroke(Color.RED);
                line.setStrokeWidth(3);
                deliveryManagementMenu.getPane().getChildren().addAll(line);
            }
            for(int i = 0 ; i<order.getDistanceFromDeliveryToCustomer().size()-1 ; i++) {
                Line line = new Line(Map.getMapMatrixX()[order.getDistanceFromDeliveryToCustomer()
                        .get(i) - 1], Map.getMapMatrixY()[order.getDistanceFromDeliveryToCustomer().get(i) - 1]
                        , Map.getMapMatrixX()[order.getDistanceFromDeliveryToCustomer()
                        .get(i + 1) - 1], Map.getMapMatrixY()[order.getDistanceFromDeliveryToCustomer().get(i + 1) - 1]);
                line.setStrokeType(StrokeType.OUTSIDE);
                if (trafic(order.getDistanceFromDeliveryToCustomer().get(i + 1), order.getDistanceFromDeliveryToCustomer().get(i)).equals("Blue"))
                    line.setStroke(Color.BLUE);
                else if (trafic(order.getDistanceFromDeliveryToCustomer().get(i + 1), order.getDistanceFromDeliveryToCustomer()
                        .get(i)).equals("Yellow"))
                    line.setStroke(Color.YELLOW);
                else if (trafic(order.getDistanceFromDeliveryToCustomer().get(i + 1), order.getDistanceFromDeliveryToCustomer()
                        .get(i)).equals("Red"))
                    line.setStroke(Color.RED);
                line.setStrokeWidth(3);
                deliveryManagementMenu.getPane().getChildren().addAll(line);
            }
        }
    }

    public void ShowRoad2(Order order) {
//        String idd = m.group("id");
//        int id = Integer.parseInt(idd);
//        Order t = Customer.findOrderByID(id);
//        return Map.dijkstraPrinter(t.getOwner().getNode()
//                ,t.getResturant().getLocation().getNode());
        ArrayList<Integer> newbie = Map.dijkstraPrinter(order.getOwner().getNode()
                ,order.getResturant().getLocation().getNode());
        for(int i = 0 ; i<newbie.size()-1 ; i++)
        {
            Line line = new Line(Map.getMapMatrixX()[newbie.get(i)-1], Map.getMapMatrixY()[newbie.get(i)-1]
                    ,Map.getMapMatrixX()[newbie.get(i+1)-1] , Map.getMapMatrixY()[newbie.get(i+1)-1]);
            line.setStrokeType(StrokeType.OUTSIDE);
            if(trafic(newbie.get(i+1) , newbie.get(i)).equals("Blue"))
                line.setStroke(Color.BLUE);
            else if(trafic(newbie.get(i+1) , newbie.get(i)).equals("Yellow"))
                line.setStroke(Color.YELLOW);
            else if(trafic(newbie.get(i+1) , newbie.get(i)).equals("Red"))
                line.setStroke(Color.RED);
            line.setStrokeWidth(3);
            deliveryManagementMenu.getPane().getChildren().addAll(line);
        }
        Label label = new Label();
        label.setGraphic(deliveryManagementMenu.icon2);
        label.setLayoutX(Map.getMapMatrixX()[order.getResturant().getLocation().getNode()-1]);
        label.setLayoutY(Map.getMapMatrixY()[order.getResturant().getLocation().getNode()-1]);
        Label label1 = new Label();
        label1.setGraphic(deliveryManagementMenu.icon3);
        label1.setLayoutX(Map.getMapMatrixX()[order.getOwner().getNode()-1]);
        label1.setLayoutY(Map.getMapMatrixY()[order.getOwner().getNode()-1]);
        deliveryManagementMenu.getPane().getChildren().add(label);
        deliveryManagementMenu.getPane().getChildren().add(label1);
    }

    public String ConfirmOrder(Order order , Delivery delivery) {
        System.out.println("dd");
        if(order==null)
        {
            System.out.println("gang");
        }
        delivery.setOrder(order);
        assert order != null;
        order.setDelivery(delivery);
        long t1 = estimateTime1(delivery.getNode() ,
                order.getResturant().getLocation().getNode());
        order.setTimefordeliverytorestaurant(t1);
        order.setFinaltime(order.getTimefordeliverytorestaurant()+
                order.getTimefordeliverytoCustomer()+System.currentTimeMillis());
        order.setDistanceFromDeliveryToResturant(Map.dijkstraPrinter(delivery.getNode() ,order.getResturant().getLocation().getNode()));
        OrderController orderController = new OrderController(order,delivery);
        System.out.println(delivery.getOrder());
        orderController.start();
        System.out.println(delivery.getOrder().getOwner().getName());
        System.out.println(order.getResturant().getName());
        System.out.println(order.getOwner().getName());
        return "Confirmed";
    }

    public long estimateTime1(int deliveryNode , int ResturantNode)
    {
        return (Map.dijkstra(deliveryNode , ResturantNode))*6000;
    }

    public String trafic(int node1 , int node2)
    {
        if(Map.MapMatrixV2[node1][node2] - Map.getMapMatrix()[node1][node2] == 2)
        {
            return "Red";
        }
        if(Map.MapMatrixV2[node1][node2] - Map.getMapMatrix()[node1][node2] == 1)
        {
            return "Yellow";
        }

        return "Blue";
    }
}
