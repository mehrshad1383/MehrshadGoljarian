package controller;

import javafx.scene.layout.VBox;
import model.*;
import view.AdminMenu;
import view.AdminResturantMenu;
import view.Menu;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AdminMenuController {
    public  ArrayList<Restauranttmp> restauranttmps ;
    private AdminMenu adminMenu;

    public AdminMenuController(AdminMenu adminMenu) {
        this.adminMenu = adminMenu;
    }
    public VBox getVbox () throws IOException {
        restauranttmps= new ArrayList<>();

        ResturantOwner resturantOwner = adminMenu.getResturantOwner();
        String type="";
        String name="";
        double rating;
        String rate="";
        int id;
        VBox vBox = new VBox();
        for(int i = 0; i < resturantOwner.getResturants().size(); ++i) {
            name= resturantOwner.getResturants().get(i).getName() ;
            id=  resturantOwner.getResturants().get(i).getId();
            int a = 0;
            for (int j = 0; j < resturantOwner.getResturants().get(i).getComments().size(); j++) {
                a+=resturantOwner.getResturants().get(i).getComments().get(j).getRating();
            }
            if(resturantOwner.getResturants().get(i).getComments().size()!=0)
                a/=resturantOwner.getResturants().get(i).getComments().size();
            rating=a;
            rate=rating+" from ";
            rate=rate+String.valueOf(resturantOwner.getResturants().get(i).getComments().size())+" vote";
            for (int j = 0; j < resturantOwner.getResturants().get(i).getRestaurantType().size(); j++) {
                type= type+  resturantOwner.getResturants().get(i).getRestaurantType().get(j)+"-";
            }
            StringBuilder b = new StringBuilder(type.trim());
            type= b.deleteCharAt(b.length()-1).toString();
            Restauranttmp restauranttmp =new Restauranttmp(name,type,rate+"","20000","/Image/pic2.png",id+"",resturantOwner.getResturants().get(i),true);
            restauranttmps.add(restauranttmp);
            vBox.getChildren().add(restauranttmp.getInstance());
        }

        return vBox;


    }
    public void ShowOwnRestaurant(ResturantOwner resturantOwner){
        if(resturantOwner.getResturants().size()==0){
            System.out.println("You don't have any restaurant");
        }else {
            System.out.println("Your restaurants :");
            ArrayList<Resturant> t = resturantOwner.getSortedRestaurants();
            for (int i = 0; i < t.size() ; i++) {
                System.out.println((i+1)+"_ "+t.get(i).getName()+"\tid: "+t.get(i).getId());
            }
        }
    }
    public void CreateRestaurant(ResturantOwner resturantOwner){
        String command;
        String r4 = "(?<num>(\\d)+)";
        Pattern p4 = Pattern.compile(r4);
        String restaurantName = Menu.getScanner().nextLine().trim();
        int idd = 1000000+Resturant.getAllresturants().size();
        System.out.println("Your id is "+idd);
        System.out.println("Where does your restaurant located?(write node num)");
        while (true){
            String no = Menu.getScanner().nextLine().trim();
            Matcher m4 = p4.matcher(no);
            if(m4.matches()){
                int nd = Integer.parseInt(m4.group("num"));
                Mapi mapi = new Mapi(nd);
                System.out.println("Write your FOODTYPES in below and seprate them by mines like (italian-irani torki-fastfood)");
                command= Menu.getScanner().nextLine().trim();
                String[] types = command.trim().split("-");
                ArrayList<String> tmp = new ArrayList<>();
                for (int i = 0; i < types.length; i++) {
                    tmp.add(types[i]);
                }
                Resturant resturant = new Resturant(restaurantName,idd, mapi,tmp);
                resturant.setResturantOwner(resturantOwner);
                resturantOwner.AddToResturants(resturant);
                System.out.println("restaurant created successfully");
                break;
            }else {
                System.out.println("restaurant location is described by a number !");
            }
        }
    }
    public void SelectResturant(int id) {
        Resturant resturant = null;
        boolean a = false;
        for(int i = 0; i < this.adminMenu.getResturantOwner().getResturants().size(); ++i) {
            if (((Resturant)this.adminMenu.getResturantOwner().getResturants().get(i)).getId() == id) {
                a = true;
                resturant = (Resturant)this.adminMenu.getResturantOwner().getResturants().get(i);
            }
        }
        if (!a) {
            System.out.println("You don't own any restaurant with this id");
        } else {
            AdminResturantMenu adminResturantMenu = new AdminResturantMenu(this.adminMenu.getResturantOwner(), resturant);
            adminResturantMenu.run(id-1000000);
        }

    }
}