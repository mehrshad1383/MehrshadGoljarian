package controller;

import model.Map;

public class TraficMaker extends Thread{

    public static int pp = 0;
    public void runner()
    {
        for(int i = 0 ; i<134 ; i++)
        {
            for(int j = 0 ; j<134 ; j++)
            {
                Map.MapMatrixV2[i][j] = Map.getMapMatrix()[i][j];
            }
        }
    }

    @Override
    public void run()
    {
        while(true)
        {
            runner();
            for(int i = 1 ; i<134 ; )
            {
                for(int j = 1 ; j<134 ; )
                {
                    if(Map.MapMatrixV2[i][j]!=0)
                    {
                        Map.MapMatrixV2[i][j]+=1;
                    }
                    j+=2+pp;
                }
                i+=2+pp;
            }
            for(int i = 2 ; i<134 ; i+=0)
            {
                for(int j = 2 ; j<134 ; j+=0)
                {
                    if(Map.MapMatrixV2[i][j]!=0&&Map.MapMatrixV2[i][j] - Map.getMapMatrix()[i][j] == 0)
                    {
                        Map.MapMatrixV2[i][j]+=2;
                    }
                    j+=1+pp;
                }
                i+=1+pp;
            }
            pp=(pp+2)%3;
            try {
                Thread.sleep(10);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
