package controller;

import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import model.Customer;
import model.FileManager;
import model.Historytmp;
import model.Order;
import view.CostumerMenu;
import view.OrderHistoryMenu;

import java.io.IOException;

public class OrderHistoryMenuController {
    private OrderHistoryMenu orderHistoryMenu;

    public OrderHistoryMenuController(OrderHistoryMenu orderHistoryMenu) {
        this.orderHistoryMenu=orderHistoryMenu;
    }
   // public void showAllOrder(int index){
    //    System.out.println(ShowAllOrder(index));
   // }
    public static VBox ShowAllOrder(int index, VBox vBox) throws IOException {
        String name ="";
        int id;
        String list="";
        String numorder;
        int cnt=0;
        if(FileManager.getFileManagerInstance().customers.get(index).getCompletedorders().size()>0) {
            for (int i = 0; i < FileManager.getFileManagerInstance().customers.get(index).getCompletedorders().size(); i++) {
                System.out.println(FileManager.getFileManagerInstance().customers.get(index).getCompletedorders().get(i).getStatus());
                cnt=0;
                list="";
                id = ( FileManager.getFileManagerInstance().customers.get(index).getCompletedorders().get(i).getId()+3000000);
                name=FileManager.getFileManagerInstance().customers.get(index).getCompletedorders().get(i).getResturant().getName();
                list = list+"Total price= "+FileManager.getFileManagerInstance().customers.get(index).getCompletedorders().get(i).getOrderedfoods().get(0).getCost()+"\n";
                for (int j = 0; j <FileManager.getFileManagerInstance().customers.get(index).getCompletedorders().get(i).getOrderedfoods().get(0).getFoods().size() ; j++) {
                    cnt++;
                    list = list+(cnt) + ". NAME FOOD= " + FileManager.getFileManagerInstance().customers.get(index).getCompletedorders().get(i).getOrderedfoods().get(0).getFoods().get(j).getName()+"\n";
                }
               vBox.getChildren().add(new Historytmp(name,list,"ORDER"+(i+1),"20000","/Image/pic2.png",id+"").getInstance()) ;
            }
        }
        else{

        }
        return vBox;
    }
    public void Showspecialorder(int index,int id){
        System.out.println(showspecialOrder(index,id));
    }
    public static String showspecialOrder(int index,int id){
        String list ="";
        if(id<0||id>=getIdOfOrderr()){
            list = list+"There is no order with this id\n";
        }
        else {
            Order order = Customer.findOrderByID(id+3000000);
            list = list+"The name of the restaurant= " + order.getOrderedfoods().get(0).getResturant().getName() + "  Total price= ";
            list = list+order.getOrderedfoods().get(0).getCost()+"\n";
            for (int i = 0; i < order.getOrderedfoods().get(0).getFoods().size(); i++) {
                list = list+(i + 1) + ". NAME FOOD= " + order.getOrderedfoods().get(0).getFoods().get(i).getName()+"\n";
            }
        }
        return list;
    }
    public static int getIdOfOrderr(){
        int cnt=0;
        for(int i=0;i<FileManager.getFileManagerInstance().customers.size();i++){
            for(int j=0;j<FileManager.getFileManagerInstance().customers.get(i).getCompletedorders().size();j++){
                cnt++;
            }
        }
        return cnt;
    }
}
