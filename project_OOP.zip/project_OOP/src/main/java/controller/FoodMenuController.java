package controller;

import javafx.scene.layout.VBox;
import model.*;
import view.FoodMenu;
import view.Menu;
import view.ResturantMenu;

import java.io.IOException;

public class FoodMenuController {
    FoodMenu foodMenu;
    public FoodMenuController(FoodMenu foodMenu) {
        this.foodMenu = foodMenu;
    }
    public VBox showAllComment(int indexresturant, int indexfood,VBox vBox) throws IOException {
        vBox = Resturant.showAllComment(indexresturant,indexfood,vBox);
        return vBox;
    }
    public void DisplayRatings(int indexresturant,int indexfood){
        double rating = Resturant.RatingFood(indexresturant,indexfood);
        if(rating==-1){
            System.out.println("No rated");
        }
        else{
            System.out.println(rating+" from "+Resturant.numOfRatingFood(indexresturant,indexfood)+" vote");
        }
    }
    public void AddnewComment(Customer customer,String command,int indexresturant,int indexfood)
    {
            Resturant.commentForFood(indexresturant,indexfood,command,customer);

    }
    public boolean CheckforCommitOrnot(Customer customer,int indexrestaurant,int indexfood){
        for(int i=0;i<FileManager.getFileManagerInstance().resturants.get(indexrestaurant).getFoods().get(indexfood).getComments().size();i++){
            if(FileManager.getFileManagerInstance().resturants.get(indexrestaurant).getFoods().get(indexfood).getComments().get(i).getCustomer().equals(customer)){
                return false;
            }
        }
        return true;
    }
    public void EditComment(int indexresturant, int indexfood,int id,String command){
            Resturant.EditCommitForFood(id,command,indexresturant,indexfood);
    }
    public static int returnindexComment(Customer customer,int indexrestaurant,int indexfood){
        for(int i=0;i<FileManager.getFileManagerInstance().resturants.get(indexrestaurant).getFoods().get(indexfood).getComments().size();i++){
            if(FileManager.getFileManagerInstance().resturants.get(indexrestaurant).getFoods().get(indexfood).getComments().get(i).getCustomer().equals(customer)){
                return i;
            }
        }
        return -1;
    }
    public static double returnrating(int indexrestaurant,int indexfood,int indexcommentid){
        return FileManager.getFileManagerInstance().resturants.get(indexrestaurant).getFoods().get(indexfood).getComments().get(indexcommentid).getRating();
    }
    public void SubmitRating(int indexresturant,int indexfood,double rating,int id){

                Resturant.SubmitRatingForFood(indexresturant, indexfood, rating, id);
            }

    public void EditRating(int indexresturant,int indexfood,double rating,int id){
            Resturant.SubmitRatingForFood(indexresturant,indexfood,rating,id);
    }

    public void AddToCart(int index,Food food,Resturant resturant,Customer customer)
    {
        addtoCart(index,food,resturant,customer);
    }
    public  boolean checkOrderFood(Customer customer,Food food,int index){
        int inedex=0;
        for(int i=0;i<FileManager.getFileManagerInstance().customers.size();i++){
            if(FileManager.getFileManagerInstance().customers.get(i).equals(customer)){
                inedex = i;
            }
        }
        for(int i=0;i<FileManager.getFileManagerInstance().customers.get(inedex).getCompletedorders().size();i++){
            for(int j=0;j<FileManager.getFileManagerInstance().customers.get(inedex).getCompletedorders().get(i).getOrderedfoods().get(0).getFoods().size();j++){
                if(FileManager.getFileManagerInstance().customers.get(inedex).getCompletedorders().get(i).getOrderedfoods().get(0).getFoods().get(j).getId()==food.getId()&&FileManager.getFileManagerInstance().customers.get(inedex).getCompletedorders().get(i).getOrderedfoods().get(0).getResturant().getId()==index+1000000){
                    return true;
                }
            }
        }
        return false;
    }
    public static void addtoCart(int index,Food food,Resturant resturant,Customer customer){
        Cart cart = null;
        if(customer.hasCart==false){
            cart = new Cart(customer,resturant,0);
            FileManager.getFileManagerInstance().customers.get(index).getCarts().add(cart);
            customer.hasCart=true;
        }else {
            customer.getCarts().get(0);
        }
        FileManager.getFileManagerInstance().customers.get(index).getCarts().get(0).getFoods().add(food);
        FileManager.getFileManagerInstance().customers.get(index).getCarts().get(0).setResturant(resturant);
        double price = FileManager.getFileManagerInstance().customers.get(index).getCarts().get(0).getCost();
        double price1 = (double) ((100-food.getDiscount())*food.getPrice())/100;
        FileManager.getFileManagerInstance().customers.get(index).getCarts().get(0).setCost(price+price1);
    }
    public  void ShowResponse(int indexrestaurant,int indexfood,Customer customer){
        indexrestaurant=indexrestaurant-1000000;
        indexfood = indexfood-2000000;
        int id = Food.ReturnIndexOfComment(indexrestaurant,indexfood,customer);
        if(id==-1){
            System.out.println("You have not registered a comment");
        }
        else if(!FileManager.getFileManagerInstance().resturants.get(indexrestaurant).getFoods().get(indexfood).getComments().get(id).isAnswered()){
            System.out.println("NO answe has been given for you");
        }
        else{
            System.out.println("RESPONSE= "+FileManager.getFileManagerInstance().resturants.get(indexrestaurant).getFoods().get(indexfood).getComments().get(id).getResponse());
        }
    }
}
