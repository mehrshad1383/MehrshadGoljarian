package controller;

import javafx.scene.layout.VBox;
import model.*;
import view.AdminOrderHistoryMenu;
import view.OrderHistoryMenu;

import java.io.IOException;

public class AdminOrderHistoryMenuController {
    private AdminOrderHistoryMenu adminOrderHistoryMenu;
    public AdminOrderHistoryMenuController(AdminOrderHistoryMenu adminOrderHistoryMenu) {
        this.adminOrderHistoryMenu=adminOrderHistoryMenu;
    }
    // public void showAllOrder(int index){
    //    System.out.println(ShowAllOrder(index));
    // }
    public static VBox ShowOrderHistory(Resturant resturant, VBox vBox) throws IOException {
        String name ="";
        int id;
        String list="";
        String numorder;
        int cnt=0;
        if(resturant.getOrders().size()>0) {
            for (int i = 0; i < resturant.getOrders().size(); i++) {
                if(resturant.getOrders().get(i).getStatus().equals("Recieved")){
                cnt=0;
                list="";
                id = ( resturant.getOrders().get(i).getId()+3000000);
                name=resturant.getOrders().get(i).getResturant().getName();
                list = list+"Total price= "+resturant.getOrders().get(i).getOrderedfoods().get(0).getCost()+"\n";
                for (int j = 0; j <resturant.getOrders().get(i).getOrderedfoods().get(0).getFoods().size() ; j++) {
                    cnt++;
                    list = list+(cnt) + ". NAME FOOD= " + resturant.getOrders().get(i).getOrderedfoods().get(0).getFoods().get(j).getName()+"\n"
                            +"Status = "+resturant.getOrders().get(i).getStatus()+"\n";
                }
                vBox.getChildren().add(new Historytmp(name,list,"ORDER"+(i+1),"20000","/Image/pic2.png",id+"").getInstance()) ;
            }}
        }
        else{

        }
        return vBox;
    }
    public static VBox ShowAvailibleOrder(Resturant resturant, VBox vBox) throws IOException {
        String name ="";
        int id;
        String list="";
        String numorder;
        int cnt=0;
        if(resturant.getOrders().size()>0) {
            for (int i = 0; i < resturant.getOrders().size(); i++) {
                if(resturant.getOrders().get(i).getStatus().equals("WaitingForRestuarantConfirmation")||
                        resturant.getOrders().get(i).getStatus().equals("Confirmed_IsCooking")
                ||resturant.getOrders().get(i).getStatus().equals("Delivery")){
                    cnt=0;
                    list="";
                    id = ( resturant.getOrders().get(i).getId()+3000000);
                    name=resturant.getOrders().get(i).getResturant().getName();
                    list = list+"Total price= "+resturant.getOrders().get(i).getOrderedfoods().get(0).getCost()+"\n";
                    for (int j = 0; j <resturant.getOrders().get(i).getOrderedfoods().get(0).getFoods().size() ; j++) {
                        cnt++;
                        list = list+(cnt) + ". NAME FOOD= " + resturant.getOrders().get(i).getOrderedfoods().get(0).getFoods().get(j).getName()+"\n"
                        +"Status = "+resturant.getOrders().get(i).getStatus()+"\n";
                    }
                    vBox.getChildren().add(new Historytmp(name,list,"ORDER"+(i+1),"20000","/Image/pic2.png",id+"").getInstance()) ;
                }}
        }
        else{

        }
        return vBox;
    }
}
