module untitled {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires java.desktop;
    requires com.google.gson;
    requires javafx.media;

    exports view;
    opens view to javafx.fxml;
    exports controller;
    opens controller to javafx.fxml, com.google.gson;
    exports model;
    opens model to javafx.fxml, com.google.gson;
}